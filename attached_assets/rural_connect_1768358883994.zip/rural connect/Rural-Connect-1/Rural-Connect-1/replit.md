# Rural Community Management App - Transamazônica

## Overview

A mobile-first web application for rural community coordination in the Transamazônica region (Medicilândia - Uruará, Pará, Brazil). The app enables community members to report and track infrastructure issues (road problems, electrical outages, bridge damage), manage community petitions, and connect with local producers through an interactive map interface.

The application serves rural producers and community members who need to coordinate around shared infrastructure challenges, making it critical that the interface be accessible, work well on mobile devices, and support users with varying levels of technical literacy.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming (light/dark mode support)
- **Map Integration**: Leaflet with react-leaflet for interactive mapping
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript (ESM modules)
- **API Style**: RESTful JSON API at `/api/*` endpoints
- **Build System**: Custom build script using esbuild for server bundling and Vite for client

### Data Layer
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema-to-validation integration
- **Schema Location**: `shared/schema.ts` - shared between client and server for type safety

### Key Data Entities
1. **Vicinais** (Rural roads/communities) - geographic communities with social links
2. **Users** - community members/producers with property locations
3. **Occurrences** - infrastructure issues (electrical, road, bridge, social, theft, other)
4. **Petitions** - community petitions with signature tracking
5. **Signatures** - petition endorsements from users

### Design Decisions
- **Mobile-first design**: Bottom navigation, large touch targets, optimized for smartphones
- **Offline awareness**: Architecture supports sync status indicators (for future PWA features)
- **Material Design influence**: Using Roboto font, consistent spacing system
- **Portuguese localization**: All user-facing text in Brazilian Portuguese

### Directory Structure
```
client/src/           # React frontend
  components/         # Reusable UI components
  components/ui/      # shadcn/ui base components
  pages/              # Route page components
  hooks/              # Custom React hooks
  lib/                # Utilities (query client, theme)
server/               # Express backend
  routes.ts           # API route definitions
  storage.ts          # Database access layer
  db.ts               # Database connection
shared/               # Shared types and schemas
  schema.ts           # Drizzle schema definitions
```

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connected via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations stored in `/migrations`

### Third-Party Services
- **Leaflet Maps**: OpenStreetMap tiles for map rendering (no API key required)
- **Google Fonts**: Roboto font family

### Key NPM Dependencies
- `drizzle-orm` / `drizzle-zod`: Type-safe database operations
- `@tanstack/react-query`: Server state management
- `react-leaflet` / `leaflet`: Interactive mapping
- `@radix-ui/*`: Accessible UI primitives
- `react-hook-form` / `zod`: Form handling and validation
- `wouter`: Client-side routing
- `express` / `express-session`: HTTP server and sessions
- `connect-pg-simple`: PostgreSQL session storage

## Recent Changes

### January 2026
- **Service Providers System**: Full directory of service providers for rural communities
  - Provider registration with company/autonomous types
  - Service catalog with categories (trator, escavadeira, patrol, caçamba, pipa, eletricista, etc.)
  - Pricing with min/max and units (hora, diária, metro, etc.)
  - Coverage areas by vicinais
  - Availability scheduling
  - Contact integration (telefone, WhatsApp)
  
- **Community Points System**: Gamification to incentivize community engagement
  - Points dashboard with total, monthly, and level tracking
  - Action categories: limpeza_rede, bom_vizinho, contribuicao_trabalho, etc.
  - Community leaderboard with top 20 rankings
  - Point events history

- **CRUD Functionality**: Complete CRUD operations for vicinais, occurrences, and roads
  - VicinalDialog, OccurrenceDialog for add/edit with form validation
  - Delete confirmation dialogs with AlertDialog component
  - Settings page (/configuracoes) for managing all data entities
  
- **API Routes**: RESTful endpoints with payload sanitization
- **Design System**: Amazon-inspired color palette (forest greens, earth tones, warm oranges)
- **Mobile-first Navigation**: Bottom navigation with "Serviços" and "Pontos" sections

- **Google Maps Migration**: Migrated from Leaflet to @vis.gl/react-google-maps
  - Custom SVG markers for better compatibility
  - Road drawing tool with polyline support
  - Distance measurement tool
  - API key stored in Replit Secrets (VITE_GOOGLE_MAPS_API_KEY)
  - Map ID configurable via VITE_GOOGLE_MAPS_MAP_ID

## Future Integration Considerations

### Lidacacau Project
- **Repository**: https://github.com/gut-bit/lidacacau
- **Technology**: Expo React Native with PostgreSQL backend
- **Purpose**: Rural work app for the same region
- **Potential Integration**: User data sharing, road information sync, unified producer directory
- **Status**: Reference saved for future consideration