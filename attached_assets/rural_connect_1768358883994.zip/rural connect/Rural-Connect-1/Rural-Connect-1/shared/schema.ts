import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Vicinal (Community/Road)
export const vicinais = pgTable("vicinais", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  whatsappLink: text("whatsapp_link"),
  facebookLink: text("facebook_link"),
  instagramLink: text("instagram_link"),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
});

export const insertVicinalSchema = createInsertSchema(vicinais).omit({ id: true });
export type InsertVicinal = z.infer<typeof insertVicinalSchema>;
export type Vicinal = typeof vicinais.$inferSelect;

// Users (Producers/Members)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  cpf: text("cpf").notNull(),
  car: text("car"),
  telefone: text("telefone"),
  vicinalId: varchar("vicinal_id"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  propriedadeNome: text("propriedade_nome"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Occurrence Types
export type OccurrenceType = 'electrical' | 'road' | 'bridge' | 'social' | 'theft' | 'other';
export type OccurrenceStatus = 'open' | 'in_progress' | 'resolved';

// Occurrences (Problems/Incidents)
export const occurrences = pgTable("occurrences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  tipo: text("tipo").notNull().$type<OccurrenceType>(),
  status: text("status").notNull().$type<OccurrenceStatus>().default('open'),
  vicinalId: varchar("vicinal_id").notNull(),
  userId: varchar("user_id").notNull(),
  roadId: varchar("road_id"),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  fotos: text("fotos").array(),
  createdAt: text("created_at").notNull(),
  resolvedAt: text("resolved_at"),
  resolvedBy: varchar("resolved_by"),
});

export const insertOccurrenceSchema = createInsertSchema(occurrences).omit({ id: true, resolvedAt: true, resolvedBy: true });
export type InsertOccurrence = z.infer<typeof insertOccurrenceSchema>;
export type Occurrence = typeof occurrences.$inferSelect;

// Occurrence History (Resolved/Expired occurrences)
export const occurrenceHistory = pgTable("occurrence_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalId: varchar("original_id").notNull(),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  tipo: text("tipo").notNull().$type<OccurrenceType>(),
  vicinalId: varchar("vicinal_id").notNull(),
  userId: varchar("user_id").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  fotos: text("fotos").array(),
  createdAt: text("created_at").notNull(),
  resolvedAt: text("resolved_at"),
  resolvedBy: varchar("resolved_by"),
  archivedAt: text("archived_at").notNull(),
  archiveReason: text("archive_reason").notNull(),
});

export type OccurrenceHistory = typeof occurrenceHistory.$inferSelect;

// Occurrence Comments
export const occurrenceComments = pgTable("occurrence_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  occurrenceId: varchar("occurrence_id").notNull(),
  userId: varchar("user_id").notNull(),
  userName: text("user_name").notNull(),
  content: text("content").notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertCommentSchema = createInsertSchema(occurrenceComments).omit({ id: true });
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type OccurrenceComment = typeof occurrenceComments.$inferSelect;

// Petitions (Abaixo-assinados)
export const petitions = pgTable("petitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  occurrenceId: varchar("occurrence_id"),
  vicinalId: varchar("vicinal_id").notNull(),
  userId: varchar("user_id").notNull(),
  fotos: text("fotos").array(),
  targetSignatures: integer("target_signatures").default(50),
  createdAt: text("created_at").notNull(),
});

export const insertPetitionSchema = createInsertSchema(petitions).omit({ id: true });
export type InsertPetition = z.infer<typeof insertPetitionSchema>;
export type Petition = typeof petitions.$inferSelect;

// Petition Signatures
export const signatures = pgTable("signatures", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  petitionId: varchar("petition_id").notNull(),
  userId: varchar("user_id").notNull(),
  signedAt: text("signed_at").notNull(),
});

export const insertSignatureSchema = createInsertSchema(signatures).omit({ id: true });
export type InsertSignature = z.infer<typeof insertSignatureSchema>;
export type Signature = typeof signatures.$inferSelect;

// Road Types
export type RoadClassification = 'principal' | 'ramal';
export type TrafegabilidadeEstado = 'boa' | 'regular' | 'ruim' | 'intransitavel';

// Roads (Estradas/Vicinais)
export const roads = pgTable("roads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  classification: text("classification").notNull().$type<RoadClassification>(),
  coordinates: text("coordinates").notNull(),
  color: text("color").default("#2563eb"),
  vicinalId: varchar("vicinal_id"),
  associationId: varchar("association_id"),
  trafegabilidade: text("trafegabilidade").$type<TrafegabilidadeEstado>().default('regular'),
  trafegabilidadeDetalhe: text("trafegabilidade_detalhe"),
  agriculturaPrincipal: text("agricultura_principal"),
  comprimentoMetros: real("comprimento_metros"),
  createdBy: varchar("created_by"),
  createdAt: text("created_at").notNull(),
});

export const insertRoadSchema = createInsertSchema(roads).omit({ id: true });
export type InsertRoad = z.infer<typeof insertRoadSchema>;
export type Road = typeof roads.$inferSelect;

// Road Members (Produtores da Estrada)
export const roadMembers = pgTable("road_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roadId: varchar("road_id").notNull(),
  userId: varchar("user_id"),
  propriedadeNome: text("propriedade_nome").notNull(),
  hectares: real("hectares"),
  culturaPrincipal: text("cultura_principal"),
  createdAt: text("created_at").notNull(),
});

export const insertRoadMemberSchema = createInsertSchema(roadMembers).omit({ id: true });
export type InsertRoadMember = z.infer<typeof insertRoadMemberSchema>;
export type RoadMember = typeof roadMembers.$inferSelect;

// Association Member Roles
export type MemberRole = 'presidente' | 'vice_presidente' | 'tesoureiro' | 'secretario' | 'fiscal' | 'membro';

// Associations (Associações de Vicinais)
export const associations = pgTable("associations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vicinalId: varchar("vicinal_id").notNull(),
  nome: text("nome").notNull(),
  cnpj: text("cnpj"),
  descricao: text("descricao"),
  dataFundacao: text("data_fundacao"),
  endereco: text("endereco"),
  telefone: text("telefone"),
  email: text("email"),
  pixKey: text("pix_key"),
  bankInfo: text("bank_info"),
  createdAt: text("created_at").notNull(),
});

export const insertAssociationSchema = createInsertSchema(associations).omit({ id: true });
export type InsertAssociation = z.infer<typeof insertAssociationSchema>;
export type Association = typeof associations.$inferSelect;

// Association Members
export const associationMembers = pgTable("association_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  associationId: varchar("association_id").notNull(),
  userId: varchar("user_id").notNull(),
  role: text("role").notNull().$type<MemberRole>().default('membro'),
  joinedAt: text("joined_at").notNull(),
  isActive: boolean("is_active").default(true),
});

export const insertMemberSchema = createInsertSchema(associationMembers).omit({ id: true });
export type InsertMember = z.infer<typeof insertMemberSchema>;
export type AssociationMember = typeof associationMembers.$inferSelect;

// Project Types and Status
export type ProjectType = 'construcao' | 'manutencao' | 'infraestrutura' | 'servico' | 'outro';
export type ProjectStatus = 'proposta' | 'aprovado' | 'em_arrecadacao' | 'em_execucao' | 'concluido' | 'cancelado';

// Projects (Projetos Comunitários)
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  associationId: varchar("association_id").notNull(),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  tipo: text("tipo").notNull().$type<ProjectType>(),
  status: text("status").notNull().$type<ProjectStatus>().default('proposta'),
  orcamento: real("orcamento").notNull(),
  arrecadado: real("arrecadado").default(0),
  metaArrecadacao: real("meta_arrecadacao"),
  prazoInicio: text("prazo_inicio"),
  prazoConclusao: text("prazo_conclusao"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  fotos: text("fotos").array(),
  createdBy: varchar("created_by").notNull(),
  createdAt: text("created_at").notNull(),
  approvedAt: text("approved_at"),
  approvedBy: varchar("approved_by"),
  completedAt: text("completed_at"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, arrecadado: true, approvedAt: true, approvedBy: true, completedAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Transaction Types
export type TransactionType = 'contribuicao' | 'mensalidade' | 'doacao' | 'despesa' | 'pagamento_servico' | 'compra_material';

// Financial Transactions (Movimentações Financeiras)
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  associationId: varchar("association_id").notNull(),
  projectId: varchar("project_id"),
  tipo: text("tipo").notNull().$type<TransactionType>(),
  valor: real("valor").notNull(),
  descricao: text("descricao").notNull(),
  categoria: text("categoria"),
  comprovante: text("comprovante"),
  userId: varchar("user_id"),
  userName: text("user_name"),
  createdAt: text("created_at").notNull(),
  registeredBy: varchar("registered_by").notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// Project Contributions (Contribuições para Projetos)
export const contributions = pgTable("contributions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  userId: varchar("user_id"),
  userName: text("user_name").notNull(),
  valor: real("valor").notNull(),
  metodoPagamento: text("metodo_pagamento"),
  comprovante: text("comprovante"),
  isAnonymous: boolean("is_anonymous").default(false),
  createdAt: text("created_at").notNull(),
  registeredBy: varchar("registered_by").notNull(),
});

export const insertContributionSchema = createInsertSchema(contributions).omit({ id: true });
export type InsertContribution = z.infer<typeof insertContributionSchema>;
export type Contribution = typeof contributions.$inferSelect;

// Service Provider Types
export type ServiceCategory = 'trator_grade' | 'escavadeira' | 'patrol' | 'cacamba' | 'pipa_agua' | 'eletricista' | 'mecanico' | 'transporte' | 'construcao' | 'outro';
export type ProviderType = 'empresa' | 'autonomo';

// Service Providers (Prestadores de Serviço)
export const serviceProviders = pgTable("service_providers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  nome: text("nome").notNull(),
  tipo: text("tipo").notNull().$type<ProviderType>(),
  cnpjCpf: text("cnpj_cpf"),
  telefone: text("telefone").notNull(),
  whatsapp: text("whatsapp"),
  email: text("email"),
  descricao: text("descricao"),
  foto: text("foto"),
  endereco: text("endereco"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  isActive: boolean("is_active").default(true),
  createdAt: text("created_at").notNull(),
});

export const insertServiceProviderSchema = createInsertSchema(serviceProviders).omit({ id: true });
export type InsertServiceProvider = z.infer<typeof insertServiceProviderSchema>;
export type ServiceProvider = typeof serviceProviders.$inferSelect;

// Provider Services (Serviços oferecidos)
export const providerServices = pgTable("provider_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").notNull(),
  categoria: text("categoria").notNull().$type<ServiceCategory>(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  precoMinimo: real("preco_minimo"),
  precoMaximo: real("preco_maximo"),
  unidadePreco: text("unidade_preco"),
  equipamento: text("equipamento"),
});

export const insertProviderServiceSchema = createInsertSchema(providerServices).omit({ id: true });
export type InsertProviderService = z.infer<typeof insertProviderServiceSchema>;
export type ProviderService = typeof providerServices.$inferSelect;

// Provider Coverage (Regiões atendidas)
export const providerCoverage = pgTable("provider_coverage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").notNull(),
  vicinalId: varchar("vicinal_id").notNull(),
});

export const insertProviderCoverageSchema = createInsertSchema(providerCoverage).omit({ id: true });
export type InsertProviderCoverage = z.infer<typeof insertProviderCoverageSchema>;
export type ProviderCoverage = typeof providerCoverage.$inferSelect;

// Provider Availability (Disponibilidade)
export const providerAvailability = pgTable("provider_availability", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").notNull(),
  diaSemana: integer("dia_semana"),
  horaInicio: text("hora_inicio"),
  horaFim: text("hora_fim"),
  disponivel: boolean("disponivel").default(true),
  observacao: text("observacao"),
});

export const insertProviderAvailabilitySchema = createInsertSchema(providerAvailability).omit({ id: true });
export type InsertProviderAvailability = z.infer<typeof insertProviderAvailabilitySchema>;
export type ProviderAvailability = typeof providerAvailability.$inferSelect;

// Point Action Types
export type PointActionType = 'limpeza_rede' | 'bom_vizinho' | 'contribuicao_trabalho' | 'contribuicao_financeira' | 'relato_ocorrencia' | 'resolucao_ocorrencia' | 'participacao_projeto' | 'outro';

// User Points (Pontuação dos Usuários)
export const userPoints = pgTable("user_points", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  totalPontos: integer("total_pontos").default(0),
  pontosDoMes: integer("pontos_do_mes").default(0),
  nivel: integer("nivel").default(1),
  updatedAt: text("updated_at").notNull(),
});

export const insertUserPointsSchema = createInsertSchema(userPoints).omit({ id: true });
export type InsertUserPoints = z.infer<typeof insertUserPointsSchema>;
export type UserPoints = typeof userPoints.$inferSelect;

// Point Events (Histórico de Pontos)
export const pointEvents = pgTable("point_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  tipoAcao: text("tipo_acao").notNull().$type<PointActionType>(),
  pontos: integer("pontos").notNull(),
  descricao: text("descricao").notNull(),
  referenceId: varchar("reference_id"),
  referenceType: text("reference_type"),
  awardedBy: varchar("awarded_by"),
  createdAt: text("created_at").notNull(),
});

export const insertPointEventSchema = createInsertSchema(pointEvents).omit({ id: true });
export type InsertPointEvent = z.infer<typeof insertPointEventSchema>;
export type PointEvent = typeof pointEvents.$inferSelect;

// Point Rules (Regras de Pontuação)
export const pointRules = pgTable("point_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tipoAcao: text("tipo_acao").notNull().$type<PointActionType>(),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  pontosBase: integer("pontos_base").notNull(),
  isActive: boolean("is_active").default(true),
});

export const insertPointRuleSchema = createInsertSchema(pointRules).omit({ id: true });
export type InsertPointRule = z.infer<typeof insertPointRuleSchema>;
export type PointRule = typeof pointRules.$inferSelect;

// Fiscalization Alert Types
export type AlertType = 'ibama' | 'icmbio' | 'policia_ambiental' | 'sema' | 'outro';
export type AlertStatus = 'active' | 'expired' | 'cancelled';

// Fiscalization Alerts (Alertas de Fiscalização)
export const fiscalizationAlerts = pgTable("fiscalization_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vicinalId: varchar("vicinal_id").notNull(),
  userId: varchar("user_id").notNull(),
  tipo: text("tipo").notNull().$type<AlertType>(),
  descricao: text("descricao"),
  direcao: text("direcao"),
  veiculos: text("veiculos"),
  status: text("status").notNull().$type<AlertStatus>().default('active'),
  latitude: real("latitude"),
  longitude: real("longitude"),
  expiresAt: text("expires_at").notNull(),
  createdAt: text("created_at").notNull(),
  cancelledAt: text("cancelled_at"),
  cancelledBy: varchar("cancelled_by"),
});

export const insertFiscalizationAlertSchema = createInsertSchema(fiscalizationAlerts).omit({ id: true, cancelledAt: true, cancelledBy: true });
export type InsertFiscalizationAlert = z.infer<typeof insertFiscalizationAlertSchema>;
export type FiscalizationAlert = typeof fiscalizationAlerts.$inferSelect;

// Government Demand Types
export type DemandCategory = 'infraestrutura' | 'saude' | 'educacao' | 'seguranca' | 'agricultura' | 'meio_ambiente' | 'transporte' | 'outro';
export type DemandStatus = 'pendente' | 'em_analise' | 'aprovado' | 'em_execucao' | 'concluido' | 'negado';
export type DemandPriority = 'baixa' | 'media' | 'alta' | 'urgente';

// Government Demands (Demandas para Prefeitura)
export const governmentDemands = pgTable("government_demands", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vicinalId: varchar("vicinal_id").notNull(),
  userId: varchar("user_id").notNull(),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  categoria: text("categoria").notNull().$type<DemandCategory>(),
  prioridade: text("prioridade").notNull().$type<DemandPriority>().default('media'),
  status: text("status").notNull().$type<DemandStatus>().default('pendente'),
  latitude: real("latitude"),
  longitude: real("longitude"),
  fotos: text("fotos").array(),
  populacaoAfetada: integer("populacao_afetada"),
  orcamentoEstimado: real("orcamento_estimado"),
  petitionId: varchar("petition_id"),
  signatureCount: integer("signature_count").default(0),
  responseGoverno: text("response_governo"),
  responsavelGoverno: text("responsavel_governo"),
  prazoResposta: text("prazo_resposta"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at"),
});

export const insertGovernmentDemandSchema = createInsertSchema(governmentDemands).omit({ id: true, responseGoverno: true, responsavelGoverno: true, updatedAt: true });
export type InsertGovernmentDemand = z.infer<typeof insertGovernmentDemandSchema>;
export type GovernmentDemand = typeof governmentDemands.$inferSelect;

// Government Projects (Projetos do Governo/Prefeitura)
export type GovProjectStatus = 'planejado' | 'licitacao' | 'em_execucao' | 'paralisado' | 'concluido' | 'cancelado';

export const governmentProjects = pgTable("government_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  descricao: text("descricao").notNull(),
  orgaoResponsavel: text("orgao_responsavel").notNull(),
  status: text("status").notNull().$type<GovProjectStatus>().default('planejado'),
  orcamento: real("orcamento"),
  prazoInicio: text("prazo_inicio"),
  prazoConclusao: text("prazo_conclusao"),
  percentualConcluido: integer("percentual_concluido").default(0),
  vicinalIds: text("vicinal_ids").array(),
  latitude: real("latitude"),
  longitude: real("longitude"),
  fotos: text("fotos").array(),
  responsavelNome: text("responsavel_nome"),
  responsavelContato: text("responsavel_contato"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at"),
});

export const insertGovernmentProjectSchema = createInsertSchema(governmentProjects).omit({ id: true, updatedAt: true });
export type InsertGovernmentProject = z.infer<typeof insertGovernmentProjectSchema>;
export type GovernmentProject = typeof governmentProjects.$inferSelect;
