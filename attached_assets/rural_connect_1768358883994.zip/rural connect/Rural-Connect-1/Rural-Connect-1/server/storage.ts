import { 
  users, vicinais, occurrences, petitions, signatures, roads, roadMembers,
  occurrenceHistory, occurrenceComments,
  associations, associationMembers, projects, transactions, contributions,
  serviceProviders, providerServices, providerCoverage, providerAvailability,
  userPoints, pointEvents, pointRules,
  fiscalizationAlerts, governmentDemands, governmentProjects,
  type User, type InsertUser,
  type Vicinal, type InsertVicinal,
  type Occurrence, type InsertOccurrence,
  type Petition, type InsertPetition,
  type Signature, type InsertSignature,
  type Road, type InsertRoad,
  type RoadMember, type InsertRoadMember,
  type OccurrenceHistory, type OccurrenceComment, type InsertComment,
  type Association, type InsertAssociation,
  type AssociationMember, type InsertMember,
  type Project, type InsertProject,
  type Transaction, type InsertTransaction,
  type Contribution, type InsertContribution,
  type ServiceProvider, type InsertServiceProvider,
  type ProviderService, type InsertProviderService,
  type ProviderCoverage, type InsertProviderCoverage,
  type ProviderAvailability, type InsertProviderAvailability,
  type UserPoints, type InsertUserPoints,
  type PointEvent, type InsertPointEvent,
  type PointRule, type InsertPointRule,
  type FiscalizationAlert, type InsertFiscalizationAlert,
  type GovernmentDemand, type InsertGovernmentDemand,
  type GovernmentProject, type InsertGovernmentProject
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gt, desc, inArray } from "drizzle-orm";

export interface RoadInsights {
  road: Road;
  association: Association | null;
  membersCount: number;
  propertiesCount: number;
  openOccurrencesCount: number;
  occurrencesBySeverity: { open: number; in_progress: number; resolved: number };
  comprimentoMetros: number;
}

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByCpf(cpf: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  getUsersByVicinal(vicinalId: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;

  // Vicinais
  getVicinal(id: string): Promise<Vicinal | undefined>;
  getVicinais(): Promise<Vicinal[]>;
  createVicinal(vicinal: InsertVicinal): Promise<Vicinal>;
  updateVicinal(id: string, vicinal: Partial<InsertVicinal>): Promise<Vicinal | undefined>;
  deleteVicinal(id: string): Promise<boolean>;

  // Occurrences
  getOccurrence(id: string): Promise<Occurrence | undefined>;
  getOccurrences(): Promise<Occurrence[]>;
  getActiveOccurrences(): Promise<Occurrence[]>;
  getOccurrencesByVicinal(vicinalId: string): Promise<Occurrence[]>;
  createOccurrence(occurrence: InsertOccurrence): Promise<Occurrence>;
  updateOccurrence(id: string, occurrence: Partial<InsertOccurrence>): Promise<Occurrence | undefined>;
  resolveOccurrence(id: string, resolvedBy: string): Promise<boolean>;
  deleteOccurrence(id: string): Promise<boolean>;
  
  // Occurrence History
  getOccurrenceHistory(): Promise<OccurrenceHistory[]>;
  archiveOccurrence(occurrence: Occurrence, reason: string): Promise<OccurrenceHistory>;
  
  // Comments
  getCommentsByOccurrence(occurrenceId: string): Promise<OccurrenceComment[]>;
  createComment(comment: InsertComment): Promise<OccurrenceComment>;

  // Petitions
  getPetition(id: string): Promise<Petition | undefined>;
  getPetitions(): Promise<Petition[]>;
  getPetitionsByVicinal(vicinalId: string): Promise<Petition[]>;
  createPetition(petition: InsertPetition): Promise<Petition>;

  // Signatures
  getSignaturesByPetition(petitionId: string): Promise<Signature[]>;
  createSignature(signature: InsertSignature): Promise<Signature>;
  hasUserSigned(petitionId: string, userId: string): Promise<boolean>;

  // Roads
  getRoad(id: string): Promise<Road | undefined>;
  getRoads(): Promise<Road[]>;
  createRoad(road: InsertRoad): Promise<Road>;
  updateRoad(id: string, road: Partial<Road>): Promise<Road | undefined>;
  deleteRoad(id: string): Promise<boolean>;
  getRoadInsights(roadId: string): Promise<RoadInsights | undefined>;
  
  // Road Members
  getRoadMembers(roadId: string): Promise<RoadMember[]>;
  createRoadMember(member: InsertRoadMember): Promise<RoadMember>;

  // Associations
  getAssociation(id: string): Promise<Association | undefined>;
  getAssociationByVicinal(vicinalId: string): Promise<Association | undefined>;
  getAssociations(): Promise<Association[]>;
  createAssociation(association: InsertAssociation): Promise<Association>;
  updateAssociation(id: string, association: Partial<InsertAssociation>): Promise<Association | undefined>;

  // Association Members
  getMembersByAssociation(associationId: string): Promise<AssociationMember[]>;
  getMemberByUser(associationId: string, userId: string): Promise<AssociationMember | undefined>;
  createMember(member: InsertMember): Promise<AssociationMember>;
  updateMember(id: string, member: Partial<InsertMember>): Promise<AssociationMember | undefined>;
  removeMember(id: string): Promise<boolean>;

  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjectsByAssociation(associationId: string): Promise<Project[]>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<Project>): Promise<Project | undefined>;

  // Transactions
  getTransactionsByAssociation(associationId: string): Promise<Transaction[]>;
  getTransactionsByProject(projectId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Contributions
  getContributionsByProject(projectId: string): Promise<Contribution[]>;
  createContribution(contribution: InsertContribution): Promise<Contribution>;

  // Service Providers
  getServiceProviders(): Promise<ServiceProvider[]>;
  getServiceProvider(id: string): Promise<ServiceProvider | undefined>;
  createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider>;
  updateServiceProvider(id: string, provider: Partial<InsertServiceProvider>): Promise<ServiceProvider | undefined>;
  deleteServiceProvider(id: string): Promise<boolean>;
  getProvidersByVicinal(vicinalId: string): Promise<ServiceProvider[]>;

  // Provider Services
  getProviderServices(providerId: string): Promise<ProviderService[]>;
  createProviderService(service: InsertProviderService): Promise<ProviderService>;
  deleteProviderService(id: string): Promise<boolean>;

  // Provider Coverage
  getProviderCoverage(providerId: string): Promise<ProviderCoverage[]>;
  createProviderCoverage(coverage: InsertProviderCoverage): Promise<ProviderCoverage>;
  deleteProviderCoverage(id: string): Promise<boolean>;

  // Provider Availability
  getProviderAvailability(providerId: string): Promise<ProviderAvailability[]>;
  createProviderAvailability(availability: InsertProviderAvailability): Promise<ProviderAvailability>;
  updateProviderAvailability(id: string, availability: Partial<InsertProviderAvailability>): Promise<ProviderAvailability | undefined>;
  deleteProviderAvailability(id: string): Promise<boolean>;

  // Points System
  getUserPoints(userId: string): Promise<UserPoints | undefined>;
  createUserPoints(points: InsertUserPoints): Promise<UserPoints>;
  updateUserPoints(id: string, points: Partial<InsertUserPoints>): Promise<UserPoints | undefined>;
  getPointEvents(userId: string): Promise<PointEvent[]>;
  createPointEvent(event: InsertPointEvent): Promise<PointEvent>;
  getLeaderboard(limit: number): Promise<UserPoints[]>;
  getPointRules(): Promise<PointRule[]>;
  createPointRule(rule: InsertPointRule): Promise<PointRule>;

  // Fiscalization Alerts
  getFiscalizationAlerts(): Promise<FiscalizationAlert[]>;
  getActiveAlerts(): Promise<FiscalizationAlert[]>;
  getAlertsByVicinal(vicinalId: string): Promise<FiscalizationAlert[]>;
  createFiscalizationAlert(alert: InsertFiscalizationAlert): Promise<FiscalizationAlert>;
  cancelAlert(id: string, cancelledBy: string): Promise<boolean>;

  // Government Demands
  getGovernmentDemands(): Promise<GovernmentDemand[]>;
  getGovernmentDemand(id: string): Promise<GovernmentDemand | undefined>;
  getDemandsByVicinal(vicinalId: string): Promise<GovernmentDemand[]>;
  createGovernmentDemand(demand: InsertGovernmentDemand): Promise<GovernmentDemand>;
  updateGovernmentDemand(id: string, demand: Partial<GovernmentDemand>): Promise<GovernmentDemand | undefined>;

  // Government Projects
  getGovernmentProjects(): Promise<GovernmentProject[]>;
  getGovernmentProject(id: string): Promise<GovernmentProject | undefined>;
  createGovernmentProject(project: InsertGovernmentProject): Promise<GovernmentProject>;
  updateGovernmentProject(id: string, project: Partial<GovernmentProject>): Promise<GovernmentProject | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByCpf(cpf: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.cpf, cpf));
    return user || undefined;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByVicinal(vicinalId: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.vicinalId, vicinalId));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(userData).where(eq(users.id, id)).returning();
    return user || undefined;
  }

  // Vicinais
  async getVicinal(id: string): Promise<Vicinal | undefined> {
    const [vicinal] = await db.select().from(vicinais).where(eq(vicinais.id, id));
    return vicinal || undefined;
  }

  async getVicinais(): Promise<Vicinal[]> {
    return await db.select().from(vicinais);
  }

  async createVicinal(insertVicinal: InsertVicinal): Promise<Vicinal> {
    const [vicinal] = await db.insert(vicinais).values(insertVicinal).returning();
    return vicinal;
  }

  async updateVicinal(id: string, vicinalData: Partial<InsertVicinal>): Promise<Vicinal | undefined> {
    const [vicinal] = await db.update(vicinais).set(vicinalData).where(eq(vicinais.id, id)).returning();
    return vicinal || undefined;
  }

  async deleteVicinal(id: string): Promise<boolean> {
    await db.delete(vicinais).where(eq(vicinais.id, id));
    return true;
  }

  // Occurrences
  async getOccurrence(id: string): Promise<Occurrence | undefined> {
    const [occurrence] = await db.select().from(occurrences).where(eq(occurrences.id, id));
    return occurrence || undefined;
  }

  async getOccurrences(): Promise<Occurrence[]> {
    return await db.select().from(occurrences);
  }

  async getOccurrencesByVicinal(vicinalId: string): Promise<Occurrence[]> {
    return await db.select().from(occurrences).where(eq(occurrences.vicinalId, vicinalId));
  }

  async createOccurrence(insertOccurrence: InsertOccurrence): Promise<Occurrence> {
    const [occurrence] = await db.insert(occurrences).values(insertOccurrence as any).returning();
    return occurrence;
  }

  async updateOccurrence(id: string, occurrenceData: Partial<InsertOccurrence>): Promise<Occurrence | undefined> {
    const [occurrence] = await db.update(occurrences).set(occurrenceData as any).where(eq(occurrences.id, id)).returning();
    return occurrence || undefined;
  }

  async getActiveOccurrences(): Promise<Occurrence[]> {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const allOccurrences = await db.select().from(occurrences);
    return allOccurrences.filter(o => {
      const createdDate = new Date(o.createdAt);
      return createdDate > oneWeekAgo && o.status !== 'resolved';
    });
  }

  async resolveOccurrence(id: string, resolvedBy: string): Promise<boolean> {
    const occurrence = await this.getOccurrence(id);
    if (!occurrence) return false;
    
    await this.archiveOccurrence(occurrence, 'resolved');
    await db.delete(occurrences).where(eq(occurrences.id, id));
    return true;
  }

  async deleteOccurrence(id: string): Promise<boolean> {
    await db.delete(occurrences).where(eq(occurrences.id, id));
    return true;
  }

  // Occurrence History
  async getOccurrenceHistory(): Promise<OccurrenceHistory[]> {
    return await db.select().from(occurrenceHistory);
  }

  async archiveOccurrence(occurrence: Occurrence, reason: string): Promise<OccurrenceHistory> {
    const [archived] = await db.insert(occurrenceHistory).values({
      originalId: occurrence.id,
      titulo: occurrence.titulo,
      descricao: occurrence.descricao,
      tipo: occurrence.tipo,
      vicinalId: occurrence.vicinalId,
      userId: occurrence.userId,
      latitude: occurrence.latitude,
      longitude: occurrence.longitude,
      fotos: occurrence.fotos,
      createdAt: occurrence.createdAt,
      resolvedAt: occurrence.resolvedAt,
      resolvedBy: occurrence.resolvedBy,
      archivedAt: new Date().toISOString(),
      archiveReason: reason,
    }).returning();
    return archived;
  }

  // Comments
  async getCommentsByOccurrence(occurrenceId: string): Promise<OccurrenceComment[]> {
    return await db.select().from(occurrenceComments).where(eq(occurrenceComments.occurrenceId, occurrenceId));
  }

  async createComment(insertComment: InsertComment): Promise<OccurrenceComment> {
    const [comment] = await db.insert(occurrenceComments).values(insertComment).returning();
    return comment;
  }

  // Petitions
  async getPetition(id: string): Promise<Petition | undefined> {
    const [petition] = await db.select().from(petitions).where(eq(petitions.id, id));
    return petition || undefined;
  }

  async getPetitions(): Promise<Petition[]> {
    return await db.select().from(petitions);
  }

  async getPetitionsByVicinal(vicinalId: string): Promise<Petition[]> {
    return await db.select().from(petitions).where(eq(petitions.vicinalId, vicinalId));
  }

  async createPetition(insertPetition: InsertPetition): Promise<Petition> {
    const [petition] = await db.insert(petitions).values(insertPetition).returning();
    return petition;
  }

  // Signatures
  async getSignaturesByPetition(petitionId: string): Promise<Signature[]> {
    return await db.select().from(signatures).where(eq(signatures.petitionId, petitionId));
  }

  async createSignature(insertSignature: InsertSignature): Promise<Signature> {
    const [signature] = await db.insert(signatures).values(insertSignature).returning();
    return signature;
  }

  async hasUserSigned(petitionId: string, userId: string): Promise<boolean> {
    const [signature] = await db.select().from(signatures)
      .where(and(eq(signatures.petitionId, petitionId), eq(signatures.userId, userId)));
    return !!signature;
  }

  // Roads
  async getRoad(id: string): Promise<Road | undefined> {
    const [road] = await db.select().from(roads).where(eq(roads.id, id));
    return road || undefined;
  }

  async getRoads(): Promise<Road[]> {
    return await db.select().from(roads);
  }

  async createRoad(insertRoad: InsertRoad): Promise<Road> {
    const [road] = await db.insert(roads).values(insertRoad as any).returning();
    return road;
  }

  async updateRoad(id: string, roadData: Partial<Road>): Promise<Road | undefined> {
    const [road] = await db.update(roads).set(roadData as any).where(eq(roads.id, id)).returning();
    return road || undefined;
  }

  async deleteRoad(id: string): Promise<boolean> {
    const result = await db.delete(roads).where(eq(roads.id, id));
    return true;
  }

  async getRoadInsights(roadId: string): Promise<RoadInsights | undefined> {
    const road = await this.getRoad(roadId);
    if (!road) return undefined;

    let association: Association | null = null;
    if (road.associationId) {
      association = await this.getAssociation(road.associationId) || null;
    }

    const members = await this.getRoadMembers(roadId);
    const membersCount = members.length;
    const propertiesCount = members.length;

    const allOccurrences = await db.select().from(occurrences).where(eq(occurrences.roadId, roadId));
    const openOccurrencesCount = allOccurrences.filter(o => o.status === 'open').length;
    const occurrencesBySeverity = {
      open: allOccurrences.filter(o => o.status === 'open').length,
      in_progress: allOccurrences.filter(o => o.status === 'in_progress').length,
      resolved: allOccurrences.filter(o => o.status === 'resolved').length,
    };

    // Compute road length from coordinates if not cached
    let comprimentoMetros = road.comprimentoMetros || 0;
    if (!road.comprimentoMetros && road.coordinates) {
      comprimentoMetros = this.calculateRoadLength(road.coordinates);
    }

    return {
      road,
      association,
      membersCount,
      propertiesCount,
      openOccurrencesCount,
      occurrencesBySeverity,
      comprimentoMetros,
    };
  }

  // Calculate road length in meters using Haversine formula
  private calculateRoadLength(coordinatesJson: string): number {
    try {
      const coords: [number, number][] = JSON.parse(coordinatesJson);
      if (coords.length < 2) return 0;

      let totalDistance = 0;
      for (let i = 0; i < coords.length - 1; i++) {
        const [lat1, lng1] = coords[i];
        const [lat2, lng2] = coords[i + 1];
        totalDistance += this.haversineDistance(lat1, lng1, lat2, lng2);
      }
      return Math.round(totalDistance);
    } catch {
      return 0;
    }
  }

  private haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371000; // Earth radius in meters
    const toRad = (deg: number) => (deg * Math.PI) / 180;
    
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLng / 2) * Math.sin(dLng / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  // Road Members
  async getRoadMembers(roadId: string): Promise<RoadMember[]> {
    return await db.select().from(roadMembers).where(eq(roadMembers.roadId, roadId));
  }

  async createRoadMember(insertRoadMember: InsertRoadMember): Promise<RoadMember> {
    const [member] = await db.insert(roadMembers).values(insertRoadMember as any).returning();
    return member;
  }

  // Associations
  async getAssociation(id: string): Promise<Association | undefined> {
    const [association] = await db.select().from(associations).where(eq(associations.id, id));
    return association || undefined;
  }

  async getAssociationByVicinal(vicinalId: string): Promise<Association | undefined> {
    const [association] = await db.select().from(associations).where(eq(associations.vicinalId, vicinalId));
    return association || undefined;
  }

  async getAssociations(): Promise<Association[]> {
    return await db.select().from(associations);
  }

  async createAssociation(insertAssociation: InsertAssociation): Promise<Association> {
    const [association] = await db.insert(associations).values(insertAssociation).returning();
    return association;
  }

  async updateAssociation(id: string, associationData: Partial<InsertAssociation>): Promise<Association | undefined> {
    const [association] = await db.update(associations).set(associationData).where(eq(associations.id, id)).returning();
    return association || undefined;
  }

  // Association Members
  async getMembersByAssociation(associationId: string): Promise<AssociationMember[]> {
    return await db.select().from(associationMembers).where(eq(associationMembers.associationId, associationId));
  }

  async getMemberByUser(associationId: string, userId: string): Promise<AssociationMember | undefined> {
    const [member] = await db.select().from(associationMembers)
      .where(and(eq(associationMembers.associationId, associationId), eq(associationMembers.userId, userId)));
    return member || undefined;
  }

  async createMember(insertMember: InsertMember): Promise<AssociationMember> {
    const [member] = await db.insert(associationMembers).values(insertMember as any).returning();
    return member;
  }

  async updateMember(id: string, memberData: Partial<InsertMember>): Promise<AssociationMember | undefined> {
    const [member] = await db.update(associationMembers).set(memberData as any).where(eq(associationMembers.id, id)).returning();
    return member || undefined;
  }

  async removeMember(id: string): Promise<boolean> {
    await db.delete(associationMembers).where(eq(associationMembers.id, id));
    return true;
  }

  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async getProjectsByAssociation(associationId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.associationId, associationId));
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject as any).returning();
    return project;
  }

  async updateProject(id: string, projectData: Partial<Project>): Promise<Project | undefined> {
    const [project] = await db.update(projects).set(projectData).where(eq(projects.id, id)).returning();
    return project || undefined;
  }

  // Transactions
  async getTransactionsByAssociation(associationId: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(eq(transactions.associationId, associationId))
      .orderBy(desc(transactions.createdAt));
  }

  async getTransactionsByProject(projectId: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(eq(transactions.projectId, projectId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(insertTransaction as any).returning();
    return transaction;
  }

  // Contributions
  async getContributionsByProject(projectId: string): Promise<Contribution[]> {
    return await db.select().from(contributions)
      .where(eq(contributions.projectId, projectId))
      .orderBy(desc(contributions.createdAt));
  }

  async createContribution(insertContribution: InsertContribution): Promise<Contribution> {
    const [contribution] = await db.insert(contributions).values(insertContribution).returning();
    
    // Update project arrecadado amount
    const project = await this.getProject(insertContribution.projectId);
    if (project) {
      const newTotal = (project.arrecadado || 0) + insertContribution.valor;
      await this.updateProject(insertContribution.projectId, { arrecadado: newTotal });
    }
    
    return contribution;
  }

  // Service Providers
  async getServiceProviders(): Promise<ServiceProvider[]> {
    return await db.select().from(serviceProviders).where(eq(serviceProviders.isActive, true));
  }

  async getServiceProvider(id: string): Promise<ServiceProvider | undefined> {
    const [provider] = await db.select().from(serviceProviders).where(eq(serviceProviders.id, id));
    return provider || undefined;
  }

  async createServiceProvider(insertProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const [provider] = await db.insert(serviceProviders).values(insertProvider as any).returning();
    return provider;
  }

  async updateServiceProvider(id: string, providerData: Partial<InsertServiceProvider>): Promise<ServiceProvider | undefined> {
    const [provider] = await db.update(serviceProviders).set(providerData as any).where(eq(serviceProviders.id, id)).returning();
    return provider || undefined;
  }

  async deleteServiceProvider(id: string): Promise<boolean> {
    await db.delete(serviceProviders).where(eq(serviceProviders.id, id));
    return true;
  }

  async getProvidersByVicinal(vicinalId: string): Promise<ServiceProvider[]> {
    const coverageRecords = await db.select().from(providerCoverage).where(eq(providerCoverage.vicinalId, vicinalId));
    if (coverageRecords.length === 0) return [];
    
    const providerIds = coverageRecords.map(c => c.providerId);
    return await db.select().from(serviceProviders)
      .where(and(inArray(serviceProviders.id, providerIds), eq(serviceProviders.isActive, true)));
  }

  // Provider Services
  async getProviderServices(providerId: string): Promise<ProviderService[]> {
    return await db.select().from(providerServices).where(eq(providerServices.providerId, providerId));
  }

  async createProviderService(insertService: InsertProviderService): Promise<ProviderService> {
    const [service] = await db.insert(providerServices).values(insertService as any).returning();
    return service;
  }

  async deleteProviderService(id: string): Promise<boolean> {
    await db.delete(providerServices).where(eq(providerServices.id, id));
    return true;
  }

  // Provider Coverage
  async getProviderCoverage(providerId: string): Promise<ProviderCoverage[]> {
    return await db.select().from(providerCoverage).where(eq(providerCoverage.providerId, providerId));
  }

  async createProviderCoverage(insertCoverage: InsertProviderCoverage): Promise<ProviderCoverage> {
    const [coverage] = await db.insert(providerCoverage).values(insertCoverage).returning();
    return coverage;
  }

  async deleteProviderCoverage(id: string): Promise<boolean> {
    await db.delete(providerCoverage).where(eq(providerCoverage.id, id));
    return true;
  }

  // Provider Availability
  async getProviderAvailability(providerId: string): Promise<ProviderAvailability[]> {
    return await db.select().from(providerAvailability).where(eq(providerAvailability.providerId, providerId));
  }

  async createProviderAvailability(insertAvailability: InsertProviderAvailability): Promise<ProviderAvailability> {
    const [availability] = await db.insert(providerAvailability).values(insertAvailability).returning();
    return availability;
  }

  async updateProviderAvailability(id: string, availabilityData: Partial<InsertProviderAvailability>): Promise<ProviderAvailability | undefined> {
    const [availability] = await db.update(providerAvailability).set(availabilityData).where(eq(providerAvailability.id, id)).returning();
    return availability || undefined;
  }

  async deleteProviderAvailability(id: string): Promise<boolean> {
    await db.delete(providerAvailability).where(eq(providerAvailability.id, id));
    return true;
  }

  // Points System
  async getUserPoints(userId: string): Promise<UserPoints | undefined> {
    const [points] = await db.select().from(userPoints).where(eq(userPoints.userId, userId));
    return points || undefined;
  }

  async createUserPoints(insertPoints: InsertUserPoints): Promise<UserPoints> {
    const [points] = await db.insert(userPoints).values(insertPoints).returning();
    return points;
  }

  async updateUserPoints(id: string, pointsData: Partial<InsertUserPoints>): Promise<UserPoints | undefined> {
    const [points] = await db.update(userPoints).set(pointsData).where(eq(userPoints.id, id)).returning();
    return points || undefined;
  }

  async getPointEvents(userId: string): Promise<PointEvent[]> {
    return await db.select().from(pointEvents).where(eq(pointEvents.userId, userId)).orderBy(desc(pointEvents.createdAt));
  }

  async createPointEvent(insertEvent: InsertPointEvent): Promise<PointEvent> {
    const [event] = await db.insert(pointEvents).values(insertEvent as any).returning();
    return event;
  }

  async getLeaderboard(limit: number): Promise<UserPoints[]> {
    return await db.select().from(userPoints).orderBy(desc(userPoints.totalPontos)).limit(limit);
  }

  async getPointRules(): Promise<PointRule[]> {
    return await db.select().from(pointRules).where(eq(pointRules.isActive, true));
  }

  async createPointRule(insertRule: InsertPointRule): Promise<PointRule> {
    const [rule] = await db.insert(pointRules).values(insertRule as any).returning();
    return rule;
  }

  // Fiscalization Alerts
  async getFiscalizationAlerts(): Promise<FiscalizationAlert[]> {
    return await db.select().from(fiscalizationAlerts).orderBy(desc(fiscalizationAlerts.createdAt));
  }

  async getActiveAlerts(): Promise<FiscalizationAlert[]> {
    const now = new Date().toISOString();
    const all = await db.select().from(fiscalizationAlerts).where(eq(fiscalizationAlerts.status, 'active'));
    return all.filter(a => a.expiresAt > now);
  }

  async getAlertsByVicinal(vicinalId: string): Promise<FiscalizationAlert[]> {
    return await db.select().from(fiscalizationAlerts).where(eq(fiscalizationAlerts.vicinalId, vicinalId)).orderBy(desc(fiscalizationAlerts.createdAt));
  }

  async createFiscalizationAlert(insertAlert: InsertFiscalizationAlert): Promise<FiscalizationAlert> {
    const [alert] = await db.insert(fiscalizationAlerts).values(insertAlert as any).returning();
    return alert;
  }

  async cancelAlert(id: string, cancelledBy: string): Promise<boolean> {
    await db.update(fiscalizationAlerts).set({ 
      status: 'cancelled', 
      cancelledAt: new Date().toISOString(), 
      cancelledBy 
    }).where(eq(fiscalizationAlerts.id, id));
    return true;
  }

  // Government Demands
  async getGovernmentDemands(): Promise<GovernmentDemand[]> {
    return await db.select().from(governmentDemands).orderBy(desc(governmentDemands.createdAt));
  }

  async getGovernmentDemand(id: string): Promise<GovernmentDemand | undefined> {
    const [demand] = await db.select().from(governmentDemands).where(eq(governmentDemands.id, id));
    return demand || undefined;
  }

  async getDemandsByVicinal(vicinalId: string): Promise<GovernmentDemand[]> {
    return await db.select().from(governmentDemands).where(eq(governmentDemands.vicinalId, vicinalId)).orderBy(desc(governmentDemands.createdAt));
  }

  async createGovernmentDemand(insertDemand: InsertGovernmentDemand): Promise<GovernmentDemand> {
    const [demand] = await db.insert(governmentDemands).values(insertDemand as any).returning();
    return demand;
  }

  async updateGovernmentDemand(id: string, demandData: Partial<GovernmentDemand>): Promise<GovernmentDemand | undefined> {
    const [demand] = await db.update(governmentDemands).set({ ...demandData, updatedAt: new Date().toISOString() } as any).where(eq(governmentDemands.id, id)).returning();
    return demand || undefined;
  }

  // Government Projects
  async getGovernmentProjects(): Promise<GovernmentProject[]> {
    return await db.select().from(governmentProjects).orderBy(desc(governmentProjects.createdAt));
  }

  async getGovernmentProject(id: string): Promise<GovernmentProject | undefined> {
    const [project] = await db.select().from(governmentProjects).where(eq(governmentProjects.id, id));
    return project || undefined;
  }

  async createGovernmentProject(insertProject: InsertGovernmentProject): Promise<GovernmentProject> {
    const [project] = await db.insert(governmentProjects).values(insertProject as any).returning();
    return project;
  }

  async updateGovernmentProject(id: string, projectData: Partial<GovernmentProject>): Promise<GovernmentProject | undefined> {
    const [project] = await db.update(governmentProjects).set({ ...projectData, updatedAt: new Date().toISOString() } as any).where(eq(governmentProjects.id, id)).returning();
    return project || undefined;
  }
}

export const storage = new DatabaseStorage();
