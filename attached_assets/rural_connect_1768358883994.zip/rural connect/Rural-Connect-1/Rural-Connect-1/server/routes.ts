import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertVicinalSchema, 
  insertOccurrenceSchema,
  insertPetitionSchema,
  insertSignatureSchema,
  insertRoadSchema,
  insertRoadMemberSchema,
  insertCommentSchema,
  insertAssociationSchema,
  insertMemberSchema,
  insertProjectSchema,
  insertTransactionSchema,
  insertContributionSchema,
  insertServiceProviderSchema,
  insertProviderServiceSchema,
  insertProviderCoverageSchema,
  insertProviderAvailabilitySchema,
  insertUserPointsSchema,
  insertPointEventSchema,
  insertPointRuleSchema,
  insertFiscalizationAlertSchema,
  insertGovernmentDemandSchema,
  insertGovernmentProjectSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ============ USERS ============
  
  // Get all users
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Create user
  app.post("/api/users", async (req, res) => {
    try {
      const parsed = insertUserSchema.parse(req.body);
      const user = await storage.createUser(parsed);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  // Update user
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // ============ VICINAIS ============
  
  // Get all vicinais
  app.get("/api/vicinais", async (req, res) => {
    try {
      const vicinais = await storage.getVicinais();
      res.json(vicinais);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vicinais" });
    }
  });

  // Get vicinal by ID
  app.get("/api/vicinais/:id", async (req, res) => {
    try {
      const vicinal = await storage.getVicinal(req.params.id);
      if (!vicinal) {
        return res.status(404).json({ error: "Vicinal not found" });
      }
      res.json(vicinal);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vicinal" });
    }
  });

  // Create vicinal
  app.post("/api/vicinais", async (req, res) => {
    try {
      const parsed = insertVicinalSchema.parse(req.body);
      const vicinal = await storage.createVicinal(parsed);
      res.status(201).json(vicinal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create vicinal" });
    }
  });

  // Update vicinal
  app.patch("/api/vicinais/:id", async (req, res) => {
    try {
      const vicinal = await storage.updateVicinal(req.params.id, req.body);
      if (!vicinal) {
        return res.status(404).json({ error: "Vicinal not found" });
      }
      res.json(vicinal);
    } catch (error) {
      res.status(500).json({ error: "Failed to update vicinal" });
    }
  });

  // Delete vicinal
  app.delete("/api/vicinais/:id", async (req, res) => {
    try {
      await storage.deleteVicinal(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vicinal" });
    }
  });

  // ============ OCCURRENCES ============
  
  // Get all occurrences
  app.get("/api/occurrences", async (req, res) => {
    try {
      const vicinalId = req.query.vicinalId as string | undefined;
      let occurrences;
      if (vicinalId) {
        occurrences = await storage.getOccurrencesByVicinal(vicinalId);
      } else {
        occurrences = await storage.getOccurrences();
      }
      res.json(occurrences);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch occurrences" });
    }
  });

  // Get occurrence by ID
  app.get("/api/occurrences/:id", async (req, res) => {
    try {
      const occurrence = await storage.getOccurrence(req.params.id);
      if (!occurrence) {
        return res.status(404).json({ error: "Occurrence not found" });
      }
      res.json(occurrence);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch occurrence" });
    }
  });

  // Create occurrence
  app.post("/api/occurrences", async (req, res) => {
    try {
      const parsed = insertOccurrenceSchema.parse(req.body);
      const occurrence = await storage.createOccurrence(parsed);
      res.status(201).json(occurrence);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create occurrence" });
    }
  });

  // Update occurrence
  app.patch("/api/occurrences/:id", async (req, res) => {
    try {
      const allowedFields = ['titulo', 'descricao', 'tipo', 'vicinalId', 'latitude', 'longitude', 'fotos', 'status'];
      const sanitizedData: Record<string, any> = {};
      for (const key of allowedFields) {
        if (req.body[key] !== undefined) {
          sanitizedData[key] = req.body[key];
        }
      }
      const occurrence = await storage.updateOccurrence(req.params.id, sanitizedData);
      if (!occurrence) {
        return res.status(404).json({ error: "Occurrence not found" });
      }
      res.json(occurrence);
    } catch (error) {
      res.status(500).json({ error: "Failed to update occurrence" });
    }
  });

  // Delete occurrence
  app.delete("/api/occurrences/:id", async (req, res) => {
    try {
      await storage.deleteOccurrence(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete occurrence" });
    }
  });

  // Resolve occurrence (archive and delete)
  app.post("/api/occurrences/:id/resolve", async (req, res) => {
    try {
      const { resolvedBy } = req.body;
      const success = await storage.resolveOccurrence(req.params.id, resolvedBy || "anonymous");
      if (!success) {
        return res.status(404).json({ error: "Occurrence not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to resolve occurrence" });
    }
  });

  // Get occurrence comments
  app.get("/api/occurrences/:id/comments", async (req, res) => {
    try {
      const comments = await storage.getCommentsByOccurrence(req.params.id);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  // Add comment to occurrence
  app.post("/api/occurrences/:id/comments", async (req, res) => {
    try {
      const parsed = insertCommentSchema.parse({
        ...req.body,
        occurrenceId: req.params.id,
        createdAt: new Date().toISOString(),
      });
      const comment = await storage.createComment(parsed);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  // Get occurrence history
  app.get("/api/occurrences/history", async (req, res) => {
    try {
      const history = await storage.getOccurrenceHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch occurrence history" });
    }
  });

  // ============ PETITIONS ============
  
  // Get all petitions
  app.get("/api/petitions", async (req, res) => {
    try {
      const vicinalId = req.query.vicinalId as string | undefined;
      let petitions;
      if (vicinalId) {
        petitions = await storage.getPetitionsByVicinal(vicinalId);
      } else {
        petitions = await storage.getPetitions();
      }
      res.json(petitions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch petitions" });
    }
  });

  // Get petition by ID
  app.get("/api/petitions/:id", async (req, res) => {
    try {
      const petition = await storage.getPetition(req.params.id);
      if (!petition) {
        return res.status(404).json({ error: "Petition not found" });
      }
      res.json(petition);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch petition" });
    }
  });

  // Create petition
  app.post("/api/petitions", async (req, res) => {
    try {
      const parsed = insertPetitionSchema.parse(req.body);
      const petition = await storage.createPetition(parsed);
      res.status(201).json(petition);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create petition" });
    }
  });

  // ============ SIGNATURES ============
  
  // Get signatures for a petition
  app.get("/api/petitions/:petitionId/signatures", async (req, res) => {
    try {
      const signatures = await storage.getSignaturesByPetition(req.params.petitionId);
      res.json(signatures);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch signatures" });
    }
  });

  // Create signature for a petition
  app.post("/api/petitions/:petitionId/signatures", async (req, res) => {
    try {
      const parsed = insertSignatureSchema.parse({
        ...req.body,
        petitionId: req.params.petitionId,
        signedAt: new Date().toISOString(),
      });
      
      // Check if user already signed
      const hasSigned = await storage.hasUserSigned(parsed.petitionId, parsed.userId);
      if (hasSigned) {
        return res.status(400).json({ error: "User already signed this petition" });
      }
      
      const signature = await storage.createSignature(parsed);
      res.status(201).json(signature);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create signature" });
    }
  });

  // ============ ROADS ============
  
  // Get all roads
  app.get("/api/roads", async (req, res) => {
    try {
      const roads = await storage.getRoads();
      res.json(roads);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch roads" });
    }
  });

  // Get road by ID
  app.get("/api/roads/:id", async (req, res) => {
    try {
      const road = await storage.getRoad(req.params.id);
      if (!road) {
        return res.status(404).json({ error: "Road not found" });
      }
      res.json(road);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch road" });
    }
  });

  // Create road
  app.post("/api/roads", async (req, res) => {
    try {
      const parsed = insertRoadSchema.parse(req.body);
      const road = await storage.createRoad(parsed);
      res.status(201).json(road);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create road" });
    }
  });

  // Update road
  app.patch("/api/roads/:id", async (req, res) => {
    try {
      const road = await storage.updateRoad(req.params.id, req.body);
      if (!road) {
        return res.status(404).json({ error: "Road not found" });
      }
      res.json(road);
    } catch (error) {
      res.status(500).json({ error: "Failed to update road" });
    }
  });

  // Delete road
  app.delete("/api/roads/:id", async (req, res) => {
    try {
      await storage.deleteRoad(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete road" });
    }
  });

  // Get road insights
  app.get("/api/roads/:id/insights", async (req, res) => {
    try {
      const insights = await storage.getRoadInsights(req.params.id);
      if (!insights) {
        return res.status(404).json({ error: "Road not found" });
      }
      res.json(insights);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch road insights" });
    }
  });

  // Get road members
  app.get("/api/roads/:id/members", async (req, res) => {
    try {
      const members = await storage.getRoadMembers(req.params.id);
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch road members" });
    }
  });

  // Create road member
  app.post("/api/roads/:id/members", async (req, res) => {
    try {
      const parsed = insertRoadMemberSchema.parse({
        ...req.body,
        roadId: req.params.id,
        createdAt: new Date().toISOString(),
      });
      const member = await storage.createRoadMember(parsed);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create road member" });
    }
  });

  // ============ ASSOCIATIONS ============
  
  // Get all associations
  app.get("/api/associations", async (req, res) => {
    try {
      const associations = await storage.getAssociations();
      res.json(associations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch associations" });
    }
  });

  // Get association by ID
  app.get("/api/associations/:id", async (req, res) => {
    try {
      const association = await storage.getAssociation(req.params.id);
      if (!association) {
        return res.status(404).json({ error: "Association not found" });
      }
      res.json(association);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch association" });
    }
  });

  // Get association by vicinal ID
  app.get("/api/vicinais/:vicinalId/association", async (req, res) => {
    try {
      const association = await storage.getAssociationByVicinal(req.params.vicinalId);
      res.json(association || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch association" });
    }
  });

  // Create association
  app.post("/api/associations", async (req, res) => {
    try {
      const parsed = insertAssociationSchema.parse(req.body);
      const association = await storage.createAssociation(parsed);
      res.status(201).json(association);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create association" });
    }
  });

  // Update association
  app.patch("/api/associations/:id", async (req, res) => {
    try {
      const association = await storage.updateAssociation(req.params.id, req.body);
      if (!association) {
        return res.status(404).json({ error: "Association not found" });
      }
      res.json(association);
    } catch (error) {
      res.status(500).json({ error: "Failed to update association" });
    }
  });

  // ============ ASSOCIATION MEMBERS ============
  
  // Get members of an association
  app.get("/api/associations/:associationId/members", async (req, res) => {
    try {
      const members = await storage.getMembersByAssociation(req.params.associationId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch members" });
    }
  });

  // Add member to association
  app.post("/api/associations/:associationId/members", async (req, res) => {
    try {
      const parsed = insertMemberSchema.parse({
        ...req.body,
        associationId: req.params.associationId,
        joinedAt: new Date().toISOString(),
      });
      
      // Check if user is already a member
      const existingMember = await storage.getMemberByUser(req.params.associationId, parsed.userId);
      if (existingMember) {
        return res.status(400).json({ error: "User is already a member of this association" });
      }
      
      const member = await storage.createMember(parsed);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to add member" });
    }
  });

  // Update member role
  app.patch("/api/associations/:associationId/members/:memberId", async (req, res) => {
    try {
      const member = await storage.updateMember(req.params.memberId, req.body);
      if (!member) {
        return res.status(404).json({ error: "Member not found" });
      }
      res.json(member);
    } catch (error) {
      res.status(500).json({ error: "Failed to update member" });
    }
  });

  // Remove member from association
  app.delete("/api/associations/:associationId/members/:memberId", async (req, res) => {
    try {
      await storage.removeMember(req.params.memberId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove member" });
    }
  });

  // ============ PROJECTS ============
  
  // Get all projects
  app.get("/api/projects", async (req, res) => {
    try {
      const associationId = req.query.associationId as string | undefined;
      let projects;
      if (associationId) {
        projects = await storage.getProjectsByAssociation(associationId);
      } else {
        projects = await storage.getProjects();
      }
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Get project by ID
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  // Create project
  app.post("/api/projects", async (req, res) => {
    try {
      const parsed = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(parsed);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  // Update project
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.updateProject(req.params.id, req.body);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  // ============ TRANSACTIONS ============
  
  // Get transactions by association
  app.get("/api/associations/:associationId/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByAssociation(req.params.associationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // Get transactions by project
  app.get("/api/projects/:projectId/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByProject(req.params.projectId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // Create transaction
  app.post("/api/transactions", async (req, res) => {
    try {
      const parsed = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(parsed);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  // ============ CONTRIBUTIONS ============
  
  // Get contributions by project
  app.get("/api/projects/:projectId/contributions", async (req, res) => {
    try {
      const contributions = await storage.getContributionsByProject(req.params.projectId);
      res.json(contributions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contributions" });
    }
  });

  // Create contribution
  app.post("/api/contributions", async (req, res) => {
    try {
      const parsed = insertContributionSchema.parse(req.body);
      const contribution = await storage.createContribution(parsed);
      res.status(201).json(contribution);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create contribution" });
    }
  });

  // ============ SERVICE PROVIDERS ============
  
  // Get all active providers
  app.get("/api/providers", async (req, res) => {
    try {
      const providers = await storage.getServiceProviders();
      res.json(providers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch providers" });
    }
  });

  // Get providers by vicinal
  app.get("/api/providers/by-vicinal/:vicinalId", async (req, res) => {
    try {
      const providers = await storage.getProvidersByVicinal(req.params.vicinalId);
      res.json(providers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch providers" });
    }
  });

  // Get provider by ID with details
  app.get("/api/providers/:id", async (req, res) => {
    try {
      const provider = await storage.getServiceProvider(req.params.id);
      if (!provider) {
        return res.status(404).json({ error: "Provider not found" });
      }
      const services = await storage.getProviderServices(req.params.id);
      const coverage = await storage.getProviderCoverage(req.params.id);
      const availability = await storage.getProviderAvailability(req.params.id);
      res.json({ ...provider, services, coverage, availability });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch provider" });
    }
  });

  // Create provider
  app.post("/api/providers", async (req, res) => {
    try {
      const parsed = insertServiceProviderSchema.parse(req.body);
      const provider = await storage.createServiceProvider(parsed);
      res.status(201).json(provider);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create provider" });
    }
  });

  // Update provider
  app.patch("/api/providers/:id", async (req, res) => {
    try {
      const provider = await storage.updateServiceProvider(req.params.id, req.body);
      if (!provider) {
        return res.status(404).json({ error: "Provider not found" });
      }
      res.json(provider);
    } catch (error) {
      res.status(500).json({ error: "Failed to update provider" });
    }
  });

  // Delete provider
  app.delete("/api/providers/:id", async (req, res) => {
    try {
      await storage.deleteServiceProvider(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete provider" });
    }
  });

  // ============ PROVIDER SERVICES ============
  
  // Get services for provider
  app.get("/api/providers/:id/services", async (req, res) => {
    try {
      const services = await storage.getProviderServices(req.params.id);
      res.json(services);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Add service to provider
  app.post("/api/providers/:id/services", async (req, res) => {
    try {
      const parsed = insertProviderServiceSchema.parse({
        ...req.body,
        providerId: req.params.id,
      });
      const service = await storage.createProviderService(parsed);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to add service" });
    }
  });

  // Remove service from provider
  app.delete("/api/providers/:id/services/:serviceId", async (req, res) => {
    try {
      await storage.deleteProviderService(req.params.serviceId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove service" });
    }
  });

  // ============ PROVIDER COVERAGE ============
  
  // Get coverage for provider
  app.get("/api/providers/:id/coverage", async (req, res) => {
    try {
      const coverage = await storage.getProviderCoverage(req.params.id);
      res.json(coverage);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch coverage" });
    }
  });

  // Add coverage to provider
  app.post("/api/providers/:id/coverage", async (req, res) => {
    try {
      const parsed = insertProviderCoverageSchema.parse({
        ...req.body,
        providerId: req.params.id,
      });
      const coverage = await storage.createProviderCoverage(parsed);
      res.status(201).json(coverage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to add coverage" });
    }
  });

  // Remove coverage from provider
  app.delete("/api/providers/:id/coverage/:coverageId", async (req, res) => {
    try {
      await storage.deleteProviderCoverage(req.params.coverageId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove coverage" });
    }
  });

  // ============ PROVIDER AVAILABILITY ============
  
  // Get availability for provider
  app.get("/api/providers/:id/availability", async (req, res) => {
    try {
      const availability = await storage.getProviderAvailability(req.params.id);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch availability" });
    }
  });

  // Add availability slot to provider
  app.post("/api/providers/:id/availability", async (req, res) => {
    try {
      const parsed = insertProviderAvailabilitySchema.parse({
        ...req.body,
        providerId: req.params.id,
      });
      const availability = await storage.createProviderAvailability(parsed);
      res.status(201).json(availability);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to add availability" });
    }
  });

  // Remove availability slot from provider
  app.delete("/api/providers/:id/availability/:availabilityId", async (req, res) => {
    try {
      await storage.deleteProviderAvailability(req.params.availabilityId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove availability" });
    }
  });

  // ============ POINTS SYSTEM ============
  
  // Get user's points and level
  app.get("/api/points/user/:userId", async (req, res) => {
    try {
      const points = await storage.getUserPoints(req.params.userId);
      if (!points) {
        return res.json({ userId: req.params.userId, totalPontos: 0, pontosDoMes: 0, nivel: 1 });
      }
      res.json(points);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user points" });
    }
  });

  // Get point events history for user
  app.get("/api/points/events/:userId", async (req, res) => {
    try {
      const events = await storage.getPointEvents(req.params.userId);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch point events" });
    }
  });

  // Award points to user
  app.post("/api/points/award", async (req, res) => {
    try {
      const { userId, tipoAcao, pontos, descricao, awardedBy } = req.body;
      
      const eventData = insertPointEventSchema.parse({
        userId,
        tipoAcao,
        pontos,
        descricao,
        awardedBy,
        createdAt: new Date().toISOString(),
      });
      
      const event = await storage.createPointEvent(eventData);
      
      let userPoints = await storage.getUserPoints(userId);
      if (!userPoints) {
        userPoints = await storage.createUserPoints({
          userId,
          totalPontos: pontos,
          pontosDoMes: pontos,
          nivel: 1,
          updatedAt: new Date().toISOString(),
        });
      } else {
        const newTotal = (userPoints.totalPontos || 0) + pontos;
        const newMonthly = (userPoints.pontosDoMes || 0) + pontos;
        const newLevel = Math.floor(newTotal / 100) + 1;
        userPoints = await storage.updateUserPoints(userPoints.id, {
          totalPontos: newTotal,
          pontosDoMes: newMonthly,
          nivel: newLevel,
          updatedAt: new Date().toISOString(),
        });
      }
      
      res.status(201).json({ event, userPoints });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to award points" });
    }
  });

  // Get leaderboard
  app.get("/api/points/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const leaderboard = await storage.getLeaderboard(limit);
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  // Get point rules
  app.get("/api/points/rules", async (req, res) => {
    try {
      const rules = await storage.getPointRules();
      res.json(rules);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch point rules" });
    }
  });

  // ============ FISCALIZATION ALERTS ============
  
  // Get all alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getFiscalizationAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Get active alerts only
  app.get("/api/alerts/active", async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch active alerts" });
    }
  });

  // Get alerts by vicinal
  app.get("/api/alerts/vicinal/:vicinalId", async (req, res) => {
    try {
      const alerts = await storage.getAlertsByVicinal(req.params.vicinalId);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Create fiscalization alert (URGENT)
  app.post("/api/alerts", async (req, res) => {
    try {
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 4);
      
      const parsed = insertFiscalizationAlertSchema.parse({
        ...req.body,
        status: 'active',
        createdAt: new Date().toISOString(),
        expiresAt: req.body.expiresAt || expiresAt.toISOString(),
      });
      const alert = await storage.createFiscalizationAlert(parsed);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create alert" });
    }
  });

  // Cancel alert
  app.post("/api/alerts/:id/cancel", async (req, res) => {
    try {
      const { cancelledBy } = req.body;
      await storage.cancelAlert(req.params.id, cancelledBy || "anonymous");
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to cancel alert" });
    }
  });

  // ============ GOVERNMENT DEMANDS ============
  
  // Get all demands
  app.get("/api/government/demands", async (req, res) => {
    try {
      const demands = await storage.getGovernmentDemands();
      res.json(demands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch demands" });
    }
  });

  // Get demand by ID
  app.get("/api/government/demands/:id", async (req, res) => {
    try {
      const demand = await storage.getGovernmentDemand(req.params.id);
      if (!demand) {
        return res.status(404).json({ error: "Demand not found" });
      }
      res.json(demand);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch demand" });
    }
  });

  // Get demands by vicinal
  app.get("/api/government/demands/vicinal/:vicinalId", async (req, res) => {
    try {
      const demands = await storage.getDemandsByVicinal(req.params.vicinalId);
      res.json(demands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch demands" });
    }
  });

  // Create demand
  app.post("/api/government/demands", async (req, res) => {
    try {
      const parsed = insertGovernmentDemandSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString(),
      });
      const demand = await storage.createGovernmentDemand(parsed);
      res.status(201).json(demand);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create demand" });
    }
  });

  // Update demand
  app.patch("/api/government/demands/:id", async (req, res) => {
    try {
      const allowedFields = ['titulo', 'descricao', 'categoria', 'prioridade', 'status', 'populacaoAfetada', 'orcamentoEstimado', 'responseGoverno', 'responsavelGoverno', 'prazoResposta', 'signatureCount'];
      const sanitizedData: Record<string, any> = {};
      for (const key of allowedFields) {
        if (req.body[key] !== undefined) {
          sanitizedData[key] = req.body[key];
        }
      }
      if (Object.keys(sanitizedData).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      const demand = await storage.updateGovernmentDemand(req.params.id, sanitizedData);
      if (!demand) {
        return res.status(404).json({ error: "Demand not found" });
      }
      res.json(demand);
    } catch (error) {
      res.status(500).json({ error: "Failed to update demand" });
    }
  });

  // ============ GOVERNMENT PROJECTS ============
  
  // Get all government projects
  app.get("/api/government/projects", async (req, res) => {
    try {
      const projects = await storage.getGovernmentProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch government projects" });
    }
  });

  // Get government project by ID
  app.get("/api/government/projects/:id", async (req, res) => {
    try {
      const project = await storage.getGovernmentProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  // Create government project
  app.post("/api/government/projects", async (req, res) => {
    try {
      const parsed = insertGovernmentProjectSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString(),
      });
      const project = await storage.createGovernmentProject(parsed);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  // Update government project
  app.patch("/api/government/projects/:id", async (req, res) => {
    try {
      const allowedFields = ['titulo', 'descricao', 'orgaoResponsavel', 'status', 'orcamento', 'prazoInicio', 'prazoConclusao', 'percentualConcluido', 'vicinalIds', 'fotos', 'responsavelNome', 'responsavelContato'];
      const sanitizedData: Record<string, any> = {};
      for (const key of allowedFields) {
        if (req.body[key] !== undefined) {
          sanitizedData[key] = req.body[key];
        }
      }
      if (Object.keys(sanitizedData).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      const project = await storage.updateGovernmentProject(req.params.id, sanitizedData);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  return httpServer;
}
