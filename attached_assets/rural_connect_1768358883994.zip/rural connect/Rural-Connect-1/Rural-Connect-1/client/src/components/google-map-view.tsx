import { useState, useCallback, useRef, useEffect } from "react";
import { APIProvider, Map, AdvancedMarker, InfoWindow, useMap } from "@vis.gl/react-google-maps";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { 
  Plus, Locate, Layers, Home, Zap, Construction, Milestone, Users, Wheat, Map as MapIcon, Satellite,
  Ruler, TrafficCone, Bus, Compass, Maximize, Mountain, X
} from "lucide-react";
import { MinimizableCard, useMinimizableCards } from "@/components/minimizable-cards";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Occurrence, Vicinal, User, Road, RoadClassification } from "@shared/schema";
import { RoadEditorToolbar, RoadList } from "./road-editor";
import { Polyline } from "./google-maps-polyline";
import { TrafficLayer, TransitLayer } from "./google-maps-layers";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const DEFAULT_CENTER = { lat: -3.6268, lng: -53.3936 };
const DEFAULT_ZOOM = 14;

const ROAD_COLORS = {
  principal: "#ff7f50",
  ramal: "#2563eb",
};

const ROAD_WEIGHTS = {
  principal: 8,
  ramal: 4,
};

const occurrenceColors: Record<string, string> = {
  electrical: "#ef4444",
  road: "#ea580c",
  bridge: "#06b6d4",
  social: "#eab308",
  theft: "#a855f7",
  other: "#6b7280",
};

const occurrenceLabels: Record<string, string> = {
  electrical: "Rede Elétrica",
  road: "Estrada",
  bridge: "Ponte",
  social: "Social",
  theft: "Roubo de Safra",
  other: "Outro",
};

function LegendCard() {
  const { isMinimized } = useMinimizableCards();

  if (isMinimized("map-legend")) return null;

  return (
    <div className="absolute bottom-20 left-4 z-[1000] max-w-[180px]">
      <MinimizableCard
        id="map-legend"
        title="Legenda"
        icon={<Layers className="h-3 w-3 text-muted-foreground" />}
      >
        <div className="space-y-1.5 text-xs">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide">Estradas</div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-1 rounded-full bg-[#ff7f50]" />
            <span>Transamazônica</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 rounded-full bg-[#2563eb]" />
            <span>Vicinais</span>
          </div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide mt-2">Marcadores</div>
          <div className="flex items-center gap-2">
            <Home className="h-3 w-3 text-green-500" />
            <span>Propriedades</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="h-3 w-3 text-red-500" />
            <span>Rede Elétrica</span>
          </div>
          <div className="flex items-center gap-2">
            <Construction className="h-3 w-3 text-[#ea580c]" />
            <span>Estrada</span>
          </div>
          <div className="flex items-center gap-2">
            <Milestone className="h-3 w-3 text-[#06b6d4]" />
            <span>Ponte</span>
          </div>
        </div>
      </MinimizableCard>
    </div>
  );
}

interface GoogleMapViewProps {
  occurrences?: Occurrence[];
  users?: User[];
  vicinais?: Vicinal[];
  onAddOccurrence?: () => void;
  onMapClick?: (lat: number, lng: number) => void;
  onOccurrenceClick?: (occurrence: Occurrence) => void;
  onRoadClick?: (road: Road) => void;
  selectedLocation?: { lat: number; lng: number } | null;
  showAddButton?: boolean;
  className?: string;
}

function MapContent({
  occurrences = [],
  users = [],
  vicinais = [],
  onAddOccurrence,
  onMapClick,
  onOccurrenceClick,
  onRoadClick,
  selectedLocation,
  showAddButton = true,
  className,
}: GoogleMapViewProps) {
  const { toast } = useToast();
  const map = useMap();
  const [isDrawingRoad, setIsDrawingRoad] = useState(false);
  const [drawingPoints, setDrawingPoints] = useState<[number, number][]>([]);
  const [mapType, setMapType] = useState<"roadmap" | "satellite" | "hybrid" | "terrain">("hybrid");
  const [selectedMarker, setSelectedMarker] = useState<{ type: "occurrence" | "user" | "road"; data: any } | null>(null);
  
  const [showTraffic, setShowTraffic] = useState(false);
  const [showTransit, setShowTransit] = useState(false);
  const [isMeasuring, setIsMeasuring] = useState(false);
  const [measurePoints, setMeasurePoints] = useState<google.maps.LatLngLiteral[]>([]);
  const [totalDistance, setTotalDistance] = useState<number>(0);

  const { data: savedRoads = [] } = useQuery<Road[]>({
    queryKey: ["/api/roads"],
  });

  const vicinalKm140 = savedRoads.find(r => r.nome.toLowerCase().includes("140") && r.nome.toLowerCase().includes("norte"));

  const createRoadMutation = useMutation({
    mutationFn: async (data: { nome: string; classification: RoadClassification; coordinates: string }) => {
      return apiRequest("POST", "/api/roads", {
        ...data,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roads"] });
      toast({
        title: "Estrada salva",
        description: "A estrada foi salva com sucesso!",
      });
      setIsDrawingRoad(false);
      setDrawingPoints([]);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível salvar a estrada.",
        variant: "destructive",
      });
    },
  });

  const parseCoordinates = useCallback((coordString: string): google.maps.LatLngLiteral[] => {
    try {
      const coords: [number, number][] = JSON.parse(coordString);
      return coords.map(([lat, lng]) => ({ lat, lng }));
    } catch {
      return [];
    }
  }, []);

  useEffect(() => {
    if (map && vicinalKm140) {
      const path = parseCoordinates(vicinalKm140.coordinates);
      if (path.length > 0) {
        map.panTo(path[0]);
        map.setZoom(15);
      }
    }
  }, [map, vicinalKm140, parseCoordinates]);

  const calculateDistance = useCallback((p1: google.maps.LatLngLiteral, p2: google.maps.LatLngLiteral): number => {
    const R = 6371;
    const dLat = (p2.lat - p1.lat) * Math.PI / 180;
    const dLng = (p2.lng - p1.lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) *
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }, []);

  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (!e.latLng) return;
    const lat = e.latLng.lat();
    const lng = e.latLng.lng();
    
    if (isMeasuring) {
      const newPoint = { lat, lng };
      setMeasurePoints((prev) => {
        const newPoints = [...prev, newPoint];
        let total = 0;
        for (let i = 1; i < newPoints.length; i++) {
          total += calculateDistance(newPoints[i-1], newPoints[i]);
        }
        setTotalDistance(total);
        return newPoints;
      });
    } else if (isDrawingRoad) {
      setDrawingPoints((prev) => [...prev, [lat, lng]]);
    } else if (onMapClick) {
      onMapClick(lat, lng);
    }
    setSelectedMarker(null);
  }, [isMeasuring, isDrawingRoad, onMapClick, calculateDistance]);

  useEffect(() => {
    if (!map) return;
    const listener = map.addListener('click', handleMapClick);
    return () => google.maps.event.removeListener(listener);
  }, [map, handleMapClick]);

  useEffect(() => {
    if (map) {
      map.setMapTypeId(mapType);
    }
  }, [map, mapType]);

  const handleLocate = useCallback(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        if (map) {
          map.panTo({ lat: latitude, lng: longitude });
          map.setZoom(16);
        }
      },
      () => {
        toast({
          title: "Erro de localização",
          description: "Não foi possível obter sua localização.",
          variant: "destructive",
        });
      }
    );
  }, [map, toast]);

  const handleStartDrawing = useCallback(() => {
    if (isMeasuring) {
      setIsMeasuring(false);
      setMeasurePoints([]);
      setTotalDistance(0);
    }
    setIsDrawingRoad(true);
    setDrawingPoints([]);
  }, [isMeasuring]);

  const handleCancelDrawing = useCallback(() => {
    setIsDrawingRoad(false);
    setDrawingPoints([]);
  }, []);

  const handleSaveRoad = useCallback((name: string, classification: RoadClassification) => {
    if (drawingPoints.length < 2) return;
    
    createRoadMutation.mutate({
      nome: name,
      classification,
      coordinates: JSON.stringify(drawingPoints),
    });
  }, [drawingPoints, createRoadMutation]);

  const handleStartMeasuring = useCallback(() => {
    if (isDrawingRoad) {
      setIsDrawingRoad(false);
      setDrawingPoints([]);
    }
    setIsMeasuring(true);
    setMeasurePoints([]);
    setTotalDistance(0);
  }, [isDrawingRoad]);

  const handleClearMeasurement = useCallback(() => {
    setIsMeasuring(false);
    setMeasurePoints([]);
    setTotalDistance(0);
  }, []);

  const handleResetNorth = useCallback(() => {
    if (map) {
      map.setHeading(0);
      map.setTilt(0);
    }
  }, [map]);

  const handleFullscreen = useCallback(() => {
    const mapDiv = document.querySelector(".google-map-container");
    if (mapDiv && document.fullscreenElement === null) {
      mapDiv.requestFullscreen?.();
    } else if (document.fullscreenElement) {
      document.exitFullscreen?.();
    }
  }, []);

  return (
    <>
      {savedRoads.map((road) => {
        const path = parseCoordinates(road.coordinates);
        if (path.length < 2) return null;
        return (
          <Polyline
            key={road.id}
            path={path}
            strokeColor={road.id === vicinalKm140?.id ? "#f97316" : (ROAD_COLORS[road.classification as keyof typeof ROAD_COLORS] || ROAD_COLORS.ramal)}
            strokeWeight={road.id === vicinalKm140?.id ? 10 : (ROAD_WEIGHTS[road.classification as keyof typeof ROAD_WEIGHTS] || ROAD_WEIGHTS.ramal)}
            strokeOpacity={road.id === vicinalKm140?.id ? 1.0 : 0.9}
            clickable={true}
            zIndex={road.id === vicinalKm140?.id ? 1000 : 1}
            onClick={() => {
              onRoadClick?.(road);
              setSelectedMarker({ type: "road", data: road });
            }}
          />
        );
      })}

      {isDrawingRoad && drawingPoints.length >= 2 && (
        <Polyline
          path={drawingPoints.map(([lat, lng]) => ({ lat, lng }))}
          strokeColor="#2563eb"
          strokeWeight={5}
          strokeOpacity={0.9}
        />
      )}

      {isDrawingRoad && drawingPoints.map((point, index) => (
        <AdvancedMarker
          key={`drawing-point-${index}`}
          position={{ lat: point[0], lng: point[1] }}
        >
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 border-2 border-white text-white text-xs font-bold shadow-lg">
            {index + 1}
          </div>
        </AdvancedMarker>
      ))}

      {users.map((user) =>
        user.latitude && user.longitude ? (
          <AdvancedMarker
            key={`user-${user.id}`}
            position={{ lat: user.latitude, lng: user.longitude }}
            onClick={() => setSelectedMarker({ type: "user", data: user })}
          >
            <div className="flex items-center justify-center w-5 h-5 rounded-full bg-green-500 border-2 border-white shadow-md">
              <Home className="h-3 w-3 text-white" />
            </div>
          </AdvancedMarker>
        ) : null
      )}

      {occurrences.map((occurrence) => (
        <AdvancedMarker
          key={`occurrence-${occurrence.id}`}
          position={{ lat: occurrence.latitude, lng: occurrence.longitude }}
          onClick={() => {
            onOccurrenceClick?.(occurrence);
            setSelectedMarker({ type: "occurrence", data: occurrence });
          }}
        >
          <div 
            className="relative flex items-center justify-center"
            style={{ 
              width: 28, 
              height: 38,
            }}
          >
            <svg viewBox="0 0 24 34" width="28" height="38">
              <path 
                d="M12 0C5.4 0 0 5.4 0 12c0 7.4 12 22 12 22s12-14.6 12-22c0-6.6-5.4-12-12-12z" 
                fill={occurrenceColors[occurrence.tipo] || occurrenceColors.other}
                stroke="#ffffff"
                strokeWidth="1.5"
              />
              <circle cx="12" cy="11" r="4" fill="#ffffff" />
            </svg>
          </div>
        </AdvancedMarker>
      ))}

      {selectedLocation && (
        <AdvancedMarker
          position={{ lat: selectedLocation.lat, lng: selectedLocation.lng }}
        >
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-500 border-3 border-white shadow-lg animate-pulse" />
        </AdvancedMarker>
      )}

      {selectedMarker && selectedMarker.type === "user" && (
        <InfoWindow
          position={{ lat: selectedMarker.data.latitude, lng: selectedMarker.data.longitude }}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div className="p-1">
            <p className="font-medium text-gray-900">{selectedMarker.data.propriedadeNome || selectedMarker.data.nome}</p>
            <p className="text-sm text-gray-600">{selectedMarker.data.nome}</p>
          </div>
        </InfoWindow>
      )}

      {selectedMarker && selectedMarker.type === "occurrence" && (
        <InfoWindow
          position={{ lat: selectedMarker.data.latitude, lng: selectedMarker.data.longitude }}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div className="p-1 min-w-[150px]">
            <p className="font-medium text-gray-900">{selectedMarker.data.titulo}</p>
            <p className="text-xs text-gray-500 mt-1">
              {occurrenceLabels[selectedMarker.data.tipo]}
            </p>
            <p className="text-sm text-gray-700 mt-2 line-clamp-2">{selectedMarker.data.descricao}</p>
          </div>
        </InfoWindow>
      )}

      {selectedMarker && selectedMarker.type === "road" && (
        <InfoWindow
          position={parseCoordinates(selectedMarker.data.coordinates)[0]}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div className="p-1">
            <p className="font-medium text-gray-900">{selectedMarker.data.nome}</p>
            <p className="text-xs text-gray-500">
              {selectedMarker.data.classification === "principal" ? "Estrada Principal" : "Ramal/Vicinal"}
            </p>
          </div>
        </InfoWindow>
      )}

      {showTraffic && <TrafficLayer />}
      {showTransit && <TransitLayer />}

      {isMeasuring && measurePoints.length >= 2 && (
        <Polyline
          path={measurePoints}
          strokeColor="#f97316"
          strokeWeight={4}
          strokeOpacity={1}
        />
      )}
      {isMeasuring && measurePoints.map((point, index) => (
        <AdvancedMarker
          key={`measure-point-${index}`}
          position={point}
        >
          <div className="flex items-center justify-center w-5 h-5 rounded-full bg-orange-500 border-2 border-white text-white text-[10px] font-bold shadow-lg">
            {index + 1}
          </div>
        </AdvancedMarker>
      ))}

      <Button
        variant="secondary"
        size="icon"
        className="absolute top-4 right-4 z-[1000] shadow-md"
        onClick={() => setMapType(mapType === "roadmap" ? "satellite" : mapType === "satellite" ? "hybrid" : mapType === "hybrid" ? "terrain" : "roadmap")}
        data-testid="button-map-type"
      >
        {mapType === "roadmap" ? <MapIcon className="h-5 w-5" /> : <Satellite className="h-5 w-5" />}
      </Button>

      <Button
        variant="secondary"
        size="icon"
        className="absolute top-16 right-4 z-[1000] shadow-md"
        onClick={handleLocate}
        data-testid="button-locate"
      >
        <Locate className="h-5 w-5" />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="secondary"
            size="icon"
            className="absolute top-28 right-4 z-[1000] shadow-md"
            data-testid="button-map-tools"
          >
            <Layers className="h-5 w-5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel>Ferramentas do Mapa</DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          <DropdownMenuItem onClick={() => setShowTraffic(!showTraffic)} data-testid="menu-traffic">
            <TrafficCone className="h-4 w-4 mr-2" />
            Trânsito
            {showTraffic && <Badge variant="secondary" className="ml-auto text-[10px]">ON</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={() => setShowTransit(!showTransit)} data-testid="menu-transit">
            <Bus className="h-4 w-4 mr-2" />
            Transporte Público
            {showTransit && <Badge variant="secondary" className="ml-auto text-[10px]">ON</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          
          <DropdownMenuItem onClick={isMeasuring ? handleClearMeasurement : handleStartMeasuring} data-testid="menu-measure">
            <Ruler className="h-4 w-4 mr-2" />
            {isMeasuring ? "Parar Medição" : "Medir Distância"}
            {isMeasuring && <Badge variant="secondary" className="ml-auto text-[10px]">ON</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={handleResetNorth} data-testid="menu-compass">
            <Compass className="h-4 w-4 mr-2" />
            Apontar Norte
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={handleFullscreen} data-testid="menu-fullscreen">
            <Maximize className="h-4 w-4 mr-2" />
            Tela Cheia
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          <DropdownMenuLabel className="text-[10px] text-muted-foreground">Tipo de Mapa</DropdownMenuLabel>
          
          <DropdownMenuItem onClick={() => setMapType("roadmap")} data-testid="menu-roadmap">
            <MapIcon className="h-4 w-4 mr-2" />
            Mapa
            {mapType === "roadmap" && <Badge variant="secondary" className="ml-auto text-[10px]">✓</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={() => setMapType("satellite")} data-testid="menu-satellite">
            <Satellite className="h-4 w-4 mr-2" />
            Satélite
            {mapType === "satellite" && <Badge variant="secondary" className="ml-auto text-[10px]">✓</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={() => setMapType("hybrid")} data-testid="menu-hybrid">
            <Layers className="h-4 w-4 mr-2" />
            Híbrido
            {mapType === "hybrid" && <Badge variant="secondary" className="ml-auto text-[10px]">✓</Badge>}
          </DropdownMenuItem>
          
          <DropdownMenuItem onClick={() => setMapType("terrain")} data-testid="menu-terrain">
            <Mountain className="h-4 w-4 mr-2" />
            Terreno
            {mapType === "terrain" && <Badge variant="secondary" className="ml-auto text-[10px]">✓</Badge>}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {isMeasuring && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000]">
          <div className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-full shadow-lg">
            <Ruler className="h-4 w-4" />
            <span className="text-sm font-medium">
              {totalDistance > 0 
                ? `${totalDistance.toFixed(2)} km` 
                : "Toque para medir"}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5 ml-1 text-white hover:bg-orange-600"
              onClick={handleClearMeasurement}
              data-testid="button-clear-measurement"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>
      )}

      <RoadEditorToolbar
        isDrawing={isDrawingRoad}
        drawingPoints={drawingPoints}
        onStartDrawing={handleStartDrawing}
        onCancelDrawing={handleCancelDrawing}
        onSaveRoad={handleSaveRoad}
      />

      {!isDrawingRoad && savedRoads.length > 0 && (
        <RoadList onDeleteRoad={() => {}} />
      )}

      <LegendCard />

      {showAddButton && onAddOccurrence && !isDrawingRoad && (
        <Button
          size="lg"
          className="absolute bottom-20 right-4 z-[1000] h-14 w-14 rounded-full shadow-lg"
          onClick={onAddOccurrence}
          data-testid="button-add-occurrence"
        >
          <Plus className="h-6 w-6" />
        </Button>
      )}
    </>
  );
}

export function GoogleMapView(props: GoogleMapViewProps) {
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
  const mapId = import.meta.env.VITE_GOOGLE_MAPS_MAP_ID || "DEMO_MAP_ID";
  const [keyError, setKeyError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  if (!apiKey) {
    return (
      <div className="flex items-center justify-center h-full bg-muted">
        <p className="text-muted-foreground">Chave da API do Google Maps não configurada</p>
      </div>
    );
  }

  return (
    <div className={cn("relative w-full h-full google-map-container", props.className)}>
      <APIProvider 
        apiKey={apiKey}
        language="pt-BR"
        region="BR"
        libraries={["places", "geometry", "marker"]}
        onLoad={() => {
          setKeyError(false);
          setErrorMessage("");
        }}
        onError={(error: unknown) => {
          setKeyError(true);
          const errMsg = error instanceof Error ? error.message : String(error);
          setErrorMessage(errMsg || "Erro desconhecido");
          console.error("Google Maps API Error:", error);
        }}
      >
        {keyError ? (
          <div className="flex flex-col items-center justify-center h-full bg-muted p-6 text-center">
            <p className="text-destructive font-medium mb-2">Erro ao carregar Google Maps</p>
            <p className="text-sm text-muted-foreground mb-2">
              Verifique se a API key está correta e sem restrições de domínio.
            </p>
            {errorMessage && (
              <p className="text-xs text-muted-foreground font-mono bg-muted-foreground/10 p-2 rounded">
                {errorMessage}
              </p>
            )}
          </div>
        ) : (
          <Map
            defaultCenter={DEFAULT_CENTER}
            defaultZoom={DEFAULT_ZOOM}
            mapId={mapId}
            gestureHandling="greedy"
            disableDefaultUI={false}
            zoomControl={true}
            streetViewControl={true}
            mapTypeControl={false}
            fullscreenControl={false}
            scaleControl={true}
            style={{ width: "100%", height: "100%" }}
          >
            <MapContent {...props} />
          </Map>
        )}
      </APIProvider>
    </div>
  );
}
