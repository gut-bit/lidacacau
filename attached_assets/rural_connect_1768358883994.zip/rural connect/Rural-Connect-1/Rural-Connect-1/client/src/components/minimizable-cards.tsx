import { createContext, useContext, useState, ReactNode } from "react";
import { X, Maximize2, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface MinimizedCard {
  id: string;
  title: string;
  icon?: ReactNode;
  color?: string;
}

interface MinimizableCardsContextType {
  minimizedCards: MinimizedCard[];
  minimizeCard: (card: MinimizedCard) => void;
  restoreCard: (id: string) => void;
  isMinimized: (id: string) => boolean;
}

const MinimizableCardsContext = createContext<MinimizableCardsContextType | null>(null);

export function MinimizableCardsProvider({ children }: { children: ReactNode }) {
  const [minimizedCards, setMinimizedCards] = useState<MinimizedCard[]>([]);

  const minimizeCard = (card: MinimizedCard) => {
    setMinimizedCards((prev) => {
      if (prev.find((c) => c.id === card.id)) return prev;
      return [...prev, card];
    });
  };

  const restoreCard = (id: string) => {
    setMinimizedCards((prev) => prev.filter((c) => c.id !== id));
  };

  const isMinimized = (id: string) => {
    return minimizedCards.some((c) => c.id === id);
  };

  return (
    <MinimizableCardsContext.Provider value={{ minimizedCards, minimizeCard, restoreCard, isMinimized }}>
      {children}
    </MinimizableCardsContext.Provider>
  );
}

export function useMinimizableCards() {
  const context = useContext(MinimizableCardsContext);
  if (!context) {
    return {
      minimizedCards: [],
      minimizeCard: () => {},
      restoreCard: () => {},
      isMinimized: () => false,
    };
  }
  return context;
}

interface MinimizableCardProps {
  id: string;
  title: string;
  icon?: ReactNode;
  color?: string;
  children: ReactNode;
  className?: string;
  onClose?: () => void;
}

export function MinimizableCard({
  id,
  title,
  icon,
  color = "bg-primary",
  children,
  className,
  onClose,
}: MinimizableCardProps) {
  const { minimizeCard, isMinimized, restoreCard } = useMinimizableCards();

  if (isMinimized(id)) {
    return null;
  }

  const handleMinimize = () => {
    minimizeCard({ id, title, icon, color });
  };

  return (
    <div
      className={cn(
        "bg-card rounded-lg shadow-lg border border-card-border overflow-hidden",
        className
      )}
    >
      <div className="flex items-center justify-between px-3 py-2 bg-muted/50 border-b border-card-border">
        <div className="flex items-center gap-2 text-sm font-medium">
          {icon}
          <span className="truncate">{title}</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={handleMinimize}
            data-testid={`button-minimize-${id}`}
            aria-label="Minimizar"
          >
            <Minus className="h-3 w-3" />
          </Button>
          {onClose && (
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={onClose}
              data-testid={`button-close-${id}`}
              aria-label="Fechar"
            >
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>
      <div className="p-3">{children}</div>
    </div>
  );
}

export function MinimizedCardsTray() {
  const { minimizedCards, restoreCard } = useMinimizableCards();

  if (minimizedCards.length === 0) return null;

  return (
    <div
      className="absolute bottom-24 left-4 z-[1001] flex flex-col items-start gap-1.5"
      data-testid="minimized-cards-tray"
    >
      {minimizedCards.map((card) => (
        <button
          key={card.id}
          onClick={() => restoreCard(card.id)}
          className={cn(
            "flex items-center gap-1.5 px-2 py-1 rounded-md shadow-md border border-orange-600/20 bg-orange-500 hover:bg-orange-600 transition-all active:scale-95",
            "text-[10px] font-bold text-white uppercase tracking-wider"
          )}
          data-testid={`button-restore-${card.id}`}
          aria-label={`Restaurar ${card.title}`}
        >
          {card.icon && <div className="scale-75">{card.icon}</div>}
          <span className="max-w-[60px] truncate leading-none">{card.title}</span>
          <Maximize2 className="h-2.5 w-2.5 text-white/80" />
        </button>
      ))}
    </div>
  );
}
