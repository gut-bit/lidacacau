import { useEffect, useRef } from 'react';
import { useMap, useMapsLibrary } from '@vis.gl/react-google-maps';

type PolylineEventProps = {
  onClick?: (e: google.maps.MapMouseEvent) => void;
  onDrag?: (e: google.maps.MapMouseEvent) => void;
  onDragStart?: (e: google.maps.MapMouseEvent) => void;
  onDragEnd?: (e: google.maps.MapMouseEvent) => void;
  onMouseOver?: (e: google.maps.MapMouseEvent) => void;
  onMouseOut?: (e: google.maps.MapMouseEvent) => void;
};

type PolylineCustomProps = {
  encodedPath?: string;
};

export type PolylineProps = google.maps.PolylineOptions &
  PolylineEventProps &
  PolylineCustomProps;

export function Polyline(props: PolylineProps) {
  const {
    onClick,
    onDrag,
    onDragStart,
    onDragEnd,
    onMouseOver,
    onMouseOut,
    encodedPath,
    ...polylineOptions
  } = props;

  const map = useMap();
  const geometry = useMapsLibrary('geometry');
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  useEffect(() => {
    if (!map) return;

    const polyline = new google.maps.Polyline({
      map,
      ...polylineOptions,
    });

    polylineRef.current = polyline;

    return () => {
      polyline.setMap(null);
    };
  }, [map]);

  useEffect(() => {
    if (!polylineRef.current) return;

    const path = encodedPath
      ? geometry?.encoding.decodePath(encodedPath)
      : polylineOptions.path;

    polylineRef.current.setOptions({
      ...polylineOptions,
      path,
    });
  }, [polylineOptions, encodedPath, geometry]);

  useEffect(() => {
    if (!polylineRef.current) return;

    const listeners = [
      onClick && google.maps.event.addListener(polylineRef.current, 'click', onClick),
      onDrag && google.maps.event.addListener(polylineRef.current, 'drag', onDrag),
      onDragStart && google.maps.event.addListener(polylineRef.current, 'dragstart', onDragStart),
      onDragEnd && google.maps.event.addListener(polylineRef.current, 'dragend', onDragEnd),
      onMouseOver && google.maps.event.addListener(polylineRef.current, 'mouseover', onMouseOver),
      onMouseOut && google.maps.event.addListener(polylineRef.current, 'mouseout', onMouseOut),
    ].filter(Boolean) as google.maps.MapsEventListener[];

    return () => {
      listeners.forEach(listener => google.maps.event.removeListener(listener));
    };
  }, [onClick, onDrag, onDragStart, onDragEnd, onMouseOver, onMouseOut]);

  return null;
}
