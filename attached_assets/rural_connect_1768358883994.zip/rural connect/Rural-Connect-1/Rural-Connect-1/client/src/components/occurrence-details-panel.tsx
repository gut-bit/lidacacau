import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, Send, CheckCircle, Clock, MapPin, User, MessageCircle, Loader2, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Occurrence, OccurrenceComment, Vicinal } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

interface OccurrenceDetailsPanelProps {
  occurrence: Occurrence;
  vicinais: Vicinal[];
  onClose: () => void;
}

const occurrenceLabels: Record<string, string> = {
  electrical: "Rede Elétrica",
  road: "Estrada",
  bridge: "Ponte",
  social: "Social",
  theft: "Roubo de Safra",
  other: "Outro",
};

const occurrenceColors: Record<string, string> = {
  electrical: "bg-red-500",
  road: "bg-orange-500",
  bridge: "bg-cyan-500",
  social: "bg-yellow-500",
  theft: "bg-purple-500",
  other: "bg-gray-500",
};

export function OccurrenceDetailsPanel({ occurrence, vicinais, onClose }: OccurrenceDetailsPanelProps) {
  const { toast } = useToast();
  const [newComment, setNewComment] = useState("");
  const [userName, setUserName] = useState("");

  const vicinal = vicinais.find(v => v.id === occurrence.vicinalId);

  const { data: comments = [], isLoading: loadingComments } = useQuery<OccurrenceComment[]>({
    queryKey: ["/api/occurrences", occurrence.id, "comments"],
    queryFn: async () => {
      const res = await fetch(`/api/occurrences/${occurrence.id}/comments`);
      if (!res.ok) throw new Error("Failed to fetch comments");
      return res.json();
    },
  });

  const addComment = useMutation({
    mutationFn: async (data: { content: string; userName: string }) => {
      return apiRequest("POST", `/api/occurrences/${occurrence.id}/comments`, {
        content: data.content,
        userName: data.userName,
        userId: "anonymous",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences", occurrence.id, "comments"] });
      setNewComment("");
      toast({
        title: "Comentário adicionado",
        description: "Seu comentário foi publicado.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível adicionar o comentário.",
        variant: "destructive",
      });
    },
  });

  const resolveOccurrence = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/occurrences/${occurrence.id}/resolve`, {
        resolvedBy: userName || "anonymous",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      toast({
        title: "Problema resolvido",
        description: "A ocorrência foi marcada como resolvida e arquivada.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível resolver a ocorrência.",
        variant: "destructive",
      });
    },
  });

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    if (!userName.trim()) {
      toast({
        title: "Nome obrigatório",
        description: "Digite seu nome para comentar.",
        variant: "destructive",
      });
      return;
    }
    addComment.mutate({ content: newComment, userName: userName.trim() });
  };

  const createdDate = new Date(occurrence.createdAt);
  const timeAgo = formatDistanceToNow(createdDate, { addSuffix: true, locale: ptBR });

  return (
    <Card className="w-80 max-h-[calc(100vh-180px)] flex flex-col shadow-xl">
      <CardHeader className="pb-2 flex flex-row items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge className={`${occurrenceColors[occurrence.tipo]} text-white text-xs`}>
              {occurrenceLabels[occurrence.tipo]}
            </Badge>
          </div>
          <CardTitle className="text-base leading-tight">{occurrence.titulo}</CardTitle>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="shrink-0"
          onClick={onClose}
          data-testid="button-close-details"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-3 overflow-hidden pt-0">
        <p className="text-sm text-muted-foreground">{occurrence.descricao}</p>
        
        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{timeAgo}</span>
          </div>
          {vicinal && (
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span>{vicinal.nome}</span>
            </div>
          )}
        </div>

        <div className="border-t pt-3">
          <div className="flex items-center gap-2 mb-2">
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Comentários ({comments.length})</span>
          </div>
          
          <ScrollArea className="h-32 mb-3">
            {loadingComments ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-4 w-4 animate-spin" />
              </div>
            ) : comments.length === 0 ? (
              <p className="text-xs text-muted-foreground py-2">Nenhum comentário ainda.</p>
            ) : (
              <div className="space-y-2 pr-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="bg-muted/50 rounded-md p-2">
                    <div className="flex items-center gap-1 mb-1">
                      <User className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs font-medium">{comment.userName}</span>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true, locale: ptBR })}
                      </span>
                    </div>
                    <p className="text-xs">{comment.content}</p>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          <div className="space-y-2">
            <Input
              placeholder="Seu nome"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="text-sm"
              data-testid="input-comment-name"
            />
            <div className="flex gap-2">
              <Input
                placeholder="Adicionar comentário..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAddComment()}
                className="text-sm flex-1"
                data-testid="input-comment-content"
              />
              <Button
                size="icon"
                onClick={handleAddComment}
                disabled={addComment.isPending}
                data-testid="button-add-comment"
              >
                {addComment.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="flex gap-2 mt-auto">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => handleShare()}
            data-testid="button-share-occurrence"
          >
            <Share2 className="h-4 w-4 mr-2" />
            Compartilhar
          </Button>
          <Button
            variant="default"
            className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            onClick={() => resolveOccurrence.mutate()}
            disabled={resolveOccurrence.isPending}
            data-testid="button-resolve-occurrence"
          >
            {resolveOccurrence.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <CheckCircle className="h-4 w-4 mr-2" />
            )}
            Resolvido
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  function handleShare() {
    const text = `*${occurrence.titulo}*\n\n${occurrence.descricao}\n\nTipo: ${occurrenceLabels[occurrence.tipo]}\nLocal: ${vicinal?.nome || "Não especificado"}\nCoordenadas: ${occurrence.latitude}, ${occurrence.longitude}\n\nVeja no mapa: https://www.google.com/maps?q=${occurrence.latitude},${occurrence.longitude}`;
    
    if (navigator.share) {
      navigator.share({
        title: occurrence.titulo,
        text: text,
      }).catch(() => {
        shareViaWhatsApp(text);
      });
    } else {
      shareViaWhatsApp(text);
    }
  }

  function shareViaWhatsApp(text: string) {
    const encodedText = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encodedText}`, "_blank");
  }
}
