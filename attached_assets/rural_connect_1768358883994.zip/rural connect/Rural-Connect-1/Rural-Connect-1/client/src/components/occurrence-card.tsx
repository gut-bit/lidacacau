import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Zap, 
  Construction, 
  Mountain, 
  Users, 
  ShieldAlert, 
  HelpCircle,
  Clock,
  CheckCircle2,
  Loader2,
  AlertCircle,
  MoreVertical,
  Pencil,
  Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Occurrence, OccurrenceStatus, OccurrenceType } from "@shared/schema";

const typeConfig: Record<OccurrenceType, { 
  icon: typeof Zap; 
  label: string; 
  bgColor: string; 
  iconColor: string;
}> = {
  electrical: { 
    icon: Zap, 
    label: "Elétrica", 
    bgColor: "bg-amber-100 dark:bg-amber-900/40", 
    iconColor: "text-amber-600 dark:text-amber-400" 
  },
  road: { 
    icon: Construction, 
    label: "Estrada", 
    bgColor: "bg-orange-100 dark:bg-orange-900/40", 
    iconColor: "text-orange-600 dark:text-orange-400" 
  },
  bridge: { 
    icon: Mountain, 
    label: "Ponte", 
    bgColor: "bg-sky-100 dark:bg-sky-900/40", 
    iconColor: "text-sky-600 dark:text-sky-400" 
  },
  social: { 
    icon: Users, 
    label: "Social", 
    bgColor: "bg-emerald-100 dark:bg-emerald-900/40", 
    iconColor: "text-emerald-600 dark:text-emerald-400" 
  },
  theft: { 
    icon: ShieldAlert, 
    label: "Roubo", 
    bgColor: "bg-red-100 dark:bg-red-900/40", 
    iconColor: "text-red-600 dark:text-red-400" 
  },
  other: { 
    icon: HelpCircle, 
    label: "Outro", 
    bgColor: "bg-slate-100 dark:bg-slate-700/40", 
    iconColor: "text-slate-600 dark:text-slate-400" 
  },
};

const statusConfig: Record<OccurrenceStatus, { 
  icon: typeof AlertCircle;
  bgColor: string; 
  textColor: string;
  label: string;
}> = {
  open: { 
    icon: AlertCircle,
    bgColor: "bg-amber-100 dark:bg-amber-900/50", 
    textColor: "text-amber-700 dark:text-amber-300",
    label: "Aberto" 
  },
  in_progress: { 
    icon: Loader2,
    bgColor: "bg-blue-100 dark:bg-blue-900/50", 
    textColor: "text-blue-700 dark:text-blue-300",
    label: "Em Andamento" 
  },
  resolved: { 
    icon: CheckCircle2,
    bgColor: "bg-green-100 dark:bg-green-900/50", 
    textColor: "text-green-700 dark:text-green-300",
    label: "Resolvido" 
  },
};

interface OccurrenceCardProps {
  occurrence: Occurrence;
  onView?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onSign?: () => void;
  onShare?: () => void;
  compact?: boolean;
}

export function OccurrenceCard({ 
  occurrence, 
  onView,
  onEdit,
  onDelete,
  compact = false 
}: OccurrenceCardProps) {
  const typeInfo = typeConfig[occurrence.tipo] || typeConfig.other;
  const statusInfo = statusConfig[occurrence.status] || statusConfig.open;
  const TypeIcon = typeInfo.icon;
  const StatusIcon = statusInfo.icon;

  const hasPhoto = occurrence.fotos && occurrence.fotos.length > 0;
  const primaryPhoto = hasPhoto ? occurrence.fotos![0] : null;

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      if (diffHours === 0) {
        const diffMinutes = Math.floor(diffMs / (1000 * 60));
        return diffMinutes <= 1 ? "Agora" : `${diffMinutes} min`;
      }
      return `${diffHours}h`;
    }
    if (diffDays === 1) return "Ontem";
    if (diffDays < 7) return `${diffDays} dias`;
    
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
    });
  };

  const getInitials = (userId: string) => {
    return userId.substring(0, 2).toUpperCase();
  };

  return (
    <Card 
      className={cn(
        "overflow-visible cursor-pointer hover-elevate active-elevate-2 transition-all duration-200",
        compact ? "" : ""
      )}
      onClick={onView}
      data-testid={`card-occurrence-${occurrence.id}`}
    >
      <div className="relative">
        {hasPhoto && primaryPhoto ? (
          <AspectRatio ratio={16 / 9} className="overflow-hidden rounded-t-md">
            <img
              src={primaryPhoto}
              alt={occurrence.titulo}
              className="w-full h-full object-cover"
              data-testid={`img-occurrence-${occurrence.id}`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
          </AspectRatio>
        ) : (
          <div className={cn(
            "rounded-t-md flex items-center justify-center",
            typeInfo.bgColor,
            compact ? "h-24" : "h-32"
          )}>
            <TypeIcon className={cn("h-12 w-12 opacity-30", typeInfo.iconColor)} />
          </div>
        )}

        <Badge
          variant="secondary"
          className={cn(
            "absolute top-3 left-3 gap-1.5 shadow-md font-medium",
            typeInfo.bgColor,
            typeInfo.iconColor,
            "border-0"
          )}
          data-testid={`badge-type-${occurrence.id}`}
        >
          <TypeIcon className="h-3.5 w-3.5" />
          {typeInfo.label}
        </Badge>

        <Badge
          variant="secondary"
          className={cn(
            "absolute top-3 right-3 gap-1.5 shadow-md font-medium",
            statusInfo.bgColor,
            statusInfo.textColor,
            "border-0"
          )}
          data-testid={`badge-status-${occurrence.id}`}
        >
          <StatusIcon className={cn("h-3.5 w-3.5", occurrence.status === "in_progress" && "animate-spin")} />
          {statusInfo.label}
        </Badge>

        {hasPhoto && occurrence.fotos!.length > 1 && (
          <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/60 rounded-md text-white text-xs font-medium">
            +{occurrence.fotos!.length - 1}
          </div>
        )}
      </div>

      <div className={cn("p-4", compact ? "pb-3" : "")}>
        <h3 className={cn(
          "font-semibold text-foreground leading-tight",
          compact ? "text-base line-clamp-1" : "text-lg line-clamp-2"
        )} data-testid={`text-title-${occurrence.id}`}>
          {occurrence.titulo}
        </h3>

        <p className={cn(
          "text-muted-foreground mt-2",
          compact ? "text-sm line-clamp-2" : "text-sm line-clamp-3"
        )} data-testid={`text-description-${occurrence.id}`}>
          {occurrence.descricao}
        </p>

        <div className="flex items-center justify-between gap-3 mt-4 pt-3 border-t border-border/50">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar className="h-7 w-7 flex-shrink-0">
              <AvatarImage src={undefined} />
              <AvatarFallback className="text-xs bg-primary/10 text-primary font-medium">
                {getInitials(occurrence.userId)}
              </AvatarFallback>
            </Avatar>
            <span className="text-sm text-muted-foreground truncate" data-testid={`text-author-${occurrence.id}`}>
              {occurrence.userId === "anonymous" ? "Anônimo" : occurrence.userId.substring(0, 8)}
            </span>
          </div>
          
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span className="text-sm" data-testid={`text-date-${occurrence.id}`}>
                {formatDate(occurrence.createdAt)}
              </span>
            </div>
            
            {(onEdit || onDelete) && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => e.stopPropagation()}
                    data-testid={`button-occurrence-menu-${occurrence.id}`}
                  >
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {onEdit && (
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit();
                      }}
                      data-testid={`button-edit-occurrence-${occurrence.id}`}
                    >
                      <Pencil className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                  )}
                  {onDelete && (
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete();
                      }}
                      className="text-destructive focus:text-destructive"
                      data-testid={`button-delete-occurrence-${occurrence.id}`}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
