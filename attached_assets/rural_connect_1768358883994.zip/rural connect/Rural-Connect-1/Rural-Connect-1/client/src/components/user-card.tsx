import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Phone } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import type { User } from "@shared/schema";

interface UserCardProps {
  user: User;
  onContact?: () => void;
  onViewLocation?: () => void;
}

export function UserCard({ user, onContact, onViewLocation }: UserCardProps) {
  const initials = user.nome
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const handleWhatsApp = () => {
    if (user.telefone) {
      const phone = user.telefone.replace(/\D/g, "");
      window.open(`https://wa.me/55${phone}`, "_blank");
    }
  };

  return (
    <Card className="hover-elevate" data-testid={`card-user-${user.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-primary text-primary-foreground font-medium">
              {initials}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-medium truncate">{user.nome}</h3>
            {user.propriedadeNome && (
              <p className="text-sm text-muted-foreground truncate">
                {user.propriedadeNome}
              </p>
            )}
            {user.latitude && user.longitude && (
              <button
                onClick={onViewLocation}
                className="flex items-center gap-1 text-xs text-primary mt-1"
                data-testid="button-view-location"
              >
                <MapPin className="h-3 w-3" />
                Ver no mapa
              </button>
            )}
          </div>

          {user.telefone && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleWhatsApp}
              className="text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-950"
              data-testid="button-whatsapp"
            >
              <SiWhatsapp className="h-5 w-5" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
