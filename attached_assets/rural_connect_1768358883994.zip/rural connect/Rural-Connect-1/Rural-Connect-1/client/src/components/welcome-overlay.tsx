import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  MapPin, 
  Camera, 
  Users, 
  CheckCircle2, 
  ArrowRight,
  X
} from "lucide-react";

const WELCOME_DISMISSED_KEY = "welcome-dismissed";

const features = [
  {
    icon: MapPin,
    title: "Mapeie Problemas",
    description: "Registre problemas de infraestrutura no mapa interativo",
    color: "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400",
  },
  {
    icon: Camera,
    title: "Documente com Fotos",
    description: "Tire fotos para documentar e dar visibilidade aos problemas",
    color: "bg-sky-100 text-sky-600 dark:bg-sky-900/30 dark:text-sky-400",
  },
  {
    icon: Users,
    title: "Una a Comunidade",
    description: "Organize petições e projetos coletivos para resolver problemas",
    color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400",
  },
  {
    icon: CheckCircle2,
    title: "Acompanhe Resultados",
    description: "Veja o progresso e celebre conquistas da comunidade",
    color: "bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400",
  },
];

export function WelcomeOverlay() {
  const [visible, setVisible] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const dismissed = localStorage.getItem(WELCOME_DISMISSED_KEY);
    if (!dismissed) {
      setVisible(true);
    }
  }, []);

  const handleDismiss = () => {
    localStorage.setItem(WELCOME_DISMISSED_KEY, "true");
    setVisible(false);
  };

  const handleNext = () => {
    if (step < features.length - 1) {
      setStep(step + 1);
    } else {
      handleDismiss();
    }
  };

  if (!visible) return null;

  const currentFeature = features[step];
  const Icon = currentFeature.icon;
  const isLastStep = step === features.length - 1;

  return (
    <div className="fixed inset-0 z-[2000] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-sm p-6 shadow-2xl relative animate-in fade-in slide-in-from-bottom-4 duration-300">
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-3 right-3"
          onClick={handleDismiss}
          data-testid="button-dismiss-welcome"
        >
          <X className="h-4 w-4" />
        </Button>

        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 text-xs text-muted-foreground mb-4">
            {features.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === step ? "w-6 bg-primary" : "w-1.5 bg-muted"
                }`}
              />
            ))}
          </div>

          <div className={`w-16 h-16 rounded-2xl ${currentFeature.color} flex items-center justify-center mx-auto mb-4 transition-all duration-300`}>
            <Icon className="h-8 w-8" />
          </div>

          <h2 className="text-xl font-semibold mb-2">{currentFeature.title}</h2>
          <p className="text-muted-foreground text-sm">{currentFeature.description}</p>
        </div>

        <div className="flex gap-2">
          <Button
            variant="ghost"
            className="flex-1"
            onClick={handleDismiss}
            data-testid="button-skip-welcome"
          >
            Pular
          </Button>
          <Button
            className="flex-1 gap-2"
            onClick={handleNext}
            data-testid="button-next-welcome"
          >
            {isLastStep ? "Começar" : "Próximo"}
            {!isLastStep && <ArrowRight className="h-4 w-4" />}
          </Button>
        </div>

        <div className="mt-6 pt-4 border-t text-center">
          <p className="text-xs text-muted-foreground font-medium">
            Comunidade Transamazônica
          </p>
          <p className="text-[10px] text-muted-foreground mt-1">
            Resolvendo problemas juntos
          </p>
        </div>
      </Card>
    </div>
  );
}
