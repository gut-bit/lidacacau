import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, ExternalLink } from "lucide-react";
import { SiWhatsapp, SiFacebook, SiInstagram } from "react-icons/si";
import type { Vicinal } from "@shared/schema";

interface VicinalCardProps {
  vicinal: Vicinal;
  memberCount?: number;
  occurrenceCount?: number;
  onView?: () => void;
}

export function VicinalCard({
  vicinal,
  memberCount = 0,
  occurrenceCount = 0,
  onView,
}: VicinalCardProps) {
  return (
    <Card className="hover-elevate cursor-pointer" onClick={onView} data-testid={`card-vicinal-${vicinal.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-semibold text-lg">{vicinal.nome}</h3>
            {vicinal.descricao && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {vicinal.descricao}
              </p>
            )}
          </div>
          <ExternalLink className="h-4 w-4 text-muted-foreground flex-shrink-0" />
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            {memberCount} membros
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {occurrenceCount} ocorrências
          </span>
        </div>

        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {vicinal.whatsappLink && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-green-600"
              onClick={() => window.open(vicinal.whatsappLink!, "_blank")}
              data-testid="button-whatsapp-group"
            >
              <SiWhatsapp className="h-4 w-4" />
            </Button>
          )}
          {vicinal.facebookLink && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-blue-600"
              onClick={() => window.open(vicinal.facebookLink!, "_blank")}
              data-testid="button-facebook"
            >
              <SiFacebook className="h-4 w-4" />
            </Button>
          )}
          {vicinal.instagramLink && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-pink-600"
              onClick={() => window.open(vicinal.instagramLink!, "_blank")}
              data-testid="button-instagram"
            >
              <SiInstagram className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
