import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ThermometerProgress } from "@/components/status-badge";
import { FileSignature, ChevronDown, ChevronUp, Share2 } from "lucide-react";
import { useState } from "react";
import type { Petition, Signature, User } from "@shared/schema";

interface PetitionCardProps {
  petition: Petition;
  signatures: Signature[];
  signatories?: User[];
  currentUserId?: string;
  onSign?: () => void;
  onShare?: () => void;
}

export function PetitionCard({
  petition,
  signatures,
  signatories = [],
  currentUserId,
  onSign,
  onShare,
}: PetitionCardProps) {
  const [showSignatories, setShowSignatories] = useState(false);
  
  const signatureCount = signatures.length;
  const targetCount = petition.targetSignatures || 50;
  const hasUserSigned = currentUserId 
    ? signatures.some(s => s.userId === currentUserId)
    : false;

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <Card data-testid={`card-petition-${petition.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileSignature className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">{petition.titulo}</h3>
          </div>
          <Badge variant="secondary" className="text-xs">
            {formatDate(petition.createdAt)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">{petition.descricao}</p>

        {petition.fotos && petition.fotos.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-2">
            {petition.fotos.map((foto, index) => (
              <img
                key={index}
                src={foto}
                alt={`Foto ${index + 1}`}
                className="h-24 w-32 rounded-lg object-cover flex-shrink-0"
              />
            ))}
          </div>
        )}

        <ThermometerProgress 
          current={signatureCount} 
          target={targetCount} 
        />

        {signatories.length > 0 && (
          <div>
            <button
              onClick={() => setShowSignatories(!showSignatories)}
              className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
              data-testid="button-toggle-signatories"
            >
              {showSignatories ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
              Ver assinaturas ({signatureCount})
            </button>
            
            {showSignatories && (
              <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
                {signatories.map((user) => (
                  <div 
                    key={user.id} 
                    className="text-sm py-1 px-2 bg-muted/50 rounded"
                  >
                    {user.nome}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>

      <CardFooter className="gap-2 flex-wrap">
        {!hasUserSigned && onSign && (
          <Button onClick={onSign} className="flex-1" data-testid="button-sign-petition">
            <FileSignature className="h-4 w-4 mr-2" />
            Assinar Abaixo-Assinado
          </Button>
        )}
        {hasUserSigned && (
          <Badge variant="secondary" className="bg-green-500/10 text-green-600">
            Você já assinou
          </Badge>
        )}
        {onShare && (
          <Button variant="outline" size="icon" onClick={onShare} data-testid="button-share-petition">
            <Share2 className="h-4 w-4" />
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
