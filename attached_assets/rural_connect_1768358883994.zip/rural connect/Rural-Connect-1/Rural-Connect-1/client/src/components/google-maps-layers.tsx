import { useEffect, useRef } from 'react';
import { useMap } from '@vis.gl/react-google-maps';

export function TrafficLayer() {
  const map = useMap();
  const layerRef = useRef<google.maps.TrafficLayer | null>(null);

  useEffect(() => {
    if (!map) return;

    const layer = new google.maps.TrafficLayer();
    layer.setMap(map);
    layerRef.current = layer;

    return () => {
      layer.setMap(null);
    };
  }, [map]);

  return null;
}

export function TransitLayer() {
  const map = useMap();
  const layerRef = useRef<google.maps.TransitLayer | null>(null);

  useEffect(() => {
    if (!map) return;

    const layer = new google.maps.TransitLayer();
    layer.setMap(map);
    layerRef.current = layer;

    return () => {
      layer.setMap(null);
    };
  }, [map]);

  return null;
}
