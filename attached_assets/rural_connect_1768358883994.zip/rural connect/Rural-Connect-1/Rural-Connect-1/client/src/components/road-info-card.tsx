import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { X, Building2, Pencil, Route, Home, Users, AlertTriangle, Tractor, Car, Plus } from "lucide-react";
import type { Road, Association, TrafegabilidadeEstado } from "@shared/schema";

export interface RoadInsights {
  road: Road;
  association: Association | null;
  membersCount: number;
  propertiesCount: number;
  openOccurrencesCount: number;
  occurrencesBySeverity: { open: number; in_progress: number; resolved: number };
  comprimentoMetros: number;
}

interface RoadInfoCardProps {
  roadId: string;
  onClose: () => void;
  onEditRoad: () => void;
  onAddOccurrence?: () => void;
}

const trafficabilityConfig: Record<TrafegabilidadeEstado, { label: string; className: string }> = {
  boa: { label: "Boa", className: "bg-green-500/10 text-green-600 dark:text-green-400" },
  regular: { label: "Regular", className: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400" },
  ruim: { label: "Ruim", className: "bg-orange-500/10 text-orange-600 dark:text-orange-400" },
  intransitavel: { label: "Intransitável", className: "bg-red-500/10 text-red-600 dark:text-red-400" },
};

function getOccurrenceColor(count: number): string {
  const maxCount = 5;
  const ratio = Math.min(count / maxCount, 1);
  const hue = 120 * (1 - ratio);
  return `hsl(${hue}, 70%, 50%)`;
}

function getOccurrenceBgClass(count: number): string {
  if (count === 0) return "bg-green-500/10 text-green-600 dark:text-green-400";
  if (count <= 2) return "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400";
  if (count <= 4) return "bg-orange-500/10 text-orange-600 dark:text-orange-400";
  return "bg-red-500/10 text-red-600 dark:text-red-400";
}

export function RoadInfoCard({ roadId, onClose, onEditRoad, onAddOccurrence }: RoadInfoCardProps) {
  const { data: insights, isLoading } = useQuery<RoadInsights>({
    queryKey: ["/api/roads", roadId, "insights"],
    queryFn: async () => {
      const res = await fetch(`/api/roads/${roadId}/insights`);
      if (!res.ok) throw new Error("Failed to fetch road insights");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <Card className="w-80 shadow-xl" data-testid="card-road-info-loading">
        <CardHeader className="pb-2 flex flex-row items-start justify-between gap-2">
          <div className="flex-1 space-y-2">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0"
            onClick={onClose}
            data-testid="button-close-road-info"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Skeleton className="h-9 flex-1" />
            <Skeleton className="h-9 flex-1" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!insights) {
    return (
      <Card className="w-80 shadow-xl" data-testid="card-road-info-error">
        <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
          <CardTitle className="text-base">Erro ao carregar</CardTitle>
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0"
            onClick={onClose}
            data-testid="button-close-road-info"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Não foi possível carregar os dados da estrada.
          </p>
        </CardContent>
      </Card>
    );
  }

  const { road, association, membersCount, propertiesCount, openOccurrencesCount, comprimentoMetros } = insights;
  const lengthKm = comprimentoMetros > 0 ? (comprimentoMetros / 1000).toFixed(1) : "N/A";
  const trafficability = road.trafegabilidade || "regular";
  const trafficConfig = trafficabilityConfig[trafficability as TrafegabilidadeEstado];
  const mainAgriculture = road.agriculturaPrincipal || "Não informado";

  return (
    <Card className="w-80 shadow-xl" data-testid={`card-road-info-${roadId}`}>
      <CardHeader className="pb-2 flex flex-row items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <CardTitle className="text-base leading-tight">{road.nome}</CardTitle>
          <Badge variant="outline" className="mt-1 text-xs">
            {road.classification === "principal" ? "Estrada Principal" : "Ramal/Vicinal"}
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="shrink-0"
          onClick={onClose}
          data-testid="button-close-road-info"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4 pt-0">
        <div className="flex gap-2 flex-wrap">
          {onAddOccurrence && (
            <Button variant="default" size="sm" onClick={onAddOccurrence} data-testid="button-add-occurrence-road">
              <Plus className="h-4 w-4 mr-1" />
              Nova Ocorrência
            </Button>
          )}
          {road.associationId && (
            <Button variant="outline" size="sm" asChild data-testid="button-view-association">
              <Link href="/associacao">
                <Building2 className="h-4 w-4 mr-1" />
                Ver Associação
              </Link>
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={onEditRoad} data-testid="button-edit-road">
            <Pencil className="h-4 w-4 mr-1" />
            Editar Estrada
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <Route className="h-3.5 w-3.5" />
              <span className="text-xs">Extensão</span>
            </div>
            <p className="text-sm font-medium">{lengthKm} km</p>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <Home className="h-3.5 w-3.5" />
              <span className="text-xs">Propriedades</span>
            </div>
            <p className="text-sm font-medium">{propertiesCount}</p>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <Users className="h-3.5 w-3.5" />
              <span className="text-xs">Membros</span>
            </div>
            <p className="text-sm font-medium">{membersCount}</p>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <Car className="h-3.5 w-3.5" />
              <span className="text-xs">Trafegabilidade</span>
            </div>
            <Badge className={`text-xs ${trafficConfig.className}`}>
              {trafficConfig.label}
            </Badge>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <AlertTriangle className="h-3.5 w-3.5" />
              <span className="text-xs">Ocorrências Abertas</span>
            </div>
            <Badge className={`text-xs ${getOccurrenceBgClass(openOccurrencesCount)}`}>
              {openOccurrencesCount}
            </Badge>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="flex items-center gap-1 text-muted-foreground mb-1">
              <Tractor className="h-3.5 w-3.5" />
              <span className="text-xs">Agricultura</span>
            </div>
            <p className="text-sm font-medium truncate" title={mainAgriculture}>
              {mainAgriculture}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
