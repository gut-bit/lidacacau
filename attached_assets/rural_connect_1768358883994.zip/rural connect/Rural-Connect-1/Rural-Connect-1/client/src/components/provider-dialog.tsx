import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Trash2, Loader2 } from "lucide-react";
import type { ServiceProvider, Vicinal, ServiceCategory, ProviderType } from "@shared/schema";

const serviceCategoryOptions: { value: ServiceCategory; label: string }[] = [
  { value: "trator_grade", label: "Trator com Grade" },
  { value: "escavadeira", label: "Escavadeira" },
  { value: "patrol", label: "Patrol" },
  { value: "cacamba", label: "Caçamba" },
  { value: "pipa_agua", label: "Pipa de Água" },
  { value: "eletricista", label: "Eletricista" },
  { value: "mecanico", label: "Mecânico" },
  { value: "transporte", label: "Transporte" },
  { value: "construcao", label: "Construção" },
  { value: "outro", label: "Outro" },
];

const priceUnitOptions = [
  { value: "hora", label: "Por Hora" },
  { value: "diaria", label: "Por Diária" },
  { value: "metro", label: "Por Metro" },
  { value: "hectare", label: "Por Hectare" },
  { value: "km", label: "Por Km" },
  { value: "viagem", label: "Por Viagem" },
  { value: "servico", label: "Por Serviço" },
];

const dayOfWeekOptions = [
  { value: 0, label: "Domingo" },
  { value: 1, label: "Segunda" },
  { value: 2, label: "Terça" },
  { value: 3, label: "Quarta" },
  { value: 4, label: "Quinta" },
  { value: 5, label: "Sexta" },
  { value: 6, label: "Sábado" },
];

const serviceSchema = z.object({
  categoria: z.string().min(1, "Selecione uma categoria"),
  nome: z.string().min(1, "Nome do serviço é obrigatório"),
  precoMinimo: z.coerce.number().optional(),
  precoMaximo: z.coerce.number().optional(),
  unidadePreco: z.string().optional(),
});

const formSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  tipo: z.enum(["empresa", "autonomo"]),
  cnpjCpf: z.string().optional(),
  telefone: z.string().min(10, "Telefone deve ter pelo menos 10 dígitos"),
  whatsapp: z.string().optional(),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  descricao: z.string().optional(),
  services: z.array(serviceSchema).min(1, "Adicione pelo menos um serviço"),
  coverageIds: z.array(z.string()),
  availableDays: z.array(z.number()),
});

type FormData = z.infer<typeof formSchema>;

interface ProviderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: Vicinal[];
  provider?: ServiceProvider | null;
  onSubmit: (data: FormData) => Promise<void>;
  mode?: "create" | "edit";
}

export function ProviderDialog({
  open,
  onOpenChange,
  vicinais,
  provider,
  onSubmit,
  mode = "create",
}: ProviderDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nome: provider?.nome || "",
      tipo: (provider?.tipo as ProviderType) || "autonomo",
      cnpjCpf: provider?.cnpjCpf || "",
      telefone: provider?.telefone || "",
      whatsapp: provider?.whatsapp || "",
      email: provider?.email || "",
      descricao: provider?.descricao || "",
      services: [{ categoria: "", nome: "", precoMinimo: undefined, precoMaximo: undefined, unidadePreco: "" }],
      coverageIds: [],
      availableDays: [1, 2, 3, 4, 5],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "services",
  });

  const handleSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      await onSubmit(data);
      onOpenChange(false);
      form.reset();
    } finally {
      setIsSubmitting(false);
    }
  };

  const addService = () => {
    append({ categoria: "", nome: "", precoMinimo: undefined, precoMaximo: undefined, unidadePreco: "" });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0" data-testid="dialog-provider">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle data-testid="text-dialog-title">
            {mode === "create" ? "Cadastrar Prestador de Serviço" : "Editar Prestador"}
          </DialogTitle>
          <DialogDescription>
            Preencha os dados do prestador de serviço
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-120px)]">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6 p-6 pt-4">
              <div className="space-y-4">
                <h4 className="font-medium text-sm text-muted-foreground">Informações Básicas</h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="nome"
                    render={({ field }) => (
                      <FormItem className="col-span-2 sm:col-span-1">
                        <FormLabel>Nome *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Nome do prestador" 
                            {...field} 
                            data-testid="input-provider-nome"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="tipo"
                    render={({ field }) => (
                      <FormItem className="col-span-2 sm:col-span-1">
                        <FormLabel>Tipo *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-provider-tipo">
                              <SelectValue placeholder="Selecione o tipo" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="empresa">Empresa</SelectItem>
                            <SelectItem value="autonomo">Autônomo</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="cnpjCpf"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CNPJ/CPF</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="00.000.000/0000-00 ou 000.000.000-00" 
                          {...field} 
                          data-testid="input-provider-cnpjcpf"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="telefone"
                    render={({ field }) => (
                      <FormItem className="col-span-2 sm:col-span-1">
                        <FormLabel>Telefone *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="(00) 00000-0000" 
                            {...field} 
                            data-testid="input-provider-telefone"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="whatsapp"
                    render={({ field }) => (
                      <FormItem className="col-span-2 sm:col-span-1">
                        <FormLabel>WhatsApp</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="(00) 00000-0000" 
                            {...field} 
                            data-testid="input-provider-whatsapp"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="email@exemplo.com" 
                          {...field} 
                          data-testid="input-provider-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="descricao"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descrição</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Descreva os serviços oferecidos..." 
                          className="resize-none"
                          rows={3}
                          {...field} 
                          data-testid="textarea-provider-descricao"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-sm text-muted-foreground">Serviços Oferecidos *</h4>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addService}
                    data-testid="button-add-service"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Adicionar
                  </Button>
                </div>

                {fields.map((field, index) => (
                  <div 
                    key={field.id} 
                    className="p-4 border rounded-md space-y-3 bg-muted/30"
                    data-testid={`service-form-${index}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Serviço {index + 1}</span>
                      {fields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => remove(index)}
                          className="h-8 w-8 text-destructive"
                          data-testid={`button-remove-service-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <FormField
                        control={form.control}
                        name={`services.${index}.categoria`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Categoria</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-service-categoria-${index}`}>
                                  <SelectValue placeholder="Selecione" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {serviceCategoryOptions.map((opt) => (
                                  <SelectItem key={opt.value} value={opt.value}>
                                    {opt.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`services.${index}.nome`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Nome do Serviço</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Ex: Grade de disco" 
                                {...field}
                                data-testid={`input-service-nome-${index}`}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <FormField
                        control={form.control}
                        name={`services.${index}.precoMinimo`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Preço Mín.</FormLabel>
                            <FormControl>
                              <Input 
                                type="number"
                                step="0.01"
                                placeholder="R$ 0,00"
                                {...field}
                                value={field.value ?? ""}
                                data-testid={`input-service-preco-min-${index}`}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`services.${index}.precoMaximo`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Preço Máx.</FormLabel>
                            <FormControl>
                              <Input 
                                type="number"
                                step="0.01"
                                placeholder="R$ 0,00"
                                {...field}
                                value={field.value ?? ""}
                                data-testid={`input-service-preco-max-${index}`}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`services.${index}.unidadePreco`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Unidade</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-service-unidade-${index}`}>
                                  <SelectValue placeholder="Selecione" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {priceUnitOptions.map((opt) => (
                                  <SelectItem key={opt.value} value={opt.value}>
                                    {opt.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}
                {form.formState.errors.services?.message && (
                  <p className="text-sm text-destructive">{form.formState.errors.services.message}</p>
                )}
              </div>

              <div className="space-y-4">
                <h4 className="font-medium text-sm text-muted-foreground">Regiões Atendidas</h4>
                
                <FormField
                  control={form.control}
                  name="coverageIds"
                  render={({ field }) => (
                    <FormItem>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {vicinais.map((vicinal) => (
                          <div
                            key={vicinal.id}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={`vicinal-${vicinal.id}`}
                              checked={field.value?.includes(vicinal.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  field.onChange([...field.value, vicinal.id]);
                                } else {
                                  field.onChange(field.value.filter((id) => id !== vicinal.id));
                                }
                              }}
                              data-testid={`checkbox-vicinal-${vicinal.id}`}
                            />
                            <label
                              htmlFor={`vicinal-${vicinal.id}`}
                              className="text-sm cursor-pointer"
                            >
                              {vicinal.nome}
                            </label>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <h4 className="font-medium text-sm text-muted-foreground">Disponibilidade</h4>
                
                <FormField
                  control={form.control}
                  name="availableDays"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex flex-wrap gap-2">
                        {dayOfWeekOptions.map((day) => (
                          <div
                            key={day.value}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={`day-${day.value}`}
                              checked={field.value?.includes(day.value)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  field.onChange([...field.value, day.value]);
                                } else {
                                  field.onChange(field.value.filter((d) => d !== day.value));
                                }
                              }}
                              data-testid={`checkbox-day-${day.value}`}
                            />
                            <label
                              htmlFor={`day-${day.value}`}
                              className="text-sm cursor-pointer"
                            >
                              {day.label}
                            </label>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  className="flex-1"
                  data-testid="button-cancel"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1"
                  data-testid="button-submit-provider"
                >
                  {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {mode === "create" ? "Cadastrar" : "Salvar"}
                </Button>
              </div>
            </form>
          </Form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
