import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { AlertCircle, Loader2, CheckCircle2, Users } from "lucide-react";
import type { OccurrenceStatus } from "@shared/schema";

const statusConfig: Record<OccurrenceStatus, { 
  icon: typeof AlertCircle;
  bgColor: string; 
  textColor: string;
  label: string;
}> = {
  open: { 
    icon: AlertCircle,
    bgColor: "bg-amber-100 dark:bg-amber-900/50", 
    textColor: "text-amber-700 dark:text-amber-300",
    label: "Aberto" 
  },
  in_progress: { 
    icon: Loader2,
    bgColor: "bg-blue-100 dark:bg-blue-900/50", 
    textColor: "text-blue-700 dark:text-blue-300",
    label: "Em Andamento" 
  },
  resolved: { 
    icon: CheckCircle2,
    bgColor: "bg-green-100 dark:bg-green-900/50", 
    textColor: "text-green-700 dark:text-green-300",
    label: "Resolvido" 
  },
};

interface StatusBadgeProps {
  status: OccurrenceStatus;
  className?: string;
  showIcon?: boolean;
}

export function StatusBadge({ status, className, showIcon = true }: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig.open;
  const Icon = config.icon;
  
  return (
    <Badge
      variant="secondary"
      className={cn(
        "gap-1.5 font-medium border-0",
        config.bgColor,
        config.textColor,
        className
      )}
      data-testid={`status-badge-${status}`}
    >
      {showIcon && (
        <Icon className={cn("h-3.5 w-3.5", status === "in_progress" && "animate-spin")} />
      )}
      {config.label}
    </Badge>
  );
}

interface SignatureProgressProps {
  current: number;
  target: number;
  className?: string;
  showMilestones?: boolean;
  size?: "sm" | "md" | "lg";
}

export function SignatureProgress({ 
  current, 
  target, 
  className,
  showMilestones = true,
  size = "md"
}: SignatureProgressProps) {
  const progress = Math.min((current / target) * 100, 100);
  const milestones = [25, 50, 75, 100];
  
  const heightClass = {
    sm: "h-2",
    md: "h-3",
    lg: "h-4"
  };
  
  const getProgressColor = () => {
    if (progress >= 100) return "bg-green-500 dark:bg-green-400";
    if (progress >= 75) return "bg-emerald-500 dark:bg-emerald-400";
    if (progress >= 50) return "bg-blue-500 dark:bg-blue-400";
    if (progress >= 25) return "bg-amber-500 dark:bg-amber-400";
    return "bg-primary";
  };
  
  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center justify-between text-sm">
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <Users className="h-4 w-4" />
          <span className="font-medium text-foreground">{current}</span>
          <span>de {target} assinaturas</span>
        </span>
        <span className={cn(
          "font-semibold",
          progress >= 100 ? "text-green-600 dark:text-green-400" : "text-primary"
        )}>
          {Math.round(progress)}%
        </span>
      </div>
      
      <div className="relative">
        <div className={cn(
          "relative w-full overflow-hidden rounded-full bg-secondary",
          heightClass[size]
        )}>
          <div
            className={cn(
              "h-full transition-all duration-500 ease-out rounded-full",
              getProgressColor()
            )}
            style={{ width: `${progress}%` }}
          />
        </div>
        
        {showMilestones && (
          <div className="absolute inset-0 flex">
            {milestones.map((milestone) => (
              <div
                key={milestone}
                className="relative"
                style={{ left: `${milestone}%`, position: 'absolute' }}
              >
                <div className={cn(
                  "absolute -translate-x-1/2 top-0 w-0.5 rounded-full",
                  heightClass[size],
                  progress >= milestone 
                    ? "bg-white/60" 
                    : "bg-muted-foreground/30"
                )} />
              </div>
            ))}
          </div>
        )}
      </div>
      
      {showMilestones && (
        <div className="flex justify-between text-xs text-muted-foreground">
          {milestones.map((milestone) => (
            <span
              key={milestone}
              className={cn(
                "transition-colors",
                progress >= milestone && "text-foreground font-medium"
              )}
              style={{ width: '25%', textAlign: milestone === 25 ? 'left' : milestone === 100 ? 'right' : 'center' }}
            >
              {milestone}%
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

interface ThermometerProgressProps {
  current: number;
  target: number;
  className?: string;
}

export function ThermometerProgress({ 
  current, 
  target, 
  className 
}: ThermometerProgressProps) {
  const progress = Math.min((current / target) * 100, 100);
  const milestones = [
    { value: 25, label: "25%" },
    { value: 50, label: "50%" },
    { value: 75, label: "75%" },
    { value: 100, label: "Meta" },
  ];
  
  const getProgressColor = () => {
    if (progress >= 100) return "from-green-400 to-green-600";
    if (progress >= 75) return "from-emerald-400 to-emerald-600";
    if (progress >= 50) return "from-blue-400 to-blue-600";
    if (progress >= 25) return "from-amber-400 to-amber-600";
    return "from-orange-400 to-orange-600";
  };
  
  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-baseline justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          <span className="text-2xl font-bold text-foreground">{current}</span>
          <span className="text-muted-foreground">de {target}</span>
        </div>
        <Badge 
          variant="secondary" 
          className={cn(
            "font-semibold",
            progress >= 100 
              ? "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300" 
              : ""
          )}
        >
          {progress >= 100 ? "Meta atingida!" : `${Math.round(progress)}%`}
        </Badge>
      </div>
      
      <div className="relative">
        <div className="h-6 w-full overflow-hidden rounded-full bg-secondary border border-border/50">
          <div
            className={cn(
              "h-full transition-all duration-700 ease-out rounded-full bg-gradient-to-r shadow-sm",
              getProgressColor()
            )}
            style={{ width: `${Math.max(progress, 2)}%` }}
          />
        </div>
        
        <div className="absolute inset-0 flex items-center pointer-events-none">
          {milestones.map((milestone) => (
            <div
              key={milestone.value}
              className="absolute flex flex-col items-center"
              style={{ 
                left: `${milestone.value}%`,
                transform: 'translateX(-50%)'
              }}
            >
              <div className={cn(
                "w-1 h-6 rounded-full transition-colors",
                progress >= milestone.value 
                  ? "bg-white/50" 
                  : "bg-muted-foreground/20"
              )} />
            </div>
          ))}
        </div>
      </div>
      
      <div className="relative h-4">
        {milestones.map((milestone) => (
          <span
            key={milestone.value}
            className={cn(
              "absolute text-xs transition-colors -translate-x-1/2",
              progress >= milestone.value 
                ? "text-foreground font-medium" 
                : "text-muted-foreground"
            )}
            style={{ left: `${milestone.value}%` }}
          >
            {milestone.label}
          </span>
        ))}
      </div>
    </div>
  );
}
