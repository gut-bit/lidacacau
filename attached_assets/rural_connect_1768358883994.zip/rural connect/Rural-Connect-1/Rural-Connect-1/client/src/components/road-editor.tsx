import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Route, Trash2, Save, X, Pencil, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { MinimizableCard, useMinimizableCards } from "@/components/minimizable-cards";
import type { Road, RoadClassification } from "@shared/schema";

interface RoadEditorProps {
  isDrawing: boolean;
  drawingPoints: [number, number][];
  onStartDrawing: () => void;
  onCancelDrawing: () => void;
  onSaveRoad: (name: string, classification: RoadClassification) => void;
}

export function RoadEditorToolbar({
  isDrawing,
  drawingPoints,
  onStartDrawing,
  onCancelDrawing,
  onSaveRoad,
}: RoadEditorProps) {
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [roadName, setRoadName] = useState("");
  const [classification, setClassification] = useState<RoadClassification>("ramal");

  const handleSave = () => {
    if (roadName.trim() && drawingPoints.length >= 2) {
      onSaveRoad(roadName.trim(), classification);
      setShowSaveDialog(false);
      setRoadName("");
      setClassification("ramal");
    }
  };

  if (!isDrawing) {
    return (
      <Button
        variant="default"
        size="default"
        className="absolute top-4 left-4 z-[1000] shadow-lg gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium"
        onClick={onStartDrawing}
        data-testid="button-start-road-drawing"
      >
        <Pencil className="h-4 w-4" />
        Desenhar Estrada
      </Button>
    );
  }

  return (
    <>
      <div className="absolute top-4 left-4 z-[1000] bg-card p-3 rounded-lg shadow-lg border space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Route className="h-4 w-4 text-primary" />
          Modo Desenho
        </div>
        <p className="text-xs text-muted-foreground">
          Toque no mapa para adicionar marcadores.
          <br />
          A linha azul conecta os pontos automaticamente.
          <br />
          <span className="font-medium text-foreground">Marcadores: {drawingPoints.length}</span>
        </p>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onCancelDrawing}
            data-testid="button-cancel-drawing"
          >
            <X className="h-4 w-4 mr-1" />
            Cancelar
          </Button>
          <Button
            size="sm"
            disabled={drawingPoints.length < 2}
            onClick={() => setShowSaveDialog(true)}
            data-testid="button-save-road"
          >
            <Save className="h-4 w-4 mr-1" />
            Salvar
          </Button>
        </div>
      </div>

      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Salvar Estrada</DialogTitle>
            <DialogDescription>
              Dê um nome para esta estrada e escolha o tipo.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Nome da Estrada</label>
              <Input
                value={roadName}
                onChange={(e) => setRoadName(e.target.value)}
                placeholder="Ex: Vicinal km 140 Norte"
                data-testid="input-road-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Tipo</label>
              <Select
                value={classification}
                onValueChange={(v) => setClassification(v as RoadClassification)}
              >
                <SelectTrigger data-testid="select-road-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="principal">Estrada Principal (BR-230)</SelectItem>
                  <SelectItem value="ramal">Ramal / Vicinal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowSaveDialog(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSave}
                disabled={!roadName.trim()}
                className="flex-1"
                data-testid="button-confirm-save-road"
              >
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

interface RoadListProps {
  onDeleteRoad: (id: string) => void;
}

export function RoadList({ onDeleteRoad }: RoadListProps) {
  const { data: roads = [], isLoading } = useQuery<Road[]>({
    queryKey: ["/api/roads"],
  });
  const { isMinimized } = useMinimizableCards();

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/roads/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roads"] });
    },
  });

  if (isLoading || roads.length === 0 || isMinimized("saved-roads")) return null;

  return (
    <div className="absolute top-16 left-4 z-[1000] max-w-[200px]">
      <MinimizableCard
        id="saved-roads"
        title="Estradas Salvas"
        icon={<Route className="h-3 w-3 text-blue-500" />}
        className="max-h-[200px]"
      >
        <div className="space-y-1 max-h-[120px] overflow-y-auto">
          {roads.map((road) => (
            <div
              key={road.id}
              className="flex items-center justify-between gap-2 text-xs p-1.5 bg-muted/50 rounded"
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <div
                  className={`w-2 h-2 rounded-full ${
                    road.classification === "principal" ? "bg-[#ff7f50]" : "bg-[#2563eb]"
                  }`}
                />
                <span className="truncate">{road.nome}</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 shrink-0"
                onClick={() => {
                  deleteMutation.mutate(road.id);
                  onDeleteRoad(road.id);
                }}
                disabled={deleteMutation.isPending}
                data-testid={`button-delete-road-${road.id}`}
              >
                {deleteMutation.isPending ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <Trash2 className="h-3 w-3" />
                )}
              </Button>
            </div>
          ))}
        </div>
      </MinimizableCard>
    </div>
  );
}
