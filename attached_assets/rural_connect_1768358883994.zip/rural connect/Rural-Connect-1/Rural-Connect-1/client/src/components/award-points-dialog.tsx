import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Zap,
  Heart,
  Hammer,
  DollarSign,
  Users,
  MoreHorizontal,
} from "lucide-react";
import type { PointActionType } from "@shared/schema";

const actionTypeLabels: Record<string, { label: string; icon: React.ComponentType<{ className?: string }>; defaultPoints: number }> = {
  limpeza_rede: { label: "Limpeza da Rede Elétrica", icon: Zap, defaultPoints: 20 },
  bom_vizinho: { label: "Ser Bom Vizinho", icon: Heart, defaultPoints: 15 },
  contribuicao_trabalho: { label: "Contribuição com Trabalho", icon: Hammer, defaultPoints: 25 },
  contribuicao_financeira: { label: "Contribuição Financeira", icon: DollarSign, defaultPoints: 30 },
  participacao_projeto: { label: "Participação em Projeto", icon: Users, defaultPoints: 20 },
  outro: { label: "Outra Ação", icon: MoreHorizontal, defaultPoints: 10 },
};

const formSchema = z.object({
  tipoAcao: z.string().min(1, "Selecione o tipo de ação"),
  descricao: z.string().min(3, "Descreva a ação realizada"),
  pontos: z.coerce.number().min(1, "Pontos devem ser maior que 0").max(100, "Máximo de 100 pontos"),
});

type FormData = z.infer<typeof formSchema>;

interface AwardPointsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
}

export function AwardPointsDialog({ open, onOpenChange, userId }: AwardPointsDialogProps) {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tipoAcao: "",
      descricao: "",
      pontos: 10,
    },
  });

  const awardPoints = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/points/award", {
        userId,
        tipoAcao: data.tipoAcao as PointActionType,
        pontos: data.pontos,
        descricao: data.descricao,
        awardedBy: userId,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/points/user", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/points/events", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/points/leaderboard"] });
      toast({
        title: "Pontos registrados",
        description: "Sua ação foi registrada com sucesso!",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível registrar os pontos.",
        variant: "destructive",
      });
    },
  });

  const handleActionTypeChange = (value: string) => {
    form.setValue("tipoAcao", value);
    const actionData = actionTypeLabels[value];
    if (actionData) {
      form.setValue("pontos", actionData.defaultPoints);
    }
  };

  const onSubmit = (data: FormData) => {
    awardPoints.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Registrar Ação Comunitária</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="tipoAcao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Ação</FormLabel>
                  <Select
                    onValueChange={handleActionTypeChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-action-type">
                        <SelectValue placeholder="Selecione o tipo de ação" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Object.entries(actionTypeLabels).map(([key, { label, icon: Icon }]) => (
                        <SelectItem key={key} value={key} data-testid={`option-${key}`}>
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4" />
                            <span>{label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descricao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descreva a ação realizada..."
                      className="resize-none"
                      {...field}
                      data-testid="input-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="pontos"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pontos</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      max={100}
                      {...field}
                      data-testid="input-points"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-2 justify-end pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={awardPoints.isPending}
                data-testid="button-submit"
              >
                {awardPoints.isPending ? "Registrando..." : "Registrar"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export { actionTypeLabels };
