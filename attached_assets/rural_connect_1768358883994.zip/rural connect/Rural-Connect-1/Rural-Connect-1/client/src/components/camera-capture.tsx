import { useState, useRef, useCallback, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Camera, X, Check, MapPin, Clock, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Vicinal, OccurrenceType } from "@shared/schema";

interface CameraCaptureProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: Vicinal[];
  onCapture: (data: {
    photo: string;
    titulo: string;
    descricao: string;
    tipo: OccurrenceType;
    vicinalId: string;
    latitude: number;
    longitude: number;
    timestamp: string;
  }) => void;
}

const occurrenceTypes: { value: OccurrenceType; label: string }[] = [
  { value: "electrical", label: "Rede Elétrica" },
  { value: "road", label: "Estrada" },
  { value: "bridge", label: "Ponte" },
  { value: "social", label: "Social" },
  { value: "theft", label: "Roubo de Safra" },
  { value: "other", label: "Outro" },
];

export function CameraCapture({ open, onOpenChange, vicinais, onCapture }: CameraCaptureProps) {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [step, setStep] = useState<"camera" | "form">("camera");
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [timestamp, setTimestamp] = useState<string>("");
  const [loadingLocation, setLoadingLocation] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [tipo, setTipo] = useState<OccurrenceType>("road");
  const [vicinalId, setVicinalId] = useState("");

  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera error:", err);
      setCameraError("Não foi possível acessar a câmera. Verifique as permissões.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  }, []);

  const getLocation = useCallback(() => {
    setLoadingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLoadingLocation(false);
      },
      (err) => {
        console.error("Location error:", err);
        setLocation(null);
        setLoadingLocation(false);
        toast({
          title: "Localização não disponível",
          description: "Ative a localização para registrar ocorrências.",
          variant: "destructive",
        });
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, [toast]);

  useEffect(() => {
    if (open && step === "camera") {
      startCamera();
      getLocation();
      setTimestamp(new Date().toISOString());
    }
    return () => {
      if (!open) {
        stopCamera();
      }
    };
  }, [open, step, startCamera, stopCamera, getLocation]);

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);

    const now = new Date();
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, canvas.height - 60, canvas.width, 60);
    ctx.fillStyle = "white";
    ctx.font = "16px Arial";
    ctx.fillText(`Data: ${now.toLocaleDateString("pt-BR")} ${now.toLocaleTimeString("pt-BR")}`, 10, canvas.height - 35);
    if (location) {
      ctx.fillText(`Local: ${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}`, 10, canvas.height - 10);
    }

    const photoData = canvas.toDataURL("image/jpeg", 0.8);
    setCapturedPhoto(photoData);
    setTimestamp(now.toISOString());
    stopCamera();
    setStep("form");
  };

  const handleSubmit = () => {
    if (!capturedPhoto || !location || !titulo.trim() || !vicinalId) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    onCapture({
      photo: capturedPhoto,
      titulo: titulo.trim(),
      descricao: descricao.trim(),
      tipo,
      vicinalId,
      latitude: location.lat,
      longitude: location.lng,
      timestamp,
    });

    resetForm();
    onOpenChange(false);
  };

  const resetForm = () => {
    setStep("camera");
    setCapturedPhoto(null);
    setTitulo("");
    setDescricao("");
    setTipo("road");
    setVicinalId("");
    setCameraError(null);
  };

  const handleClose = () => {
    stopCamera();
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md p-0 overflow-hidden">
        <DialogHeader className="p-4 pb-2">
          <DialogTitle>
            {step === "camera" ? "Capturar Ocorrência" : "Detalhes da Ocorrência"}
          </DialogTitle>
          <DialogDescription>
            {step === "camera"
              ? "Tire uma foto do problema para registrar."
              : "Complete as informações da ocorrência."}
          </DialogDescription>
        </DialogHeader>

        {step === "camera" ? (
          <div className="relative">
            {cameraError ? (
              <div className="aspect-video bg-muted flex flex-col items-center justify-center p-4 text-center">
                <Camera className="h-12 w-12 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">{cameraError}</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={startCamera} data-testid="button-camera-retry">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Tentar novamente
                </Button>
              </div>
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full aspect-video object-cover bg-black"
              />
            )}
            <canvas ref={canvasRef} className="hidden" />

            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <div className="bg-black/60 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                {loadingLocation ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : location ? (
                  <>
                    <MapPin className="h-3 w-3" />
                    <span>{location.lat.toFixed(4)}, {location.lng.toFixed(4)}</span>
                  </>
                ) : (
                  <span>Sem localização</span>
                )}
              </div>
              <div className="bg-black/60 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{new Date().toLocaleTimeString("pt-BR")}</span>
              </div>
            </div>

            <div className="p-4 flex gap-2">
              <Button variant="outline" className="flex-1" onClick={handleClose} data-testid="button-camera-cancel">
                <X className="h-4 w-4 mr-2" />
                Cancelar
              </Button>
              <Button
                className="flex-1"
                onClick={capturePhoto}
                disabled={!!cameraError || loadingLocation || !location}
                data-testid="button-camera-capture-photo"
              >
                <Camera className="h-4 w-4 mr-2" />
                Capturar
              </Button>
            </div>
          </div>
        ) : (
          <div className="p-4 pt-0 space-y-4">
            {capturedPhoto && (
              <img
                src={capturedPhoto}
                alt="Foto capturada"
                className="w-full rounded-md border"
              />
            )}

            <div>
              <label className="text-sm font-medium">Título *</label>
              <Input
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                placeholder="Ex: Buraco na estrada km 85"
                data-testid="input-capture-title"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Descrição</label>
              <Input
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                placeholder="Descreva o problema..."
                data-testid="input-capture-description"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Tipo *</label>
              <Select value={tipo} onValueChange={(v) => setTipo(v as OccurrenceType)}>
                <SelectTrigger data-testid="select-capture-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {occurrenceTypes.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Vicinal *</label>
              <Select value={vicinalId} onValueChange={setVicinalId}>
                <SelectTrigger data-testid="select-capture-vicinal">
                  <SelectValue placeholder="Selecione a vicinal" />
                </SelectTrigger>
                <SelectContent>
                  {vicinais.map((v) => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setStep("camera")} data-testid="button-camera-retake">
                <RefreshCw className="h-4 w-4 mr-2" />
                Nova Foto
              </Button>
              <Button className="flex-1" onClick={handleSubmit} data-testid="button-camera-submit">
                <Check className="h-4 w-4 mr-2" />
                Registrar
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
