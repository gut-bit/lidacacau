import { useQuery } from "@tanstack/react-query";
import { Star, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { UserPoints } from "@shared/schema";

interface PointsBadgeProps {
  userId: string | null;
  className?: string;
  showLevel?: boolean;
}

export function PointsBadge({ userId, className, showLevel = true }: PointsBadgeProps) {
  const { data: userPoints } = useQuery<UserPoints>({
    queryKey: ["/api/points/user", userId],
    queryFn: async () => {
      if (!userId) return { userId: "", totalPontos: 0, pontosDoMes: 0, nivel: 1, updatedAt: "", id: "" };
      const res = await fetch(`/api/points/user/${userId}`);
      return res.json();
    },
    enabled: !!userId,
  });

  if (!userId || !userPoints) {
    return null;
  }

  const totalPontos = userPoints.totalPontos || 0;
  const nivel = userPoints.nivel || 1;

  return (
    <div className={cn("flex items-center gap-2", className)} data-testid="points-badge">
      <Badge variant="secondary" className="gap-1.5 px-2.5 py-1">
        <Star className="h-3.5 w-3.5 text-yellow-500 fill-yellow-500" />
        <span className="font-semibold" data-testid="text-total-points">{totalPontos}</span>
        <span className="text-muted-foreground">pts</span>
      </Badge>
      {showLevel && (
        <Badge variant="outline" className="gap-1 px-2 py-1">
          <TrendingUp className="h-3 w-3 text-primary" />
          <span data-testid="text-level">Nv. {nivel}</span>
        </Badge>
      )}
    </div>
  );
}
