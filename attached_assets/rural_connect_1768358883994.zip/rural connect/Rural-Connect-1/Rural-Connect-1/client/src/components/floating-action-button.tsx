import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Plus,
  X,
  Zap,
  Construction,
  Mountain,
  Users,
  ShieldAlert,
  HelpCircle,
  Camera,
} from "lucide-react";
import type { OccurrenceType } from "@shared/schema";

interface FloatingActionButtonProps {
  onSelectPinType: (type: OccurrenceType) => void;
  onOpenCamera: () => void;
  disabled?: boolean;
}

const pinTypes: { type: OccurrenceType; icon: typeof Zap; label: string; bgColor: string; iconColor: string }[] = [
  { type: "electrical", icon: Zap, label: "Elétrica", bgColor: "bg-amber-100 dark:bg-amber-900/30", iconColor: "text-amber-600 dark:text-amber-400" },
  { type: "road", icon: Construction, label: "Estrada", bgColor: "bg-orange-100 dark:bg-orange-900/30", iconColor: "text-orange-600 dark:text-orange-400" },
  { type: "bridge", icon: Mountain, label: "Ponte", bgColor: "bg-sky-100 dark:bg-sky-900/30", iconColor: "text-sky-600 dark:text-sky-400" },
  { type: "social", icon: Users, label: "Social", bgColor: "bg-emerald-100 dark:bg-emerald-900/30", iconColor: "text-emerald-600 dark:text-emerald-400" },
  { type: "theft", icon: ShieldAlert, label: "Roubo", bgColor: "bg-red-100 dark:bg-red-900/30", iconColor: "text-red-600 dark:text-red-400" },
  { type: "other", icon: HelpCircle, label: "Outro", bgColor: "bg-slate-100 dark:bg-slate-800/50", iconColor: "text-slate-600 dark:text-slate-400" },
];

const STORAGE_KEY = "fab-position";

export function FloatingActionButton({ onSelectPinType, onOpenCamera, disabled }: FloatingActionButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: window.innerHeight - 200 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const fabRef = useRef<HTMLDivElement>(null);
  const dragStartTime = useRef<number>(0);
  const hasMoved = useRef(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setPosition({
          x: Math.min(Math.max(0, parsed.x), window.innerWidth - 60),
          y: Math.min(Math.max(0, parsed.y), window.innerHeight - 200),
        });
      } catch {
        // Use default
      }
    }
  }, []);

  const savePosition = useCallback((pos: { x: number; y: number }) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(pos));
  }, []);

  const constrainPosition = useCallback((x: number, y: number) => {
    const padding = 10;
    const fabSize = 48;
    const bottomNavHeight = 90;
    
    return {
      x: Math.max(padding, Math.min(x, window.innerWidth - fabSize - padding)),
      y: Math.max(padding, Math.min(y, window.innerHeight - fabSize - bottomNavHeight - padding)),
    };
  }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (disabled) return;
    const touch = e.touches[0];
    const rect = fabRef.current?.getBoundingClientRect();
    if (!rect) return;

    dragStartTime.current = Date.now();
    hasMoved.current = false;
    setDragOffset({
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top,
    });
    setIsDragging(true);
  }, [disabled]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const newX = touch.clientX - dragOffset.x;
    const newY = touch.clientY - dragOffset.y;
    
    if (Math.abs(newX - position.x) > 5 || Math.abs(newY - position.y) > 5) {
      hasMoved.current = true;
    }
    
    const constrained = constrainPosition(newX, newY);
    setPosition(constrained);
  }, [isDragging, dragOffset, position, constrainPosition]);

  const handleTouchEnd = useCallback(() => {
    if (isDragging) {
      savePosition(position);
      setIsDragging(false);
      
      const dragDuration = Date.now() - dragStartTime.current;
      if (!hasMoved.current && dragDuration < 200) {
        setIsOpen((prev) => !prev);
      }
    }
  }, [isDragging, position, savePosition]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (disabled) return;
    const rect = fabRef.current?.getBoundingClientRect();
    if (!rect) return;

    dragStartTime.current = Date.now();
    hasMoved.current = false;
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    setIsDragging(true);
  }, [disabled]);

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      
      if (Math.abs(newX - position.x) > 5 || Math.abs(newY - position.y) > 5) {
        hasMoved.current = true;
      }
      
      const constrained = constrainPosition(newX, newY);
      setPosition(constrained);
    };

    const handleMouseUp = () => {
      savePosition(position);
      setIsDragging(false);
      
      const dragDuration = Date.now() - dragStartTime.current;
      if (!hasMoved.current && dragDuration < 200) {
        setIsOpen((prev) => !prev);
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, dragOffset, position, constrainPosition, savePosition]);

  const handleSelectPin = (type: OccurrenceType) => {
    setIsOpen(false);
    onSelectPinType(type);
  };

  const handleCamera = () => {
    setIsOpen(false);
    onOpenCamera();
  };

  return (
    <div
      ref={fabRef}
      className="fixed z-[1001] select-none touch-none"
      style={{
        left: position.x,
        top: position.y,
        transition: isDragging ? "none" : "box-shadow 0.2s, transform 0.2s",
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
    >
      {isOpen && (
        <Card className="absolute bottom-16 left-0 p-4 shadow-2xl min-w-[220px] border-card-border animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="text-sm font-semibold mb-3 text-foreground">Registrar Problema</div>
          <div className="grid grid-cols-3 gap-2 mb-4">
            {pinTypes.map(({ type, icon: Icon, label, bgColor, iconColor }) => (
              <button
                key={type}
                className="flex flex-col items-center gap-1.5 p-2 rounded-xl hover-elevate active-elevate-2 transition-transform"
                onClick={() => handleSelectPin(type)}
                data-testid={`button-pin-${type}`}
              >
                <div className={`w-11 h-11 rounded-xl ${bgColor} flex items-center justify-center transition-transform`}>
                  <Icon className={`h-5 w-5 ${iconColor}`} />
                </div>
                <span className="text-[11px] font-medium text-center leading-tight">{label}</span>
              </button>
            ))}
          </div>
          <Button
            variant="secondary"
            size="default"
            className="w-full gap-2 font-medium"
            onClick={handleCamera}
            data-testid="button-fab-camera"
          >
            <Camera className="h-4 w-4" />
            Tirar Foto
          </Button>
        </Card>
      )}

      <Button
        size="lg"
        className={`h-12 w-12 rounded-full shadow-xl transition-all duration-200 bg-orange-500 hover:bg-orange-600 ${
          isDragging ? "scale-110 shadow-2xl ring-4 ring-orange-500/30" : ""
        } ${isOpen ? "bg-red-600 hover:bg-red-700" : ""}`}
        disabled={disabled}
        data-testid="button-fab-main"
      >
        <Plus className={`h-5 w-5 transition-transform duration-200 ${isOpen ? "rotate-45" : ""}`} />
      </Button>
    </div>
  );
}
