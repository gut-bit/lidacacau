import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Locate, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertVicinalSchema, type Vicinal, type InsertVicinal } from "@shared/schema";

interface VicinalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinal?: Vicinal | null;
}

export function VicinalDialog({
  open,
  onOpenChange,
  vicinal,
}: VicinalDialogProps) {
  const [isLocating, setIsLocating] = useState(false);
  const isEditMode = !!vicinal;

  const form = useForm<InsertVicinal>({
    resolver: zodResolver(insertVicinalSchema),
    defaultValues: {
      nome: "",
      descricao: "",
      whatsappLink: "",
      facebookLink: "",
      instagramLink: "",
      latitude: 0,
      longitude: 0,
    },
  });

  useEffect(() => {
    if (open) {
      if (vicinal) {
        form.reset({
          nome: vicinal.nome,
          descricao: vicinal.descricao ?? "",
          whatsappLink: vicinal.whatsappLink ?? "",
          facebookLink: vicinal.facebookLink ?? "",
          instagramLink: vicinal.instagramLink ?? "",
          latitude: vicinal.latitude,
          longitude: vicinal.longitude,
        });
      } else {
        form.reset({
          nome: "",
          descricao: "",
          whatsappLink: "",
          facebookLink: "",
          instagramLink: "",
          latitude: 0,
          longitude: 0,
        });
      }
    }
  }, [open, vicinal, form]);

  const createMutation = useMutation({
    mutationFn: async (data: InsertVicinal) => {
      const response = await apiRequest("POST", "/api/vicinais", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vicinais"] });
      form.reset();
      onOpenChange(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: InsertVicinal) => {
      const response = await apiRequest("PATCH", `/api/vicinais/${vicinal!.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vicinais"] });
      form.reset();
      onOpenChange(false);
    },
  });

  const isSubmitting = createMutation.isPending || updateMutation.isPending;
  const error = createMutation.error || updateMutation.error;

  const handleGetLocation = () => {
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        form.setValue("latitude", position.coords.latitude);
        form.setValue("longitude", position.coords.longitude);
        setIsLocating(false);
      },
      () => {
        setIsLocating(false);
      }
    );
  };

  const handleSubmit = async (data: InsertVicinal) => {
    const cleanedData = {
      ...data,
      descricao: data.descricao || null,
      whatsappLink: data.whatsappLink || null,
      facebookLink: data.facebookLink || null,
      instagramLink: data.instagramLink || null,
    };

    if (isEditMode) {
      updateMutation.mutate(cleanedData);
    } else {
      createMutation.mutate(cleanedData);
    }
  };

  const lat = form.watch("latitude");
  const lng = form.watch("longitude");
  const hasLocation = lat !== 0 && lng !== 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" data-testid="vicinal-dialog">
        <DialogHeader>
          <DialogTitle data-testid="dialog-title">
            {isEditMode ? "Editar Vicinal" : "Nova Vicinal"}
          </DialogTitle>
          <DialogDescription>
            {isEditMode
              ? "Atualize as informações da vicinal."
              : "Cadastre uma nova vicinal para organizar a comunidade."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="nome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome da Vicinal *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Ex: Vicinal do Km 90"
                      {...field}
                      data-testid="input-nome"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descricao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descreva a vicinal..."
                      className="min-h-[80px]"
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-descricao"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="whatsappLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Link do Grupo WhatsApp</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://chat.whatsapp.com/..."
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-whatsapp"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="facebookLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Link do Facebook</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://facebook.com/..."
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-facebook"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="instagramLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Link do Instagram</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://instagram.com/..."
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-instagram"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormLabel>Localização Central *</FormLabel>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGetLocation}
                  disabled={isLocating}
                  className="flex-1"
                  data-testid="button-get-location"
                >
                  {isLocating ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Locate className="h-4 w-4 mr-2" />
                  )}
                  {hasLocation ? "Atualizar Localização" : "Usar Minha Localização"}
                </Button>
              </div>
              {hasLocation && (
                <p className="text-xs text-muted-foreground" data-testid="text-coordinates">
                  Lat: {lat.toFixed(6)}, Lng: {lng.toFixed(6)}
                </p>
              )}
              {(form.formState.errors.latitude || form.formState.errors.longitude) && (
                <p className="text-sm text-destructive" data-testid="error-location">
                  Localização é obrigatória
                </p>
              )}
            </div>

            {error && (
              <p className="text-sm text-destructive" data-testid="error-message">
                {error.message || "Ocorreu um erro. Tente novamente."}
              </p>
            )}

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !hasLocation}
                className="flex-1"
                data-testid="button-submit"
              >
                {isSubmitting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : null}
                {isEditMode ? "Salvar" : "Criar Vicinal"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
