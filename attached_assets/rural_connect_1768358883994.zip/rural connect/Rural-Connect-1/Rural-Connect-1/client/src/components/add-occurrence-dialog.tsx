import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Locate, Loader2, Zap, Route, Construction, Users, ShieldAlert, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { OccurrenceType } from "@shared/schema";

const occurrenceTypes: { value: OccurrenceType; label: string; icon: typeof Zap; color: string }[] = [
  { value: "electrical", label: "Rede Elétrica", icon: Zap, color: "text-red-500 border-red-500" },
  { value: "road", label: "Estrada", icon: Route, color: "text-orange-500 border-orange-500" },
  { value: "bridge", label: "Ponte", icon: Construction, color: "text-amber-500 border-amber-500" },
  { value: "social", label: "Social", icon: Users, color: "text-yellow-500 border-yellow-500" },
  { value: "theft", label: "Roubo de Safra", icon: ShieldAlert, color: "text-purple-500 border-purple-500" },
  { value: "other", label: "Outro", icon: HelpCircle, color: "text-gray-500 border-gray-500" },
];

const formSchema = z.object({
  titulo: z.string().min(3, "Título deve ter pelo menos 3 caracteres"),
  descricao: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  tipo: z.enum(["electrical", "road", "bridge", "social", "theft", "other"]),
  vicinalId: z.string().min(1, "Selecione uma vicinal"),
  latitude: z.coerce.number().refine((val) => val !== 0, "Localização é obrigatória"),
  longitude: z.coerce.number().refine((val) => val !== 0, "Localização é obrigatória"),
});

type FormData = z.infer<typeof formSchema>;

interface AddOccurrenceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: { id: string; nome: string }[];
  onSubmit: (data: FormData) => Promise<void>;
  defaultLocation?: { lat: number; lng: number } | null;
  defaultTipo?: OccurrenceType;
}

export function AddOccurrenceDialog({
  open,
  onOpenChange,
  vicinais,
  onSubmit,
  defaultLocation,
  defaultTipo,
}: AddOccurrenceDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [selectedType, setSelectedType] = useState<OccurrenceType | null>(defaultTipo || null);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      tipo: defaultTipo || undefined,
      vicinalId: "",
      latitude: defaultLocation?.lat || 0,
      longitude: defaultLocation?.lng || 0,
    },
  });

  const handleGetLocation = () => {
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        form.setValue("latitude", position.coords.latitude);
        form.setValue("longitude", position.coords.longitude);
        setIsLocating(false);
      },
      () => {
        setIsLocating(false);
      }
    );
  };

  const handleSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      await onSubmit(data);
      form.reset();
      setSelectedType(null);
      onOpenChange(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTypeSelect = (type: OccurrenceType) => {
    setSelectedType(type);
    form.setValue("tipo", type);
  };

  const lat = form.watch("latitude");
  const lng = form.watch("longitude");
  const hasLocation = lat !== 0 && lng !== 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Ocorrência</DialogTitle>
          <DialogDescription>
            Registre um problema na sua vicinal para que a comunidade possa ajudar.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="tipo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Problema</FormLabel>
                  <div className="grid grid-cols-3 gap-2">
                    {occurrenceTypes.map((type) => {
                      const Icon = type.icon;
                      const isSelected = selectedType === type.value;
                      return (
                        <button
                          key={type.value}
                          type="button"
                          onClick={() => handleTypeSelect(type.value)}
                          className={cn(
                            "flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-colors",
                            isSelected ? type.color + " bg-accent" : "border-border"
                          )}
                          data-testid={`button-type-${type.value}`}
                        >
                          <Icon className={cn("h-6 w-6", isSelected ? type.color.split(" ")[0] : "text-muted-foreground")} />
                          <span className="text-xs text-center">{type.label}</span>
                        </button>
                      );
                    })}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="titulo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Ex: Árvore caída na rede elétrica" 
                      {...field} 
                      data-testid="input-titulo"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descricao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descreva o problema em detalhes..."
                      className="min-h-[100px]"
                      {...field}
                      data-testid="input-descricao"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="vicinalId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Vicinal</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-vicinal">
                        <SelectValue placeholder="Selecione a vicinal" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {vicinais.map((v) => (
                        <SelectItem key={v.id} value={v.id}>
                          {v.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormLabel>Localização</FormLabel>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGetLocation}
                  disabled={isLocating}
                  className="flex-1"
                  data-testid="button-get-location"
                >
                  {isLocating ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Locate className="h-4 w-4 mr-2" />
                  )}
                  {hasLocation ? "Atualizar Localização" : "Usar Minha Localização"}
                </Button>
              </div>
              {hasLocation && (
                <p className="text-xs text-muted-foreground">
                  Lat: {lat.toFixed(6)}, Lng: {lng.toFixed(6)}
                </p>
              )}
              {form.formState.errors.latitude && (
                <p className="text-sm text-destructive">Localização é obrigatória</p>
              )}
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !hasLocation}
                className="flex-1"
                data-testid="button-submit-occurrence"
              >
                {isSubmitting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : null}
                Registrar
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
