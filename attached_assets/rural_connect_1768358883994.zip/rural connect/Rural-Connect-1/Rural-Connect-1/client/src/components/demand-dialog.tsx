import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Vicinal } from "@shared/schema";

const demandFormSchema = z.object({
  titulo: z.string().min(5, "Título deve ter pelo menos 5 caracteres"),
  descricao: z.string().min(20, "Descreva a demanda com mais detalhes"),
  vicinalId: z.string().min(1, "Selecione uma vicinal"),
  categoria: z.enum(['infraestrutura', 'saude', 'educacao', 'seguranca', 'agricultura', 'meio_ambiente', 'transporte', 'outro']),
  prioridade: z.enum(['baixa', 'media', 'alta', 'urgente']),
  populacaoAfetada: z.preprocess(
    (val) => (val === '' || val === undefined || val === null) ? undefined : Number(val),
    z.number().positive().optional()
  ),
  orcamentoEstimado: z.preprocess(
    (val) => (val === '' || val === undefined || val === null) ? undefined : Number(val),
    z.number().positive().optional()
  ),
});

type DemandFormValues = z.infer<typeof demandFormSchema>;

interface DemandDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: Vicinal[];
}

export function DemandDialog({ open, onOpenChange, vicinais }: DemandDialogProps) {
  const { toast } = useToast();

  const form = useForm<DemandFormValues>({
    resolver: zodResolver(demandFormSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      vicinalId: "",
      categoria: "infraestrutura",
      prioridade: "media",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: DemandFormValues) => {
      return apiRequest('POST', '/api/government/demands', {
        ...data,
        userId: "demo-user",
        status: "pendente",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/government/demands'] });
      toast({ title: "Demanda registrada com sucesso!" });
      form.reset();
      onOpenChange(false);
    },
    onError: () => {
      toast({ title: "Erro ao registrar demanda", variant: "destructive" });
    },
  });

  const onSubmit = (data: DemandFormValues) => {
    createMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Demanda para o Governo</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="titulo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Recuperação da estrada vicinal" {...field} data-testid="input-demand-titulo" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descricao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Descreva detalhadamente a necessidade da comunidade..."
                      className="min-h-[100px]"
                      {...field}
                      data-testid="input-demand-descricao"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="vicinalId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Vicinal</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-demand-vicinal">
                        <SelectValue placeholder="Selecione a vicinal" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {vicinais.map(v => (
                        <SelectItem key={v.id} value={v.id}>{v.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="categoria"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categoria</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-demand-categoria">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="infraestrutura">Infraestrutura</SelectItem>
                        <SelectItem value="saude">Saúde</SelectItem>
                        <SelectItem value="educacao">Educação</SelectItem>
                        <SelectItem value="seguranca">Segurança</SelectItem>
                        <SelectItem value="agricultura">Agricultura</SelectItem>
                        <SelectItem value="meio_ambiente">Meio Ambiente</SelectItem>
                        <SelectItem value="transporte">Transporte</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="prioridade"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prioridade</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-demand-prioridade">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="baixa">Baixa</SelectItem>
                        <SelectItem value="media">Média</SelectItem>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="urgente">Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="populacaoAfetada"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>População Afetada</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Opcional" 
                        {...field} 
                        data-testid="input-demand-populacao"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="orcamentoEstimado"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Orçamento Est. (R$)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Opcional" 
                        {...field} 
                        data-testid="input-demand-orcamento"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1"
                onClick={() => onOpenChange(false)}
              >
                Cancelar
              </Button>
              <Button 
                type="submit" 
                className="flex-1"
                disabled={createMutation.isPending}
                data-testid="button-submit-demand"
              >
                {createMutation.isPending ? "Enviando..." : "Registrar Demanda"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
