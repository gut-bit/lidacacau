import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Locate, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertOccurrenceSchema, type Occurrence, type OccurrenceType, type OccurrenceStatus } from "@shared/schema";

const occurrenceTypeLabels: Record<OccurrenceType, string> = {
  electrical: "Elétrico",
  road: "Estrada",
  bridge: "Ponte",
  social: "Social",
  theft: "Roubo",
  other: "Outro",
};

const occurrenceStatusLabels: Record<OccurrenceStatus, string> = {
  open: "Aberto",
  in_progress: "Em Andamento",
  resolved: "Resolvido",
};

const formSchema = insertOccurrenceSchema.extend({
  titulo: z.string().min(1, "Título é obrigatório"),
  descricao: z.string().min(1, "Descrição é obrigatória"),
  tipo: z.enum(["electrical", "road", "bridge", "social", "theft", "other"], {
    required_error: "Tipo é obrigatório",
  }),
  vicinalId: z.string().min(1, "Vicinal é obrigatória"),
  latitude: z.coerce.number().refine((val) => val !== 0, "Latitude é obrigatória"),
  longitude: z.coerce.number().refine((val) => val !== 0, "Longitude é obrigatória"),
  status: z.enum(["open", "in_progress", "resolved"]).optional(),
});

type FormData = z.infer<typeof formSchema>;

interface OccurrenceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: { id: string; nome: string }[];
  occurrence?: Occurrence | null;
  mode: "add" | "edit";
}

export function OccurrenceDialog({
  open,
  onOpenChange,
  vicinais,
  occurrence,
  mode,
}: OccurrenceDialogProps) {
  const [isLocating, setIsLocating] = useState(false);

  const isEditMode = mode === "edit" && occurrence;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      tipo: undefined,
      vicinalId: "",
      latitude: 0,
      longitude: 0,
      status: "open",
      userId: "anonymous",
      createdAt: new Date().toISOString(),
    },
  });

  useEffect(() => {
    if (open) {
      if (isEditMode && occurrence) {
        form.reset({
          titulo: occurrence.titulo,
          descricao: occurrence.descricao,
          tipo: occurrence.tipo,
          vicinalId: occurrence.vicinalId,
          latitude: occurrence.latitude,
          longitude: occurrence.longitude,
          status: occurrence.status,
          userId: occurrence.userId,
          createdAt: occurrence.createdAt,
          roadId: occurrence.roadId || undefined,
          fotos: occurrence.fotos || undefined,
        });
      } else {
        form.reset({
          titulo: "",
          descricao: "",
          tipo: undefined,
          vicinalId: "",
          latitude: 0,
          longitude: 0,
          status: "open",
          userId: "anonymous",
          createdAt: new Date().toISOString(),
        });
      }
    }
  }, [open, isEditMode, occurrence, form]);

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/occurrences", {
        ...data,
        userId: "anonymous",
        createdAt: new Date().toISOString(),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      form.reset();
      onOpenChange(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (!occurrence) throw new Error("Occurrence not found");
      const response = await apiRequest("PATCH", `/api/occurrences/${occurrence.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      form.reset();
      onOpenChange(false);
    },
  });

  const isPending = createMutation.isPending || updateMutation.isPending;
  const error = createMutation.error || updateMutation.error;

  const handleGetLocation = () => {
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        form.setValue("latitude", position.coords.latitude);
        form.setValue("longitude", position.coords.longitude);
        setIsLocating(false);
      },
      () => {
        setIsLocating(false);
      }
    );
  };

  const handleSubmit = (data: FormData) => {
    if (isEditMode) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const lat = form.watch("latitude");
  const lng = form.watch("longitude");
  const hasLocation = lat !== 0 && lng !== 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle data-testid="dialog-title">
            {isEditMode ? "Editar Ocorrência" : "Nova Ocorrência"}
          </DialogTitle>
          <DialogDescription>
            {isEditMode
              ? "Atualize as informações da ocorrência."
              : "Registre um problema na sua vicinal para que a comunidade possa ajudar."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="titulo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Ex: Árvore caída na rede elétrica"
                      {...field}
                      data-testid="input-titulo"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descricao"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descreva o problema em detalhes..."
                      className="min-h-[100px]"
                      {...field}
                      data-testid="input-descricao"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="tipo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-tipo">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {(Object.keys(occurrenceTypeLabels) as OccurrenceType[]).map((type) => (
                        <SelectItem key={type} value={type} data-testid={`select-tipo-option-${type}`}>
                          {occurrenceTypeLabels[type]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {isEditMode && (
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-status">
                          <SelectValue placeholder="Selecione o status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(Object.keys(occurrenceStatusLabels) as OccurrenceStatus[]).map((status) => (
                          <SelectItem key={status} value={status} data-testid={`select-status-option-${status}`}>
                            {occurrenceStatusLabels[status]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="vicinalId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Vicinal</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-vicinal">
                        <SelectValue placeholder="Selecione a vicinal" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {vicinais.map((v) => (
                        <SelectItem key={v.id} value={v.id} data-testid={`select-vicinal-option-${v.id}`}>
                          {v.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="latitude"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Latitude</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="any"
                        placeholder="-3.123456"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        data-testid="input-latitude"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="longitude"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Longitude</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="any"
                        placeholder="-52.654321"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        data-testid="input-longitude"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button
              type="button"
              variant="outline"
              onClick={handleGetLocation}
              disabled={isLocating}
              className="w-full"
              data-testid="button-get-location"
            >
              {isLocating ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Locate className="h-4 w-4 mr-2" />
              )}
              {hasLocation ? "Atualizar Localização" : "Usar Minha Localização"}
            </Button>

            {error && (
              <p className="text-sm text-destructive" data-testid="error-message">
                {error.message}
              </p>
            )}

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isPending}
                className="flex-1"
                data-testid="button-submit"
              >
                {isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {isEditMode ? "Salvar" : "Registrar"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
