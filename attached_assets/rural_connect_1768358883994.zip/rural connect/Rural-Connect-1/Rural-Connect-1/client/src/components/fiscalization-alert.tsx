import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AlertTriangle, Radio, X, Clock, MapPin, Car, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { FiscalizationAlert, Vicinal } from "@shared/schema";

const alertTypeLabels: Record<string, { label: string; icon: string }> = {
  ibama: { label: "IBAMA", icon: "🌳" },
  icmbio: { label: "ICMBio", icon: "🦜" },
  policia_ambiental: { label: "Polícia Ambiental", icon: "🚔" },
  sema: { label: "SEMA", icon: "🌿" },
  outro: { label: "Outro", icon: "⚠️" },
};

interface FiscalizationAlertBannerProps {
  alerts: FiscalizationAlert[];
  vicinais: Vicinal[];
}

export function FiscalizationAlertBanner({ alerts, vicinais }: FiscalizationAlertBannerProps) {
  const [expanded, setExpanded] = useState(false);
  
  if (alerts.length === 0) return null;

  const latestAlert = alerts[0];
  const vicinal = vicinais.find(v => v.id === latestAlert.vicinalId);
  const alertType = alertTypeLabels[latestAlert.tipo] || alertTypeLabels.outro;
  
  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins} min atrás`;
    const hours = Math.floor(mins / 60);
    return `${hours}h atrás`;
  };

  return (
    <div 
      className="fixed top-0 left-0 right-0 z-[100] animate-pulse"
      data-testid="fiscalization-alert-banner"
    >
      <div 
        className="bg-amber-500 text-amber-950 px-4 py-3 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="container flex items-center gap-3">
          <div className="flex items-center gap-2 animate-bounce">
            <AlertTriangle className="h-5 w-5" />
            <Radio className="h-4 w-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm flex items-center gap-2">
              ALERTA FISCALIZAÇÃO
              <Badge className="bg-amber-600 text-amber-50 text-xs">
                {alertType.icon} {alertType.label}
              </Badge>
            </div>
            <div className="text-xs flex items-center gap-2 truncate">
              <MapPin className="h-3 w-3 shrink-0" />
              {vicinal?.nome || "Vicinal"}
              <span className="text-amber-700">•</span>
              <Clock className="h-3 w-3 shrink-0" />
              {timeAgo(latestAlert.createdAt)}
            </div>
          </div>
          <ChevronRight className={`h-5 w-5 transition-transform ${expanded ? 'rotate-90' : ''}`} />
        </div>
      </div>

      {expanded && (
        <div className="bg-amber-100 border-b border-amber-300 px-4 py-3">
          <div className="container space-y-2">
            {latestAlert.descricao && (
              <p className="text-sm text-amber-900">{latestAlert.descricao}</p>
            )}
            <div className="flex flex-wrap gap-2 text-xs text-amber-800">
              {latestAlert.direcao && (
                <span className="flex items-center gap-1">
                  Direção: {latestAlert.direcao}
                </span>
              )}
              {latestAlert.veiculos && (
                <span className="flex items-center gap-1">
                  <Car className="h-3 w-3" />
                  {latestAlert.veiculos}
                </span>
              )}
            </div>
            {alerts.length > 1 && (
              <p className="text-xs text-amber-700">
                +{alerts.length - 1} outros alertas ativos
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface CreateAlertDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vicinais: Vicinal[];
  onAlertSuccess?: () => void;
}

export function CreateAlertDialog({ open, onOpenChange, vicinais, onAlertSuccess }: CreateAlertDialogProps) {
  const { toast } = useToast();
  const [tipo, setTipo] = useState<string>('ibama');
  const [vicinalId, setVicinalId] = useState<string>('');
  const [descricao, setDescricao] = useState('');
  const [direcao, setDirecao] = useState('');
  const [veiculos, setVeiculos] = useState('');

  const createMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/alerts', {
        tipo,
        vicinalId,
        descricao,
        direcao,
        veiculos,
        userId: "demo-user",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/alerts/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      toast({ 
        title: "ALERTA ENVIADO!",
        description: "Todos os membros da vicinal serão notificados.",
      });
      onOpenChange(false);
      setDescricao('');
      setDirecao('');
      setVeiculos('');
      onAlertSuccess?.();
    },
    onError: () => {
      toast({ title: "Erro ao enviar alerta", variant: "destructive" });
    },
  });

  const handleSubmit = () => {
    if (!vicinalId) {
      toast({ title: "Selecione uma vicinal", variant: "destructive" });
      return;
    }
    createMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="h-5 w-5" />
            Alerta de Fiscalização
          </DialogTitle>
          <DialogDescription>
            Este alerta será enviado imediatamente para todos os membros da vicinal selecionada.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <p className="text-xs text-amber-800 font-medium">
              Use com responsabilidade. Alertas falsos prejudicam toda a comunidade.
            </p>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Tipo de Fiscalização</label>
            <Select value={tipo} onValueChange={setTipo}>
              <SelectTrigger data-testid="select-alert-tipo">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ibama">🌳 IBAMA</SelectItem>
                <SelectItem value="icmbio">🦜 ICMBio</SelectItem>
                <SelectItem value="policia_ambiental">🚔 Polícia Ambiental</SelectItem>
                <SelectItem value="sema">🌿 SEMA</SelectItem>
                <SelectItem value="outro">⚠️ Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Vicinal</label>
            <Select value={vicinalId} onValueChange={setVicinalId}>
              <SelectTrigger data-testid="select-alert-vicinal">
                <SelectValue placeholder="Selecione a vicinal" />
              </SelectTrigger>
              <SelectContent>
                {vicinais.map(v => (
                  <SelectItem key={v.id} value={v.id}>{v.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Direção (opcional)</label>
            <Input 
              placeholder="Ex: Entrando pela BR-230, km 102"
              value={direcao}
              onChange={(e) => setDirecao(e.target.value)}
              data-testid="input-alert-direcao"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Veículos (opcional)</label>
            <Input 
              placeholder="Ex: 2 caminhonetes brancas, 1 ônibus"
              value={veiculos}
              onChange={(e) => setVeiculos(e.target.value)}
              data-testid="input-alert-veiculos"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Observações (opcional)</label>
            <Textarea 
              placeholder="Outras informações importantes..."
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              data-testid="input-alert-descricao"
            />
          </div>

          <div className="flex gap-2 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button 
              type="button" 
              className="flex-1 bg-amber-500 hover:bg-amber-600 text-amber-950"
              onClick={handleSubmit}
              disabled={createMutation.isPending}
              data-testid="button-submit-alert"
            >
              {createMutation.isPending ? "Enviando..." : "ENVIAR ALERTA"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

interface FiscalizationAlertButtonProps {
  className?: string;
  onAlertSent?: () => void;
}

export function FiscalizationAlertButton({ className, onAlertSent }: FiscalizationAlertButtonProps) {
  const [showDialog, setShowDialog] = useState(false);
  
  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ['/api/vicinais'],
  });

  return (
    <>
      <Button
        className={`bg-amber-500 hover:bg-amber-600 text-amber-950 font-bold shadow-lg gap-2 min-h-[44px] px-4 ${className}`}
        onClick={() => setShowDialog(true)}
        data-testid="button-fiscalization-alert"
      >
        <AlertTriangle className="h-4 w-4" />
        <span className="text-sm">ALERTA</span>
      </Button>

      <CreateAlertDialog 
        open={showDialog} 
        onOpenChange={setShowDialog}
        vicinais={vicinais}
        onAlertSuccess={onAlertSent}
      />
    </>
  );
}
