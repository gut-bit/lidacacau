import { useState, useEffect } from "react";
import { Wifi, WifiOff, RefreshCw, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { isOnline, onOnlineStatusChange, getSyncQueue, syncPendingItems } from "@/lib/offline-storage";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function OnlineStatusIndicator() {
  const { toast } = useToast();
  const [online, setOnline] = useState(isOnline());
  const [pendingCount, setPendingCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    const cleanup = onOnlineStatusChange((newOnline) => {
      setOnline(newOnline);
      if (newOnline) {
        handleSync();
      }
    });

    checkPendingItems();
    const interval = setInterval(checkPendingItems, 10000);

    return () => {
      cleanup();
      clearInterval(interval);
    };
  }, []);

  async function checkPendingItems() {
    try {
      const queue = await getSyncQueue();
      setPendingCount(queue.filter(q => q.status !== "syncing").length);
    } catch {
      setPendingCount(0);
    }
  }

  async function handleSync() {
    if (syncing || !online) return;

    setSyncing(true);
    try {
      const result = await syncPendingItems(async (item) => {
        if (item.type === "occurrence") {
          await apiRequest("POST", "/api/occurrences", item.data);
          return true;
        }
        if (item.type === "comment") {
          await apiRequest("POST", `/api/occurrences/${item.data.occurrenceId}/comments`, item.data);
          return true;
        }
        return false;
      });

      if (result.synced > 0) {
        queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
        toast({
          title: "Dados sincronizados",
          description: `${result.synced} item(ns) enviado(s) com sucesso.`,
        });
      }

      await checkPendingItems();
    } catch (error) {
      console.error("Sync error:", error);
    } finally {
      setSyncing(false);
    }
  }

  if (online && pendingCount === 0) {
    return null;
  }

  return (
    <div className="fixed top-2 left-1/2 -translate-x-1/2 z-[9999] flex items-center gap-2">
      {!online ? (
        <Badge variant="destructive" className="gap-1 px-3 py-1" data-testid="badge-offline-status">
          <WifiOff className="h-3 w-3" />
          Offline
        </Badge>
      ) : pendingCount > 0 ? (
        <Badge variant="secondary" className="gap-1 px-3 py-1" data-testid="badge-pending-sync">
          <Wifi className="h-3 w-3" />
          {pendingCount} pendente(s)
          <Button
            variant="ghost"
            size="icon"
            className="h-5 w-5 ml-1"
            onClick={handleSync}
            disabled={syncing}
            data-testid="button-manual-sync"
          >
            {syncing ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <RefreshCw className="h-3 w-3" />
            )}
          </Button>
        </Badge>
      ) : null}
    </div>
  );
}
