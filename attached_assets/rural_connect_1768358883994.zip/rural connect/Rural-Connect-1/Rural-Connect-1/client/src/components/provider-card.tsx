import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Phone, 
  MessageCircle, 
  MapPin,
  Building2,
  User,
  ChevronRight,
  Tractor,
  Truck,
  Wrench,
  Droplets,
  Zap,
  Hammer,
  Package,
  HelpCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ServiceProvider, ProviderService, ProviderCoverage, ServiceCategory, ProviderType, Vicinal } from "@shared/schema";

const categoryConfig: Record<ServiceCategory, { 
  icon: typeof Tractor; 
  label: string; 
}> = {
  trator_grade: { icon: Tractor, label: "Trator com Grade" },
  escavadeira: { icon: Truck, label: "Escavadeira" },
  patrol: { icon: Truck, label: "Patrol" },
  cacamba: { icon: Truck, label: "Caçamba" },
  pipa_agua: { icon: Droplets, label: "Pipa de Água" },
  eletricista: { icon: Zap, label: "Eletricista" },
  mecanico: { icon: Wrench, label: "Mecânico" },
  transporte: { icon: Truck, label: "Transporte" },
  construcao: { icon: Hammer, label: "Construção" },
  outro: { icon: Package, label: "Outro" },
};

const typeConfig: Record<ProviderType, { 
  icon: typeof Building2;
  label: string;
  bgColor: string;
  textColor: string;
}> = {
  empresa: { 
    icon: Building2, 
    label: "Empresa",
    bgColor: "bg-blue-100 dark:bg-blue-900/50",
    textColor: "text-blue-700 dark:text-blue-300",
  },
  autonomo: { 
    icon: User, 
    label: "Autônomo",
    bgColor: "bg-purple-100 dark:bg-purple-900/50",
    textColor: "text-purple-700 dark:text-purple-300",
  },
};

interface ProviderCardProps {
  provider: ServiceProvider;
  services?: ProviderService[];
  coverageVicinais?: Vicinal[];
  isAvailableToday?: boolean;
  onViewDetails?: () => void;
}

export function ProviderCard({ 
  provider, 
  services = [],
  coverageVicinais = [],
  isAvailableToday = false,
  onViewDetails,
}: ProviderCardProps) {
  const typeInfo = typeConfig[provider.tipo] || typeConfig.autonomo;
  const TypeIcon = typeInfo.icon;

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .slice(0, 2)
      .map(n => n[0])
      .join("")
      .toUpperCase();
  };

  const formatPrice = (min?: number | null, max?: number | null, unit?: string | null) => {
    if (!min && !max) return null;
    
    const formatValue = (v: number) => 
      v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
    
    if (min && max && min !== max) {
      return `${formatValue(min)} - ${formatValue(max)}${unit ? `/${unit}` : ""}`;
    }
    return `${formatValue(min || max || 0)}${unit ? `/${unit}` : ""}`;
  };

  const handlePhoneClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.location.href = `tel:${provider.telefone}`;
  };

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const phone = (provider.whatsapp || provider.telefone).replace(/\D/g, "");
    window.open(`https://wa.me/55${phone}`, "_blank");
  };

  const displayServices = services.slice(0, 3);
  const remainingServices = services.length - 3;

  return (
    <Card 
      className="overflow-visible cursor-pointer hover-elevate active-elevate-2 transition-all duration-200"
      onClick={onViewDetails}
      data-testid={`card-provider-${provider.id}`}
    >
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className="relative">
            <Avatar className="h-14 w-14 flex-shrink-0">
              <AvatarImage src={provider.foto || undefined} alt={provider.nome} />
              <AvatarFallback className="text-lg bg-primary/10 text-primary font-semibold">
                {getInitials(provider.nome)}
              </AvatarFallback>
            </Avatar>
            {isAvailableToday && (
              <div 
                className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full border-2 border-card"
                title="Disponível hoje"
                data-testid={`indicator-available-${provider.id}`}
              />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h3 
                className="font-semibold text-foreground text-base leading-tight line-clamp-1"
                data-testid={`text-provider-name-${provider.id}`}
              >
                {provider.nome}
              </h3>
              <Badge
                variant="secondary"
                className={cn(
                  "flex-shrink-0 gap-1 text-xs font-medium",
                  typeInfo.bgColor,
                  typeInfo.textColor,
                  "border-0"
                )}
                data-testid={`badge-provider-type-${provider.id}`}
              >
                <TypeIcon className="h-3 w-3" />
                {typeInfo.label}
              </Badge>
            </div>

            {provider.descricao && (
              <p 
                className="text-sm text-muted-foreground mt-1 line-clamp-2"
                data-testid={`text-provider-description-${provider.id}`}
              >
                {provider.descricao}
              </p>
            )}
          </div>
        </div>

        {displayServices.length > 0 && (
          <div className="mt-4 space-y-2" data-testid={`list-services-${provider.id}`}>
            {displayServices.map((service) => {
              const categoryInfo = categoryConfig[service.categoria] || categoryConfig.outro;
              const CategoryIcon = categoryInfo.icon;
              const priceText = formatPrice(service.precoMinimo, service.precoMaximo, service.unidadePreco);

              return (
                <div 
                  key={service.id} 
                  className="flex items-center justify-between gap-2 text-sm"
                  data-testid={`service-item-${service.id}`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <CategoryIcon className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span className="truncate">{service.nome}</span>
                  </div>
                  {priceText && (
                    <span className="text-xs font-medium text-primary flex-shrink-0">
                      {priceText}
                    </span>
                  )}
                </div>
              );
            })}
            {remainingServices > 0 && (
              <p className="text-xs text-muted-foreground">
                +{remainingServices} {remainingServices === 1 ? "serviço" : "serviços"}
              </p>
            )}
          </div>
        )}

        {coverageVicinais.length > 0 && (
          <div className="mt-3 flex items-center gap-1.5 text-sm text-muted-foreground">
            <MapPin className="h-3.5 w-3.5 flex-shrink-0" />
            <span className="truncate" data-testid={`text-coverage-${provider.id}`}>
              {coverageVicinais.slice(0, 2).map(v => v.nome).join(", ")}
              {coverageVicinais.length > 2 && ` +${coverageVicinais.length - 2}`}
            </span>
          </div>
        )}

        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-border/50">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 gap-1.5"
            onClick={handlePhoneClick}
            data-testid={`button-phone-${provider.id}`}
          >
            <Phone className="h-4 w-4" />
            Ligar
          </Button>
          <Button
            variant="default"
            size="sm"
            className="flex-1 gap-1.5 bg-green-600 hover:bg-green-700 text-white"
            onClick={handleWhatsAppClick}
            data-testid={`button-whatsapp-${provider.id}`}
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </Button>
          {onViewDetails && (
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onViewDetails();
              }}
              data-testid={`button-details-${provider.id}`}
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
