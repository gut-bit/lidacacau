import { useState, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMapEvents, useMap, LayersControl, LayerGroup } from "react-leaflet";
import { useQuery, useMutation } from "@tanstack/react-query";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Button } from "@/components/ui/button";
import { Plus, Locate, Layers, Home, Zap, Construction, Milestone, Users, Wheat } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Occurrence, Vicinal, User, Road, RoadClassification } from "@shared/schema";
import { RoadEditorToolbar, RoadList } from "./road-editor";

const DEFAULT_CENTER: [number, number] = [-3.6268, -53.3936];
const DEFAULT_ZOOM = 14;

const ROAD_COLORS = {
  principal: "#ff7f50", // Salmon/Coral color for Transamazônica
  ramal: "#2563eb",    // Blue for Vicinais as requested
};

const ROAD_WEIGHTS = {
  principal: 8,        // Increased weight for better highlight
  ramal: 4,
};

const createIconWithSvg = (color: string, svgPath: string) => {
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="
      background-color: ${color};
      width: 32px;
      height: 32px;
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      border: 2px solid white;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
    ">
      <svg style="transform: rotate(45deg); width: 16px; height: 16px; color: white;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        ${svgPath}
      </svg>
    </div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });
};

const svgPaths = {
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  construction: '<rect x="2" y="6" width="20" height="8" rx="1"/><path d="M17 14v7"/><path d="M7 14v7"/><path d="M17 3v3"/><path d="M7 3v3"/><path d="M10 14 2.3 6.3"/><path d="m14 6 7.7 7.7"/><path d="m8 6 8 8"/>',
  bridge: '<path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M5 16V2"/><path d="M19 16V2"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  wheat: '<path d="M2 22 16 8"/><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z"/><path d="M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/><path d="M15.47 13.47 17 15l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/><path d="M19.47 9.47 21 11l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L13 11l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z"/>',
  other: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
};

const occurrenceIcons = {
  electrical: createIconWithSvg("#ef4444", svgPaths.zap),
  road: createIconWithSvg("#ea580c", svgPaths.construction),
  bridge: createIconWithSvg("#06b6d4", svgPaths.bridge),
  social: createIconWithSvg("#eab308", svgPaths.users),
  theft: createIconWithSvg("#a855f7", svgPaths.wheat),
  other: createIconWithSvg("#6b7280", svgPaths.other),
};

const propertyIcon = createIconWithSvg("#22c55e", svgPaths.home);

const createSimpleIcon = (color: string) => {
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="
      background-color: ${color};
      width: 24px;
      height: 24px;
      border-radius: 50%;
      border: 3px solid white;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    "></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12],
  });
};

const selectedLocationIcon = createSimpleIcon("#3b82f6");

const occurrenceLabels: Record<string, string> = {
  electrical: "Rede Elétrica",
  road: "Estrada",
  bridge: "Ponte",
  social: "Social",
  theft: "Roubo de Safra",
  other: "Outro",
};

function LocationButton() {
  const map = useMap();
  const [loading, setLoading] = useState(false);

  const handleLocate = () => {
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        map.flyTo([latitude, longitude], 15);
        setLoading(false);
      },
      () => {
        setLoading(false);
      }
    );
  };

  return (
    <Button
      variant="secondary"
      size="icon"
      className="absolute top-16 right-4 z-[1000] shadow-md"
      onClick={handleLocate}
      disabled={loading}
      data-testid="button-locate"
    >
      <Locate className={cn("h-5 w-5", loading && "animate-pulse")} />
    </Button>
  );
}

interface MapClickHandlerProps {
  onMapClick?: (lat: number, lng: number) => void;
  isDrawingRoad?: boolean;
  onRoadPointAdd?: (lat: number, lng: number) => void;
}

function MapClickHandler({ onMapClick, isDrawingRoad, onRoadPointAdd }: MapClickHandlerProps) {
  useMapEvents({
    click: (e) => {
      if (isDrawingRoad && onRoadPointAdd) {
        onRoadPointAdd(e.latlng.lat, e.latlng.lng);
      } else if (onMapClick) {
        onMapClick(e.latlng.lat, e.latlng.lng);
      }
    },
  });
  return null;
}

interface MapViewProps {
  occurrences?: Occurrence[];
  users?: User[];
  vicinais?: Vicinal[];
  onAddOccurrence?: () => void;
  onMapClick?: (lat: number, lng: number) => void;
  onOccurrenceClick?: (occurrence: Occurrence) => void;
  onRoadClick?: (road: Road) => void;
  selectedLocation?: { lat: number; lng: number } | null;
  showAddButton?: boolean;
  className?: string;
}

export function MapView({
  occurrences = [],
  users = [],
  vicinais = [],
  onAddOccurrence,
  onMapClick,
  onOccurrenceClick,
  onRoadClick,
  selectedLocation,
  showAddButton = true,
  className,
}: MapViewProps) {
  const { toast } = useToast();
  const [showLegend, setShowLegend] = useState(true);
  const [isDrawingRoad, setIsDrawingRoad] = useState(false);
  const [drawingPoints, setDrawingPoints] = useState<[number, number][]>([]);

  const { data: savedRoads = [] } = useQuery<Road[]>({
    queryKey: ["/api/roads"],
  });

  const createRoadMutation = useMutation({
    mutationFn: async (data: { nome: string; classification: RoadClassification; coordinates: string }) => {
      return apiRequest("POST", "/api/roads", {
        ...data,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roads"] });
      toast({
        title: "Estrada salva",
        description: "A estrada foi salva com sucesso!",
      });
      setIsDrawingRoad(false);
      setDrawingPoints([]);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível salvar a estrada.",
        variant: "destructive",
      });
    },
  });

  const handleStartDrawing = useCallback(() => {
    setIsDrawingRoad(true);
    setDrawingPoints([]);
  }, []);

  const handleCancelDrawing = useCallback(() => {
    setIsDrawingRoad(false);
    setDrawingPoints([]);
  }, []);

  const handleRoadPointAdd = useCallback((lat: number, lng: number) => {
    setDrawingPoints((prev) => [...prev, [lat, lng]]);
  }, []);

  const handleSaveRoad = useCallback((name: string, classification: RoadClassification) => {
    if (drawingPoints.length < 2) return;
    
    createRoadMutation.mutate({
      nome: name,
      classification,
      coordinates: JSON.stringify(drawingPoints),
    });
  }, [drawingPoints, createRoadMutation]);

  const parseCoordinates = (coordString: string): [number, number][] => {
    try {
      return JSON.parse(coordString);
    } catch {
      return [];
    }
  };

  return (
    <div className={cn("relative w-full h-full", className)}>
      <MapContainer
        center={DEFAULT_CENTER}
        zoom={DEFAULT_ZOOM}
        className="w-full h-full"
        zoomControl={false}
        dragging={true}
        touchZoom={true}
        scrollWheelZoom={true}
        doubleClickZoom={true}
        boxZoom={true}
        maxBounds={[
          [-3.75, -53.5], // South West
          [-3.5, -53.3]   // North East
        ]}
        maxBoundsViscosity={1.0}
        minZoom={13}
      >
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="Mapa">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Satélite">
            <TileLayer
              attribution='Tiles &copy; Esri'
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              maxZoom={19}
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Híbrido">
            <LayerGroup>
              <TileLayer
                attribution='Tiles &copy; Esri'
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                maxZoom={19}
              />
              <TileLayer
                attribution='&copy; CARTO'
                url="https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}.png"
              />
            </LayerGroup>
          </LayersControl.BaseLayer>
        </LayersControl>
        
        <LocationButton />
        <MapClickHandler 
          onMapClick={onMapClick} 
          isDrawingRoad={isDrawingRoad}
          onRoadPointAdd={handleRoadPointAdd}
        />

        {savedRoads.map((road) => {
          const coords = parseCoordinates(road.coordinates);
          if (coords.length < 2) return null;
          return (
            <Polyline
              key={road.id}
              positions={coords}
              pathOptions={{
                color: ROAD_COLORS[road.classification as keyof typeof ROAD_COLORS] || ROAD_COLORS.ramal,
                weight: ROAD_WEIGHTS[road.classification as keyof typeof ROAD_WEIGHTS] || ROAD_WEIGHTS.ramal,
                opacity: 0.8,
                lineCap: "round",
                lineJoin: "round",
              }}
              eventHandlers={{
                click: () => onRoadClick?.(road),
              }}
            >
              <Popup>
                <div className="p-1">
                  <p className="font-medium">{road.nome}</p>
                  <p className="text-xs text-muted-foreground">
                    {road.classification === "principal" ? "Estrada Principal" : "Ramal/Vicinal"}
                  </p>
                </div>
              </Popup>
            </Polyline>
          );
        })}

        {isDrawingRoad && drawingPoints.length >= 1 && (
          <Polyline
            positions={drawingPoints}
            pathOptions={{
              color: "#2563eb",
              weight: 5,
              opacity: 0.9,
              lineCap: "round",
              lineJoin: "round",
            }}
          />
        )}

        {isDrawingRoad && drawingPoints.map((point, index) => (
          <Marker
            key={`drawing-point-${index}`}
            position={point}
            icon={L.divIcon({
              className: "drawing-point",
              html: `<div style="
                background-color: #2563eb;
                width: 24px;
                height: 24px;
                border-radius: 50%;
                border: 3px solid white;
                box-shadow: 0 2px 6px rgba(0,0,0,0.4);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 11px;
                font-weight: bold;
              ">${index + 1}</div>`,
              iconSize: [24, 24],
              iconAnchor: [12, 12],
            })}
          />
        ))}

        {users.map((user) =>
          user.latitude && user.longitude ? (
            <Marker
              key={`user-${user.id}`}
              position={[user.latitude, user.longitude]}
              icon={propertyIcon}
            >
              <Popup>
                <div className="p-1">
                  <p className="font-medium">{user.propriedadeNome || user.nome}</p>
                  <p className="text-sm text-muted-foreground">{user.nome}</p>
                </div>
              </Popup>
            </Marker>
          ) : null
        )}

        {occurrences.map((occurrence) => (
          <Marker
            key={`occurrence-${occurrence.id}`}
            position={[occurrence.latitude, occurrence.longitude]}
            icon={occurrenceIcons[occurrence.tipo] || occurrenceIcons.other}
            eventHandlers={{
              click: () => onOccurrenceClick?.(occurrence),
            }}
          >
            <Popup>
              <div className="p-1 min-w-[150px]">
                <p className="font-medium">{occurrence.titulo}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {occurrenceLabels[occurrence.tipo]}
                </p>
                <p className="text-sm mt-2 line-clamp-2">{occurrence.descricao}</p>
              </div>
            </Popup>
          </Marker>
        ))}

        {selectedLocation && (
          <Marker
            position={[selectedLocation.lat, selectedLocation.lng]}
            icon={selectedLocationIcon}
          >
            <Popup>Local selecionado</Popup>
          </Marker>
        )}
      </MapContainer>

      <RoadEditorToolbar
        isDrawing={isDrawingRoad}
        drawingPoints={drawingPoints}
        onStartDrawing={handleStartDrawing}
        onCancelDrawing={handleCancelDrawing}
        onSaveRoad={handleSaveRoad}
      />

      {!isDrawingRoad && savedRoads.length > 0 && (
        <RoadList onDeleteRoad={() => {}} />
      )}

      {showLegend && (
        <div className="absolute bottom-20 left-4 z-[1000] bg-card p-3 rounded-lg shadow-lg border border-card-border max-w-[180px]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Legenda</span>
            <button
              onClick={() => setShowLegend(false)}
              className="text-muted-foreground hover:text-foreground text-xs"
            >
              Ocultar
            </button>
          </div>
          <div className="space-y-1.5">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">Estradas</div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 rounded-full bg-[#ff7f50]" />
              <span className="text-xs">Transamazônica</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 rounded-full bg-[#2563eb]" />
              <span className="text-xs">Ramais/Vicinais</span>
            </div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wide mt-2 mb-1">Marcadores</div>
            <div className="flex items-center gap-2">
              <Home className="h-4 w-4 text-green-500" />
              <span className="text-xs">Propriedades</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-red-500" />
              <span className="text-xs">Rede Elétrica</span>
            </div>
            <div className="flex items-center gap-2">
              <Construction className="h-4 w-4 text-[#ea580c]" />
              <span className="text-xs">Problema Estrada</span>
            </div>
            <div className="flex items-center gap-2">
              <Milestone className="h-4 w-4 text-[#06b6d4]" />
              <span className="text-xs">Ponte</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-yellow-500" />
              <span className="text-xs">Social</span>
            </div>
            <div className="flex items-center gap-2">
              <Wheat className="h-4 w-4 text-purple-500" />
              <span className="text-xs">Roubo de Safra</span>
            </div>
          </div>
        </div>
      )}

      {!showLegend && (
        <Button
          variant="secondary"
          size="icon"
          className="absolute bottom-20 left-4 z-[1000] shadow-md"
          onClick={() => setShowLegend(true)}
          data-testid="button-show-legend"
        >
          <Layers className="h-5 w-5" />
        </Button>
      )}

      {showAddButton && onAddOccurrence && !isDrawingRoad && (
        <Button
          size="lg"
          className="absolute bottom-20 right-4 z-[1000] h-14 w-14 rounded-full shadow-lg"
          onClick={onAddOccurrence}
          data-testid="button-add-occurrence"
        >
          <Plus className="h-6 w-6" />
        </Button>
      )}
    </div>
  );
}
