import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Map, Bell, Users, FolderKanban, Route, FileSignature, User, Settings, MoreHorizontal, X, Wrench, Trophy, Building2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { FiscalizationAlertButton } from "@/components/fiscalization-alert";

const mainNavItems = [
  { path: "/", icon: Map, label: "Mapa" },
  { path: "/ocorrencias", icon: Bell, label: "Alertas" },
  { path: "/associacao", icon: Users, label: "Comunidade" },
  { path: "/projetos", icon: FolderKanban, label: "Projetos" },
];

const moreNavItems = [
  { path: "/pontos", icon: Trophy, label: "Pontos" },
  { path: "/servicos", icon: Wrench, label: "Serviços" },
  { path: "/governo", icon: Building2, label: "Governo" },
  { path: "/estradas", icon: Route, label: "Estradas" },
  { path: "/peticoes", icon: FileSignature, label: "Petições" },
  { path: "/perfil", icon: User, label: "Perfil" },
  { path: "/configuracoes", icon: Settings, label: "Config" },
];

export function BottomNav() {
  const [location] = useLocation();
  const [showMore, setShowMore] = useState(false);

  const isMoreActive = moreNavItems.some(
    (item) => location === item.path || (item.path !== "/" && location.startsWith(item.path))
  );

  return (
    <>
      {showMore && (
        <div 
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm transition-opacity" 
          onClick={() => setShowMore(false)}
          data-testid="more-menu-overlay"
        />
      )}
      
      {showMore && (
        <div className="fixed bottom-[72px] left-4 right-4 z-50 bg-card border border-card-border rounded-2xl p-3 shadow-xl animate-in slide-in-from-bottom-4 fade-in duration-200">
          <div className="flex items-center justify-center gap-2 mb-3 pb-3 border-b border-border">
            <FiscalizationAlertButton 
              className="flex-1 max-w-[200px]" 
              onAlertSent={() => setShowMore(false)} 
            />
          </div>
          <div className="flex items-center justify-around gap-2 flex-wrap">
            {moreNavItems.map((item) => {
              const isActive = location === item.path || 
                (item.path !== "/" && location.startsWith(item.path));
              
              return (
                <Link key={item.path} href={item.path}>
                  <button
                    onClick={() => setShowMore(false)}
                    className={cn(
                      "flex flex-col items-center justify-center gap-1.5 py-3 px-3 transition-all rounded-xl min-w-[70px]",
                      isActive 
                        ? "bg-primary/10 text-primary" 
                        : "text-muted-foreground hover-elevate active-elevate-2"
                    )}
                    data-testid={`nav-${item.label.toLowerCase()}`}
                  >
                    <item.icon className={cn("h-5 w-5 transition-transform", isActive && "scale-110")} />
                    <span className="text-[10px] font-medium">{item.label}</span>
                  </button>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      <nav className="fixed bottom-0 left-0 right-0 z-50 safe-area-bottom">
        <div className="mx-2 mb-2 bg-card border border-card-border rounded-2xl shadow-lg">
          <div className="flex items-center justify-around h-[68px] px-1">
            {mainNavItems.map((item) => {
              const isActive = location === item.path || 
                (item.path !== "/" && location.startsWith(item.path));
              
              return (
                <Link key={item.path} href={item.path}>
                  <button
                    className={cn(
                      "relative flex flex-col items-center justify-center gap-1 w-16 h-14 transition-all rounded-xl",
                      isActive 
                        ? "text-primary" 
                        : "text-muted-foreground hover-elevate"
                    )}
                    data-testid={`nav-${item.label.toLowerCase()}`}
                  >
                    {isActive && (
                      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-full" />
                    )}
                    <div className={cn(
                      "flex items-center justify-center w-10 h-10 rounded-xl transition-all",
                      isActive && "bg-primary/10"
                    )}>
                      <item.icon className={cn(
                        "h-5 w-5 transition-transform",
                        isActive && "scale-110"
                      )} />
                    </div>
                    <span className={cn(
                      "text-[10px] font-medium transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground"
                    )}>
                      {item.label}
                    </span>
                  </button>
                </Link>
              );
            })}
            
            <button
              onClick={() => setShowMore(!showMore)}
              className={cn(
                "relative flex flex-col items-center justify-center gap-1 w-16 h-14 transition-all rounded-xl",
                isMoreActive || showMore
                  ? "text-primary" 
                  : "text-muted-foreground hover-elevate"
              )}
              data-testid="nav-mais"
            >
              {(isMoreActive || showMore) && (
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-full" />
              )}
              <div className={cn(
                "flex items-center justify-center w-10 h-10 rounded-xl transition-all",
                (isMoreActive || showMore) && "bg-primary/10"
              )}>
                {showMore ? (
                  <X className="h-5 w-5 transition-transform rotate-0" />
                ) : (
                  <MoreHorizontal className="h-5 w-5" />
                )}
              </div>
              <span className={cn(
                "text-[10px] font-medium transition-colors",
                (isMoreActive || showMore) ? "text-primary" : "text-muted-foreground"
              )}>
                Mais
              </span>
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}
