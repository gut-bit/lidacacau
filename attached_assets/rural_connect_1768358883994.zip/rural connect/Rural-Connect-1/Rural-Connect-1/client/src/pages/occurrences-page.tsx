import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { OccurrenceCard } from "@/components/occurrence-card";
import { AddOccurrenceDialog } from "@/components/add-occurrence-dialog";
import { OccurrenceDialog } from "@/components/occurrence-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Search, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Occurrence, Vicinal, OccurrenceType, OccurrenceStatus } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function OccurrencesPage() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedOccurrence, setSelectedOccurrence] = useState<Occurrence | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<OccurrenceType | "all">("all");
  const [filterStatus, setFilterStatus] = useState<OccurrenceStatus | "all">("all");

  const { data: occurrences = [], isLoading } = useQuery<Occurrence[]>({
    queryKey: ["/api/occurrences"],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const createOccurrence = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/occurrences", {
        ...data,
        userId: "anonymous",
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      toast({
        title: "Ocorrência registrada",
        description: "Sua ocorrência foi registrada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível registrar a ocorrência.",
        variant: "destructive",
      });
    },
  });

  const deleteOccurrence = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/occurrences/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      toast({
        title: "Ocorrência excluída",
        description: "A ocorrência foi excluída com sucesso!",
      });
      setDeleteConfirmId(null);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a ocorrência.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (occurrence: Occurrence) => {
    setSelectedOccurrence(occurrence);
    setShowEditDialog(true);
  };

  const handleDeleteClick = (occurrenceId: string) => {
    setDeleteConfirmId(occurrenceId);
  };

  const handleDeleteConfirm = () => {
    if (deleteConfirmId) {
      deleteOccurrence.mutate(deleteConfirmId);
    }
  };

  const filteredOccurrences = occurrences.filter((o) => {
    const matchesSearch =
      o.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.descricao.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || o.tipo === filterType;
    const matchesStatus = filterStatus === "all" || o.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-xl font-semibold">Ocorrências</h1>
          <Button onClick={() => setShowAddDialog(true)} data-testid="button-add-occurrence">
            <Plus className="h-4 w-4 mr-1" />
            Nova
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar ocorrências..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>

        <div className="flex gap-2">
          <Select value={filterType} onValueChange={(v) => setFilterType(v as any)}>
            <SelectTrigger className="flex-1" data-testid="select-filter-type">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="electrical">Rede Elétrica</SelectItem>
              <SelectItem value="road">Estrada</SelectItem>
              <SelectItem value="bridge">Ponte</SelectItem>
              <SelectItem value="social">Social</SelectItem>
              <SelectItem value="theft">Roubo de Safra</SelectItem>
              <SelectItem value="other">Outro</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v as any)}>
            <SelectTrigger className="flex-1" data-testid="select-filter-status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="open">Aberto</SelectItem>
              <SelectItem value="in_progress">Em Andamento</SelectItem>
              <SelectItem value="resolved">Resolvido</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-md border bg-card overflow-hidden">
                <Skeleton className="h-40 w-full rounded-none" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-7 w-7 rounded-full" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                    <Skeleton className="h-4 w-16" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredOccurrences.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-medium text-lg">Nenhuma ocorrência encontrada</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {searchQuery || filterType !== "all" || filterStatus !== "all"
                ? "Tente ajustar os filtros de busca"
                : "Seja o primeiro a registrar uma ocorrência!"}
            </p>
          </div>
        ) : (
          filteredOccurrences.map((occurrence) => (
            <OccurrenceCard
              key={occurrence.id}
              occurrence={occurrence}
              onView={() => {}}
              onEdit={() => handleEdit(occurrence)}
              onDelete={() => handleDeleteClick(occurrence.id)}
            />
          ))
        )}
      </main>

      <AddOccurrenceDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        vicinais={vicinais}
        onSubmit={async (data) => {
          await createOccurrence.mutateAsync(data);
        }}
      />

      <OccurrenceDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        vicinais={vicinais}
        occurrence={selectedOccurrence}
        mode="edit"
      />

      <AlertDialog open={!!deleteConfirmId} onOpenChange={(open) => !open && setDeleteConfirmId(null)}>
        <AlertDialogContent data-testid="dialog-delete-confirm">
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta ocorrência? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
