import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  FolderKanban,
  HandCoins,
  Loader2,
  Building2,
  Hammer,
  Wrench,
  Droplets,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Receipt,
  Users,
  Calendar
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import type { 
  Project, 
  Association,
  Contribution,
  Transaction,
  ProjectType,
  ProjectStatus
} from "@shared/schema";

const PROJECT_TYPE_LABELS: Record<ProjectType, string> = {
  construcao: "Construção",
  manutencao: "Manutenção",
  infraestrutura: "Infraestrutura",
  servico: "Serviço",
  outro: "Outro",
};

const PROJECT_TYPE_ICONS: Record<ProjectType, typeof Building2> = {
  construcao: Building2,
  manutencao: Wrench,
  infraestrutura: Hammer,
  servico: Droplets,
  outro: HelpCircle,
};

const PROJECT_STATUS_LABELS: Record<ProjectStatus, string> = {
  proposta: "Proposta",
  aprovado: "Aprovado",
  em_arrecadacao: "Em Arrecadação",
  em_execucao: "Em Execução",
  concluido: "Concluído",
  cancelado: "Cancelado",
};

const PROJECT_STATUS_VARIANTS: Record<ProjectStatus, "default" | "secondary" | "destructive" | "outline"> = {
  proposta: "outline",
  aprovado: "secondary",
  em_arrecadacao: "default",
  em_execucao: "default",
  concluido: "secondary",
  cancelado: "destructive",
};

const projectFormSchema = z.object({
  titulo: z.string().min(3, "Título deve ter pelo menos 3 caracteres"),
  descricao: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  tipo: z.enum(["construcao", "manutencao", "infraestrutura", "servico", "outro"]),
  associationId: z.string().min(1, "Selecione uma associação"),
  orcamento: z.coerce.number().min(1, "Orçamento deve ser maior que zero"),
  metaArrecadacao: z.coerce.number().optional(),
  prazoConclusao: z.string().optional(),
});

type ProjectFormData = z.infer<typeof projectFormSchema>;

const contributionFormSchema = z.object({
  userName: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  valor: z.coerce.number().min(1, "Valor deve ser maior que zero"),
  metodoPagamento: z.string().optional(),
});

type ContributionFormData = z.infer<typeof contributionFormSchema>;

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString("pt-BR");
}

interface ProjectCardProps {
  project: Project;
  association?: Association;
  onContribute: (project: Project) => void;
  onViewDetails: (project: Project) => void;
}

function ProjectCard({ project, association, onContribute, onViewDetails }: ProjectCardProps) {
  const progress = project.orcamento > 0 
    ? Math.min(100, ((project.arrecadado || 0) / project.orcamento) * 100) 
    : 0;
  
  const TypeIcon = PROJECT_TYPE_ICONS[project.tipo];
  
  return (
    <Card className="overflow-visible" data-testid={`card-project-${project.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="p-2 rounded-md bg-muted">
              <TypeIcon className="h-4 w-4" />
            </div>
            <div>
              <CardTitle className="text-base">{project.titulo}</CardTitle>
              {association && (
                <CardDescription className="text-xs mt-0.5">
                  {association.nome}
                </CardDescription>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline">
              {PROJECT_TYPE_LABELS[project.tipo]}
            </Badge>
            <Badge variant={PROJECT_STATUS_VARIANTS[project.status]}>
              {PROJECT_STATUS_LABELS[project.status]}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {project.descricao}
        </p>
        
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Arrecadado</span>
            <span className="font-medium">
              {formatCurrency(project.arrecadado || 0)} / {formatCurrency(project.orcamento)}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-muted-foreground text-right">
            {progress.toFixed(0)}% da meta
          </p>
        </div>
        
        {project.prazoConclusao && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>Prazo: {formatDate(project.prazoConclusao)}</span>
          </div>
        )}
        
        <div className="flex items-center gap-2 flex-wrap pt-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onViewDetails(project)}
            data-testid={`button-view-project-${project.id}`}
          >
            Ver Detalhes
          </Button>
          {project.status !== "concluido" && project.status !== "cancelado" && (
            <Button 
              size="sm" 
              onClick={() => onContribute(project)}
              data-testid={`button-contribute-${project.id}`}
            >
              <HandCoins className="h-4 w-4 mr-1" />
              Contribuir
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface ProjectDetailsDialogProps {
  project: Project | null;
  association?: Association;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onContribute: (project: Project) => void;
}

function ProjectDetailsDialog({ 
  project, 
  association, 
  open, 
  onOpenChange, 
  onContribute 
}: ProjectDetailsDialogProps) {
  const [showContributors, setShowContributors] = useState(true);
  const [showTransactions, setShowTransactions] = useState(true);
  
  const { data: contributions = [], isLoading: isLoadingContributions } = useQuery<Contribution[]>({
    queryKey: ["/api/projects", project?.id, "contributions"],
    enabled: !!project?.id,
  });
  
  const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/projects", project?.id, "transactions"],
    enabled: !!project?.id,
  });
  
  if (!project) return null;
  
  const progress = project.orcamento > 0 
    ? Math.min(100, ((project.arrecadado || 0) / project.orcamento) * 100) 
    : 0;
  
  const TypeIcon = PROJECT_TYPE_ICONS[project.tipo];
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="p-2 rounded-md bg-muted">
              <TypeIcon className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle>{project.titulo}</DialogTitle>
              <DialogDescription>
                {association?.nome || "Projeto Comunitário"}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline">
              {PROJECT_TYPE_LABELS[project.tipo]}
            </Badge>
            <Badge variant={PROJECT_STATUS_VARIANTS[project.status]}>
              {PROJECT_STATUS_LABELS[project.status]}
            </Badge>
          </div>
          
          <p className="text-sm text-muted-foreground">{project.descricao}</p>
          
          <div className="space-y-2 p-4 bg-muted/50 rounded-md">
            <div className="flex items-center justify-between">
              <span className="font-medium">Progresso Financeiro</span>
              <span className="text-sm text-muted-foreground">{progress.toFixed(0)}%</span>
            </div>
            <Progress value={progress} className="h-3" />
            <div className="flex items-center justify-between text-sm">
              <span>Arrecadado: {formatCurrency(project.arrecadado || 0)}</span>
              <span>Meta: {formatCurrency(project.orcamento)}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Criado em:</span>
              <p className="font-medium">{formatDate(project.createdAt)}</p>
            </div>
            {project.prazoConclusao && (
              <div>
                <span className="text-muted-foreground">Prazo:</span>
                <p className="font-medium">{formatDate(project.prazoConclusao)}</p>
              </div>
            )}
          </div>
          
          {project.status !== "concluido" && project.status !== "cancelado" && (
            <Button 
              className="w-full" 
              onClick={() => onContribute(project)}
              data-testid="button-contribute-details"
            >
              <HandCoins className="h-4 w-4 mr-2" />
              Contribuir para este Projeto
            </Button>
          )}
          
          <div className="border-t pt-4">
            <button
              className="flex items-center justify-between w-full text-left"
              onClick={() => setShowContributors(!showContributors)}
              data-testid="button-toggle-contributors"
            >
              <div className="flex items-center gap-2 font-medium">
                <Users className="h-4 w-4" />
                <span>Contribuidores ({contributions.length})</span>
              </div>
              {showContributors ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
            
            {showContributors && (
              <div className="mt-3 space-y-2">
                {isLoadingContributions ? (
                  <>
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                  </>
                ) : contributions.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-2">
                    Nenhuma contribuição ainda. Seja o primeiro a contribuir!
                  </p>
                ) : (
                  contributions.map((contribution) => (
                    <div 
                      key={contribution.id} 
                      className="flex items-center justify-between p-3 bg-muted/30 rounded-md"
                      data-testid={`contribution-${contribution.id}`}
                    >
                      <div>
                        <p className="font-medium text-sm">
                          {contribution.isAnonymous ? "Anônimo" : contribution.userName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(contribution.createdAt)}
                          {contribution.metodoPagamento && ` • ${contribution.metodoPagamento}`}
                        </p>
                      </div>
                      <span className="font-medium text-sm text-green-600 dark:text-green-400">
                        +{formatCurrency(contribution.valor)}
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
          
          <div className="border-t pt-4">
            <button
              className="flex items-center justify-between w-full text-left"
              onClick={() => setShowTransactions(!showTransactions)}
              data-testid="button-toggle-transactions"
            >
              <div className="flex items-center gap-2 font-medium">
                <Receipt className="h-4 w-4" />
                <span>Movimentações ({transactions.length})</span>
              </div>
              {showTransactions ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
            
            {showTransactions && (
              <div className="mt-3 space-y-2">
                {isLoadingTransactions ? (
                  <>
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                  </>
                ) : transactions.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-2">
                    Nenhuma movimentação registrada.
                  </p>
                ) : (
                  transactions.map((transaction) => (
                    <div 
                      key={transaction.id} 
                      className="flex items-center justify-between p-3 bg-muted/30 rounded-md"
                      data-testid={`transaction-${transaction.id}`}
                    >
                      <div>
                        <p className="font-medium text-sm">{transaction.descricao}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(transaction.createdAt)}
                          {transaction.categoria && ` • ${transaction.categoria}`}
                        </p>
                      </div>
                      <span className={`font-medium text-sm ${
                        transaction.tipo === "despesa" || transaction.tipo === "pagamento_servico" || transaction.tipo === "compra_material"
                          ? "text-red-600 dark:text-red-400" 
                          : "text-green-600 dark:text-green-400"
                      }`}>
                        {transaction.tipo === "despesa" || transaction.tipo === "pagamento_servico" || transaction.tipo === "compra_material" ? "-" : "+"}
                        {formatCurrency(transaction.valor)}
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function ProjectsPage() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showContributeDialog, setShowContributeDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAssociationId, setSelectedAssociationId] = useState<string>("all");
  
  const currentUserId = typeof window !== "undefined" 
    ? localStorage.getItem("currentUserId") 
    : null;
  const currentUserName = typeof window !== "undefined" 
    ? localStorage.getItem("currentUserName") 
    : null;
  
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  const { data: associations = [] } = useQuery<Association[]>({
    queryKey: ["/api/associations"],
  });
  
  const projectForm = useForm<ProjectFormData>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      tipo: "construcao",
      associationId: "",
      orcamento: 0,
      metaArrecadacao: undefined,
      prazoConclusao: "",
    },
  });
  
  const contributionForm = useForm<ContributionFormData>({
    resolver: zodResolver(contributionFormSchema),
    defaultValues: {
      userName: currentUserName || "",
      valor: 0,
      metodoPagamento: "",
    },
  });
  
  const createProject = useMutation({
    mutationFn: async (data: ProjectFormData) => {
      return apiRequest("POST", "/api/projects", {
        ...data,
        createdBy: currentUserId || "anonymous",
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Projeto criado",
        description: "O projeto foi criado com sucesso!",
      });
      projectForm.reset();
      setShowAddDialog(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar o projeto.",
        variant: "destructive",
      });
    },
  });
  
  const createContribution = useMutation({
    mutationFn: async (data: ContributionFormData) => {
      if (!selectedProject) throw new Error("No project selected");
      return apiRequest("POST", "/api/contributions", {
        ...data,
        projectId: selectedProject.id,
        userId: currentUserId || null,
        registeredBy: currentUserId || "anonymous",
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      if (selectedProject) {
        queryClient.invalidateQueries({ 
          queryKey: ["/api/projects", selectedProject.id, "contributions"] 
        });
      }
      toast({
        title: "Contribuição registrada",
        description: "Sua contribuição foi registrada com sucesso!",
      });
      contributionForm.reset();
      setShowContributeDialog(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível registrar a contribuição.",
        variant: "destructive",
      });
    },
  });
  
  const handleContribute = (project: Project) => {
    setSelectedProject(project);
    contributionForm.setValue("userName", currentUserName || "");
    setShowContributeDialog(true);
  };
  
  const handleViewDetails = (project: Project) => {
    setSelectedProject(project);
    setShowDetailsDialog(true);
  };
  
  const handleSubmitProject = async (data: ProjectFormData) => {
    await createProject.mutateAsync(data);
  };
  
  const handleSubmitContribution = async (data: ContributionFormData) => {
    await createContribution.mutateAsync(data);
  };
  
  const getAssociation = (associationId: string) => {
    return associations.find(a => a.id === associationId);
  };
  
  const filteredProjects = projects.filter((p) => {
    const matchesSearch = p.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.descricao.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAssociation = selectedAssociationId === "all" || p.associationId === selectedAssociationId;
    return matchesSearch && matchesAssociation;
  });
  
  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-xl font-semibold" data-testid="text-page-title">Projetos</h1>
          <Button 
            onClick={() => {
              if (!currentUserId) {
                toast({
                  title: "Cadastre-se primeiro",
                  description: "Você precisa estar cadastrado para criar um projeto.",
                  variant: "destructive",
                });
                return;
              }
              setShowAddDialog(true);
            }} 
            data-testid="button-add-project"
          >
            <Plus className="h-4 w-4 mr-1" />
            Novo Projeto
          </Button>
        </div>
        
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar projetos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search-projects"
            />
          </div>
          <Select value={selectedAssociationId} onValueChange={setSelectedAssociationId}>
            <SelectTrigger className="w-auto min-w-[180px]" data-testid="select-filter-association">
              <SelectValue placeholder="Filtrar por associação" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as associações</SelectItem>
              {associations.map((association) => (
                <SelectItem key={association.id} value={association.id}>
                  {association.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        {isLoadingProjects ? (
          <>
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-48 w-full" />
          </>
        ) : filteredProjects.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <FolderKanban className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-medium text-lg" data-testid="text-empty-title">
              Nenhum projeto encontrado
            </h3>
            <p className="text-sm text-muted-foreground mt-1" data-testid="text-empty-description">
              Crie o primeiro projeto da sua comunidade!
            </p>
          </div>
        ) : (
          filteredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              association={getAssociation(project.associationId)}
              onContribute={handleContribute}
              onViewDetails={handleViewDetails}
            />
          ))
        )}
      </main>
      
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Novo Projeto</DialogTitle>
            <DialogDescription>
              Crie uma proposta de projeto para sua comunidade.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...projectForm}>
            <form onSubmit={projectForm.handleSubmit(handleSubmitProject)} className="space-y-4">
              <FormField
                control={projectForm.control}
                name="titulo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Título</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Ex: Construção de ponte na vicinal X" 
                        {...field} 
                        data-testid="input-project-title"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={projectForm.control}
                name="descricao"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Descreva o projeto em detalhes..." 
                        {...field} 
                        data-testid="input-project-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={projectForm.control}
                  name="tipo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-project-type">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="construcao">Construção</SelectItem>
                          <SelectItem value="manutencao">Manutenção</SelectItem>
                          <SelectItem value="infraestrutura">Infraestrutura</SelectItem>
                          <SelectItem value="servico">Serviço</SelectItem>
                          <SelectItem value="outro">Outro</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={projectForm.control}
                  name="associationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Associação</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-project-association">
                            <SelectValue placeholder="Selecione" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {associations.map((association) => (
                            <SelectItem key={association.id} value={association.id}>
                              {association.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={projectForm.control}
                  name="orcamento"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Orçamento (R$)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0.00" 
                          {...field} 
                          data-testid="input-project-budget"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={projectForm.control}
                  name="prazoConclusao"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prazo de Conclusão</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field} 
                          data-testid="input-project-deadline"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={createProject.isPending}
                data-testid="button-submit-project"
              >
                {createProject.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Criando...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Criar Projeto
                  </>
                )}
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showContributeDialog} onOpenChange={setShowContributeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contribuir</DialogTitle>
            <DialogDescription>
              {selectedProject && (
                <>Contribua para o projeto: <strong>{selectedProject.titulo}</strong></>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...contributionForm}>
            <form onSubmit={contributionForm.handleSubmit(handleSubmitContribution)} className="space-y-4">
              <FormField
                control={contributionForm.control}
                name="userName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Seu Nome</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Nome do contribuidor" 
                        {...field} 
                        data-testid="input-contribution-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contributionForm.control}
                name="valor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Valor (R$)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0.00" 
                        {...field} 
                        data-testid="input-contribution-value"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={contributionForm.control}
                name="metodoPagamento"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Método de Pagamento (opcional)</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-payment-method">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="dinheiro">Dinheiro</SelectItem>
                        <SelectItem value="transferencia">Transferência</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={createContribution.isPending}
                data-testid="button-submit-contribution"
              >
                {createContribution.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Registrando...
                  </>
                ) : (
                  <>
                    <HandCoins className="h-4 w-4 mr-2" />
                    Confirmar Contribuição
                  </>
                )}
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <ProjectDetailsDialog
        project={selectedProject}
        association={selectedProject ? getAssociation(selectedProject.associationId) : undefined}
        open={showDetailsDialog}
        onOpenChange={setShowDetailsDialog}
        onContribute={handleContribute}
      />
    </div>
  );
}
