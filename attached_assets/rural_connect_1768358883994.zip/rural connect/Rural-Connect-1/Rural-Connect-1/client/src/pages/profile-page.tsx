import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { RegisterUserDialog } from "@/components/register-user-dialog";
import { PointsBadge } from "@/components/points-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  User,
  MapPin,
  Phone,
  FileText,
  Edit,
  LogOut,
  ChevronRight,
  AlertTriangle,
  FileSignature,
  Trophy,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User as UserType, Vicinal, Occurrence, Petition } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProfilePage() {
  const { toast } = useToast();
  const [showRegisterDialog, setShowRegisterDialog] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("currentUserId");
    }
    return null;
  });

  const { data: users = [] } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: occurrences = [] } = useQuery<Occurrence[]>({
    queryKey: ["/api/occurrences"],
  });

  const { data: petitions = [] } = useQuery<Petition[]>({
    queryKey: ["/api/petitions"],
  });

  const currentUser = currentUserId ? users.find((u) => u.id === currentUserId) : null;
  const userVicinal = currentUser?.vicinalId
    ? vicinais.find((v) => v.id === currentUser.vicinalId)
    : null;
  const userOccurrences = currentUserId
    ? occurrences.filter((o) => o.userId === currentUserId)
    : [];
  const userPetitions = currentUserId
    ? petitions.filter((p) => p.userId === currentUserId)
    : [];

  const createUser = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/users", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      if (data.id) {
        setCurrentUserId(data.id);
        localStorage.setItem("currentUserId", data.id);
      }
      toast({
        title: "Cadastro realizado",
        description: "Bem-vindo à comunidade!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível realizar o cadastro.",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    setCurrentUserId(null);
    localStorage.removeItem("currentUserId");
    toast({
      title: "Desconectado",
      description: "Você saiu da sua conta.",
    });
  };

  if (!currentUser) {
    return (
      <div className="flex flex-col h-full">
        <header className="sticky top-0 z-40 bg-background border-b p-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold">Perfil</h1>
          <ThemeToggle />
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-6 pb-20">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
            <User className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-center">Bem-vindo!</h2>
          <p className="text-muted-foreground text-center mt-2 max-w-xs">
            Cadastre-se para participar da comunidade, registrar ocorrências e assinar abaixo-assinados.
          </p>
          <Button
            className="mt-6 w-full max-w-xs"
            onClick={() => setShowRegisterDialog(true)}
            data-testid="button-register"
          >
            Cadastrar-se
          </Button>
        </main>

        <RegisterUserDialog
          open={showRegisterDialog}
          onOpenChange={setShowRegisterDialog}
          vicinais={vicinais}
          onSubmit={async (data) => {
            await createUser.mutateAsync(data);
          }}
        />
      </div>
    );
  }

  const initials = currentUser.nome
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold">Perfil</h1>
        <ThemeToggle />
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="bg-primary text-primary-foreground text-xl font-medium">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <h2 className="font-semibold text-lg truncate">{currentUser.nome}</h2>
                {currentUser.propriedadeNome && (
                  <p className="text-sm text-muted-foreground truncate">
                    {currentUser.propriedadeNome}
                  </p>
                )}
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  {userVicinal && (
                    <Badge variant="secondary">
                      <MapPin className="h-3 w-3 mr-1" />
                      {userVicinal.nome}
                    </Badge>
                  )}
                  <PointsBadge userId={currentUserId} showLevel={false} />
                </div>
              </div>
              <Button variant="ghost" size="icon" data-testid="button-edit-profile">
                <Edit className="h-5 w-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Informações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-muted">
                <FileText className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">CPF</p>
                <p className="text-sm font-medium">{currentUser.cpf}</p>
              </div>
            </div>

            {currentUser.car && (
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-muted">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">CAR</p>
                  <p className="text-sm font-medium truncate">{currentUser.car}</p>
                </div>
              </div>
            )}

            {currentUser.telefone && (
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-muted">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">Telefone</p>
                  <p className="text-sm font-medium">{currentUser.telefone}</p>
                </div>
              </div>
            )}

            {currentUser.latitude && currentUser.longitude && (
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-muted">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">Localização</p>
                  <p className="text-sm font-medium">
                    {currentUser.latitude.toFixed(4)}, {currentUser.longitude.toFixed(4)}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Minhas Atividades</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <button className="w-full flex items-center gap-3 p-3 rounded-lg hover-elevate" data-testid="button-my-occurrences">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Minhas Ocorrências</p>
                <p className="text-xs text-muted-foreground">
                  {userOccurrences.length} registradas
                </p>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>

            <button className="w-full flex items-center gap-3 p-3 rounded-lg hover-elevate" data-testid="button-my-petitions">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileSignature className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Meus Abaixo-Assinados</p>
                <p className="text-xs text-muted-foreground">
                  {userPetitions.length} criados
                </p>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>

            <Link href="/pontos">
              <button className="w-full flex items-center gap-3 p-3 rounded-lg hover-elevate" data-testid="button-my-points">
                <div className="p-2 rounded-lg bg-yellow-500/10">
                  <Trophy className="h-4 w-4 text-yellow-500" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium">Minha Pontuação</p>
                  <p className="text-xs text-muted-foreground">
                    Ver ranking e histórico
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
            </Link>
          </CardContent>
        </Card>

        <Button
          variant="outline"
          className="w-full text-destructive border-destructive/30"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sair da Conta
        </Button>
      </main>
    </div>
  );
}
