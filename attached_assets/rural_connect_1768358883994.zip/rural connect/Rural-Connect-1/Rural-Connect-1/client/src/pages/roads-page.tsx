import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MapContainer, TileLayer, Polyline, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Save, X, Undo2, Route, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Road, RoadClassification } from "@shared/schema";
import "leaflet/dist/leaflet.css";

const roadColors = [
  { value: "#2563eb", label: "Azul" },
  { value: "#dc2626", label: "Vermelho" },
  { value: "#16a34a", label: "Verde" },
  { value: "#ea580c", label: "Laranja" },
  { value: "#7c3aed", label: "Roxo" },
  { value: "#0891b2", label: "Ciano" },
  { value: "#4b5563", label: "Cinza" },
];

const drawMarkerIcon = new L.DivIcon({
  className: "custom-marker",
  html: `<div style="width: 16px; height: 16px; background: #2563eb; border: 3px solid white; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

function DrawingLayer({
  points,
  onAddPoint,
  color,
}: {
  points: [number, number][];
  onAddPoint: (point: [number, number]) => void;
  color: string;
}) {
  useMapEvents({
    click(e) {
      onAddPoint([e.latlng.lat, e.latlng.lng]);
    },
  });

  return (
    <>
      {points.length >= 2 && (
        <Polyline
          positions={points}
          pathOptions={{ color, weight: 4, opacity: 0.8 }}
        />
      )}
      {points.map((point, index) => (
        <Marker key={index} position={point} icon={drawMarkerIcon} />
      ))}
    </>
  );
}

export default function RoadsPage() {
  const { toast } = useToast();
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingPoints, setDrawingPoints] = useState<[number, number][]>([]);
  const [selectedColor, setSelectedColor] = useState("#2563eb");
  const [classification, setClassification] = useState<RoadClassification>("ramal");
  const [roadName, setRoadName] = useState("");
  const [showSaveDialog, setShowSaveDialog] = useState(false);

  const { data: roads = [], isLoading } = useQuery<Road[]>({
    queryKey: ["/api/roads"],
  });

  const createRoad = useMutation({
    mutationFn: async (data: {
      nome: string;
      classification: RoadClassification;
      coordinates: string;
      color: string;
    }) => {
      return apiRequest("POST", "/api/roads", {
        ...data,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roads"] });
      toast({ title: "Estrada salva com sucesso!" });
      resetDrawing();
    },
    onError: () => {
      toast({ title: "Erro ao salvar estrada", variant: "destructive" });
    },
  });

  const deleteRoad = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/roads/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roads"] });
      toast({ title: "Estrada removida" });
    },
  });

  const resetDrawing = () => {
    setIsDrawing(false);
    setDrawingPoints([]);
    setRoadName("");
    setClassification("ramal");
    setShowSaveDialog(false);
  };

  const handleAddPoint = (point: [number, number]) => {
    setDrawingPoints((prev) => [...prev, point]);
  };

  const handleUndo = () => {
    setDrawingPoints((prev) => prev.slice(0, -1));
  };

  const handleSave = () => {
    if (!roadName.trim() || drawingPoints.length < 2) return;

    createRoad.mutate({
      nome: roadName.trim(),
      classification,
      coordinates: JSON.stringify(drawingPoints),
      color: selectedColor,
    });
  };

  const parseCoordinates = (coords: string): [number, number][] => {
    try {
      return JSON.parse(coords);
    } catch {
      return [];
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b bg-card">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <Route className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold">Estradas</h1>
          </div>

          {!isDrawing ? (
            <Button onClick={() => setIsDrawing(true)} data-testid="button-start-drawing">
              <Pencil className="h-4 w-4 mr-2" />
              Desenhar Estrada
            </Button>
          ) : (
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Cor:</span>
                <Select value={selectedColor} onValueChange={setSelectedColor}>
                  <SelectTrigger className="w-24" data-testid="select-road-color">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: selectedColor }}
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {roadColors.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        <div className="flex items-center gap-2">
                          <div
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: c.value }}
                          />
                          {c.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Badge variant="secondary" className="gap-1">
                {drawingPoints.length} pontos
              </Badge>

              <Button
                variant="outline"
                size="icon"
                onClick={handleUndo}
                disabled={drawingPoints.length === 0}
                data-testid="button-undo-point"
              >
                <Undo2 className="h-4 w-4" />
              </Button>

              <Button
                variant="outline"
                onClick={resetDrawing}
                data-testid="button-cancel-drawing"
              >
                <X className="h-4 w-4 mr-2" />
                Cancelar
              </Button>

              <Button
                onClick={() => setShowSaveDialog(true)}
                disabled={drawingPoints.length < 2}
                data-testid="button-open-save-dialog"
              >
                <Save className="h-4 w-4 mr-2" />
                Salvar
              </Button>
            </div>
          )}
        </div>

        {isDrawing && (
          <p className="text-sm text-muted-foreground mt-2">
            Toque no mapa para adicionar pontos. A linha conecta automaticamente.
          </p>
        )}
      </div>

      <div className="flex-1 relative">
        <MapContainer
          center={[-3.7304, -53.5]}
          zoom={10}
          className="h-full w-full"
          style={{ cursor: isDrawing ? "crosshair" : "grab" }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {roads.map((road) => {
            const coords = parseCoordinates(road.coordinates);
            if (coords.length < 2) return null;
            return (
              <Polyline
                key={road.id}
                positions={coords}
                pathOptions={{
                  color: road.color || (road.classification === "principal" ? "#ff7f50" : "#2563eb"),
                  weight: road.classification === "principal" ? 5 : 3,
                  opacity: 0.8,
                }}
              />
            );
          })}

          {isDrawing && (
            <DrawingLayer
              points={drawingPoints}
              onAddPoint={handleAddPoint}
              color={selectedColor}
            />
          )}
        </MapContainer>
      </div>

      {!isDrawing && roads.length > 0 && (
        <div className="p-4 border-t bg-card">
          <div className="text-sm font-medium mb-2">Estradas salvas ({roads.length})</div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {roads.map((road) => (
              <Card key={road.id} className="shrink-0 min-w-[150px]">
                <CardContent className="p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{
                        backgroundColor:
                          road.color || (road.classification === "principal" ? "#ff7f50" : "#2563eb"),
                      }}
                    />
                    <span className="text-sm font-medium truncate">{road.nome}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-xs">
                      {road.classification === "principal" ? "Principal" : "Ramal"}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => deleteRoad.mutate(road.id)}
                      disabled={deleteRoad.isPending}
                      data-testid={`button-delete-road-${road.id}`}
                    >
                      {deleteRoad.isPending ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : (
                        <Trash2 className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Salvar Estrada</DialogTitle>
            <DialogDescription>
              Dê um nome e escolha o tipo da estrada.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Nome</label>
              <Input
                value={roadName}
                onChange={(e) => setRoadName(e.target.value)}
                placeholder="Ex: Vicinal km 140 Norte"
                data-testid="input-road-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Tipo</label>
              <Select
                value={classification}
                onValueChange={(v) => setClassification(v as RoadClassification)}
              >
                <SelectTrigger data-testid="select-road-classification">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="principal">Estrada Principal</SelectItem>
                  <SelectItem value="ramal">Ramal / Vicinal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowSaveDialog(false)}>
                Cancelar
              </Button>
              <Button
                className="flex-1"
                onClick={handleSave}
                disabled={!roadName.trim() || createRoad.isPending}
                data-testid="button-confirm-save"
              >
                {createRoad.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Salvar"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
