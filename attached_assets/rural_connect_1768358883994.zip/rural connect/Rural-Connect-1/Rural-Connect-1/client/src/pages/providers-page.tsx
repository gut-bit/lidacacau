import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ProviderCard } from "@/components/provider-card";
import { ProviderDialog } from "@/components/provider-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Filter, Wrench } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ServiceProvider, ProviderService, ProviderCoverage, Vicinal, ServiceCategory } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const categoryFilterOptions: { value: ServiceCategory | "all"; label: string }[] = [
  { value: "all", label: "Todos" },
  { value: "trator_grade", label: "Trator com Grade" },
  { value: "escavadeira", label: "Escavadeira" },
  { value: "patrol", label: "Patrol" },
  { value: "cacamba", label: "Caçamba" },
  { value: "pipa_agua", label: "Pipa de Água" },
  { value: "eletricista", label: "Eletricista" },
  { value: "mecanico", label: "Mecânico" },
  { value: "transporte", label: "Transporte" },
  { value: "construcao", label: "Construção" },
  { value: "outro", label: "Outro" },
];

interface ProviderWithRelations extends ServiceProvider {
  services?: ProviderService[];
  coverage?: ProviderCoverage[];
}

export default function ProvidersPage() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<ServiceCategory | "all">("all");
  const [filterAvailable, setFilterAvailable] = useState(false);

  const { data: providers = [], isLoading } = useQuery<ProviderWithRelations[]>({
    queryKey: ["/api/providers"],
  });

  const { data: allServices = [] } = useQuery<ProviderService[]>({
    queryKey: ["/api/provider-services"],
  });

  const { data: allCoverage = [] } = useQuery<ProviderCoverage[]>({
    queryKey: ["/api/provider-coverage"],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const createProvider = useMutation({
    mutationFn: async (data: any) => {
      const providerData = {
        nome: data.nome,
        tipo: data.tipo,
        cnpjCpf: data.cnpjCpf || null,
        telefone: data.telefone,
        whatsapp: data.whatsapp || null,
        email: data.email || null,
        descricao: data.descricao || null,
        createdAt: new Date().toISOString(),
      };

      const response = await apiRequest("POST", "/api/providers", providerData);
      const provider = await response.json();

      for (const service of data.services) {
        if (service.categoria && service.nome) {
          await apiRequest("POST", "/api/provider-services", {
            providerId: provider.id,
            categoria: service.categoria,
            nome: service.nome,
            precoMinimo: service.precoMinimo || null,
            precoMaximo: service.precoMaximo || null,
            unidadePreco: service.unidadePreco || null,
          });
        }
      }

      for (const vicinalId of data.coverageIds) {
        await apiRequest("POST", "/api/provider-coverage", {
          providerId: provider.id,
          vicinalId,
        });
      }

      for (const dayOfWeek of data.availableDays) {
        await apiRequest("POST", "/api/provider-availability", {
          providerId: provider.id,
          diaSemana: dayOfWeek,
          disponivel: true,
        });
      }

      return provider;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/providers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/provider-services"] });
      queryClient.invalidateQueries({ queryKey: ["/api/provider-coverage"] });
      toast({
        title: "Prestador cadastrado",
        description: "O prestador foi cadastrado com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível cadastrar o prestador.",
        variant: "destructive",
      });
    },
  });

  const getProviderServices = (providerId: string) => {
    return allServices.filter(s => s.providerId === providerId);
  };

  const getProviderCoverageVicinais = (providerId: string) => {
    const coverageIds = allCoverage
      .filter(c => c.providerId === providerId)
      .map(c => c.vicinalId);
    return vicinais.filter(v => coverageIds.includes(v.id));
  };

  const isProviderAvailableToday = () => {
    return true;
  };

  const filteredProviders = providers.filter((provider) => {
    const matchesSearch = provider.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (provider.descricao?.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const providerServices = getProviderServices(provider.id);
    const matchesCategory = filterCategory === "all" || 
      providerServices.some(s => s.categoria === filterCategory);
    
    const matchesAvailable = !filterAvailable || provider.isActive;

    return matchesSearch && matchesCategory && matchesAvailable;
  });

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Wrench className="h-5 w-5 text-primary" />
            <h1 className="text-xl font-semibold" data-testid="text-page-title">
              Prestadores de Serviço
            </h1>
          </div>
          <Button 
            onClick={() => setShowAddDialog(true)} 
            data-testid="button-add-provider"
          >
            <Plus className="h-4 w-4 mr-1" />
            Novo
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar prestadores..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>

        <div className="flex items-center gap-3">
          <Select 
            value={filterCategory} 
            onValueChange={(v) => setFilterCategory(v as any)}
          >
            <SelectTrigger className="flex-1" data-testid="select-filter-category">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              {categoryFilterOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="filter-available"
              checked={filterAvailable}
              onCheckedChange={(checked) => setFilterAvailable(checked === true)}
              data-testid="checkbox-filter-available"
            />
            <label
              htmlFor="filter-available"
              className="text-sm cursor-pointer whitespace-nowrap"
            >
              Disponível Agora
            </label>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-md border bg-card p-4">
                <div className="flex items-start gap-3">
                  <Skeleton className="h-14 w-14 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
                <div className="flex gap-2 mt-4 pt-3 border-t">
                  <Skeleton className="h-9 flex-1" />
                  <Skeleton className="h-9 flex-1" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredProviders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Wrench className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-medium text-lg" data-testid="text-empty-title">
              Nenhum prestador encontrado
            </h3>
            <p className="text-sm text-muted-foreground mt-1" data-testid="text-empty-description">
              {searchQuery || filterCategory !== "all" || filterAvailable
                ? "Tente ajustar os filtros de busca"
                : "Seja o primeiro a cadastrar um prestador!"}
            </p>
            {!searchQuery && filterCategory === "all" && !filterAvailable && (
              <Button 
                onClick={() => setShowAddDialog(true)} 
                className="mt-4"
                data-testid="button-add-first-provider"
              >
                <Plus className="h-4 w-4 mr-1" />
                Cadastrar Prestador
              </Button>
            )}
          </div>
        ) : (
          filteredProviders.map((provider) => (
            <ProviderCard
              key={provider.id}
              provider={provider}
              services={getProviderServices(provider.id)}
              coverageVicinais={getProviderCoverageVicinais(provider.id)}
              isAvailableToday={isProviderAvailableToday()}
              onViewDetails={() => {}}
            />
          ))
        )}
      </main>

      <ProviderDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        vicinais={vicinais}
        onSubmit={async (data) => {
          await createProvider.mutateAsync(data);
        }}
        mode="create"
      />
    </div>
  );
}
