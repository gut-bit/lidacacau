import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { VicinalCard } from "@/components/vicinal-card";
import { UserCard } from "@/components/user-card";
import { AddVicinalDialog } from "@/components/add-vicinal-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, MapPin, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Vicinal, User, Occurrence } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function CommunityPage() {
  const { toast } = useToast();
  const [showAddVicinalDialog, setShowAddVicinalDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: vicinais = [], isLoading: isLoadingVicinais } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: users = [], isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: occurrences = [] } = useQuery<Occurrence[]>({
    queryKey: ["/api/occurrences"],
  });

  const createVicinal = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/vicinais", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vicinais"] });
      toast({
        title: "Vicinal criada",
        description: "A vicinal foi criada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar a vicinal.",
        variant: "destructive",
      });
    },
  });

  const getMemberCount = (vicinalId: string) => {
    return users.filter((u) => u.vicinalId === vicinalId).length;
  };

  const getOccurrenceCount = (vicinalId: string) => {
    return occurrences.filter((o) => o.vicinalId === vicinalId).length;
  };

  const filteredVicinais = vicinais.filter((v) =>
    v.nome.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = users.filter(
    (u) =>
      u.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.propriedadeNome &&
        u.propriedadeNome.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-xl font-semibold">Comunidade</h1>
          <Button onClick={() => setShowAddVicinalDialog(true)} data-testid="button-add-vicinal">
            <Plus className="h-4 w-4 mr-1" />
            Nova Vicinal
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar vicinais ou produtores..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-community"
          />
        </div>
      </header>

      <Tabs defaultValue="vicinais" className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4 grid w-auto grid-cols-2">
          <TabsTrigger value="vicinais" className="gap-2" data-testid="tab-vicinais">
            <MapPin className="h-4 w-4" />
            Vicinais
          </TabsTrigger>
          <TabsTrigger value="produtores" className="gap-2" data-testid="tab-produtores">
            <Users className="h-4 w-4" />
            Produtores
          </TabsTrigger>
        </TabsList>

        <TabsContent value="vicinais" className="flex-1 overflow-y-auto p-4 pb-20 space-y-3 mt-0">
          {isLoadingVicinais ? (
            <>
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-32 w-full" />
            </>
          ) : filteredVicinais.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <MapPin className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">Nenhuma vicinal encontrada</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Crie a primeira vicinal da sua região!
              </p>
            </div>
          ) : (
            filteredVicinais.map((vicinal) => (
              <VicinalCard
                key={vicinal.id}
                vicinal={vicinal}
                memberCount={getMemberCount(vicinal.id)}
                occurrenceCount={getOccurrenceCount(vicinal.id)}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="produtores" className="flex-1 overflow-y-auto p-4 pb-20 space-y-3 mt-0">
          {isLoadingUsers ? (
            <>
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </>
          ) : filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">Nenhum produtor encontrado</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Cadastre-se na aba Perfil!
              </p>
            </div>
          ) : (
            filteredUsers.map((user) => (
              <UserCard key={user.id} user={user} />
            ))
          )}
        </TabsContent>
      </Tabs>

      <AddVicinalDialog
        open={showAddVicinalDialog}
        onOpenChange={setShowAddVicinalDialog}
        onSubmit={async (data) => {
          await createVicinal.mutateAsync(data);
        }}
      />
    </div>
  );
}
