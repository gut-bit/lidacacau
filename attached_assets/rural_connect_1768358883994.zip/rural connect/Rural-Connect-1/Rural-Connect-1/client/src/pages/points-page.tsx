import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/theme-toggle";
import { AwardPointsDialog, actionTypeLabels } from "@/components/award-points-dialog";
import {
  Trophy,
  Star,
  TrendingUp,
  Calendar,
  Plus,
  Zap,
  Heart,
  Hammer,
  DollarSign,
  Users,
  MoreHorizontal,
  AlertTriangle,
  CheckCircle,
  Medal,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { UserPoints, PointEvent, User } from "@shared/schema";

const actionTypeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  limpeza_rede: Zap,
  bom_vizinho: Heart,
  contribuicao_trabalho: Hammer,
  contribuicao_financeira: DollarSign,
  relato_ocorrencia: AlertTriangle,
  resolucao_ocorrencia: CheckCircle,
  participacao_projeto: Users,
  outro: MoreHorizontal,
};

const actionTypeLabelsMap: Record<string, string> = {
  limpeza_rede: "Limpeza da Rede Elétrica",
  bom_vizinho: "Ser Bom Vizinho",
  contribuicao_trabalho: "Contribuição com Trabalho",
  contribuicao_financeira: "Contribuição Financeira",
  relato_ocorrencia: "Relato de Ocorrência",
  resolucao_ocorrencia: "Resolução de Ocorrência",
  participacao_projeto: "Participação em Projeto",
  outro: "Outra Ação",
};

type LeaderboardEntry = UserPoints & { user?: User };

export default function PointsPage() {
  const [showAwardDialog, setShowAwardDialog] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("currentUserId");
    }
    return null;
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: userPoints, isLoading: isLoadingPoints } = useQuery<UserPoints>({
    queryKey: ["/api/points/user", currentUserId],
    queryFn: async () => {
      if (!currentUserId) return { userId: "", totalPontos: 0, pontosDoMes: 0, nivel: 1, updatedAt: "", id: "" };
      const res = await fetch(`/api/points/user/${currentUserId}`);
      return res.json();
    },
    enabled: !!currentUserId,
  });

  const { data: pointEvents = [], isLoading: isLoadingEvents } = useQuery<PointEvent[]>({
    queryKey: ["/api/points/events", currentUserId],
    queryFn: async () => {
      if (!currentUserId) return [];
      const res = await fetch(`/api/points/events/${currentUserId}`);
      return res.json();
    },
    enabled: !!currentUserId,
  });

  const { data: leaderboard = [], isLoading: isLoadingLeaderboard } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/points/leaderboard"],
    queryFn: async () => {
      const res = await fetch("/api/points/leaderboard?limit=20");
      return res.json();
    },
  });

  const totalPontos = userPoints?.totalPontos || 0;
  const pontosDoMes = userPoints?.pontosDoMes || 0;
  const nivel = userPoints?.nivel || 1;
  const pontosProximoNivel = nivel * 100;
  const pontosNoNivelAtual = totalPontos - ((nivel - 1) * 100);
  const progressoNivel = (pontosNoNivelAtual / 100) * 100;

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user?.nome || "Usuário";
  };

  const getUserInitials = (userId: string) => {
    const name = getUserName(userId);
    return name.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase();
  };

  const getMedalColor = (position: number) => {
    switch (position) {
      case 1: return "text-yellow-500";
      case 2: return "text-gray-400";
      case 3: return "text-amber-600";
      default: return "text-muted-foreground";
    }
  };

  const getRowStyle = (position: number, userId: string) => {
    const isCurrentUser = userId === currentUserId;
    if (isCurrentUser) return "bg-primary/10 border-primary/20";
    if (position === 1) return "bg-yellow-500/10";
    if (position === 2) return "bg-gray-200/50 dark:bg-gray-700/30";
    if (position === 3) return "bg-amber-500/10";
    return "";
  };

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-semibold">Pontuação Comunitária</h1>
        </div>
        <ThemeToggle />
      </header>

      <main className="flex-1 overflow-y-auto pb-24">
        <Tabs defaultValue="minha-pontuacao" className="w-full">
          <div className="sticky top-0 z-30 bg-background border-b px-4">
            <TabsList className="w-full grid grid-cols-2 h-12">
              <TabsTrigger value="minha-pontuacao" data-testid="tab-minha-pontuacao">
                Minha Pontuação
              </TabsTrigger>
              <TabsTrigger value="ranking" data-testid="tab-ranking">
                Ranking
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="minha-pontuacao" className="p-4 space-y-4">
            {!currentUserId ? (
              <Card>
                <CardContent className="p-6 text-center">
                  <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Faça login para ver sua pontuação
                  </p>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-3 rounded-xl bg-yellow-500/10">
                          <Star className="h-8 w-8 text-yellow-500 fill-yellow-500" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Total de Pontos</p>
                          {isLoadingPoints ? (
                            <Skeleton className="h-9 w-24" />
                          ) : (
                            <p className="text-3xl font-bold" data-testid="text-total-points">
                              {totalPontos}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-lg px-3 py-1.5">
                        <TrendingUp className="h-4 w-4 mr-1.5" />
                        <span data-testid="text-user-level">Nível {nivel}</span>
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Progresso para Nível {nivel + 1}</span>
                        <span className="font-medium">{pontosNoNivelAtual}/100 pts</span>
                      </div>
                      <Progress value={progressoNivel} className="h-2" data-testid="progress-level" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Pontos do Mês
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoadingPoints ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      <p className="text-2xl font-bold text-primary" data-testid="text-monthly-points">
                        +{pontosDoMes}
                      </p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
                    <CardTitle className="text-base">Histórico de Ações</CardTitle>
                    <Button
                      size="sm"
                      onClick={() => setShowAwardDialog(true)}
                      data-testid="button-register-action"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Registrar Ação
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {isLoadingEvents ? (
                      <>
                        <Skeleton className="h-16 w-full" />
                        <Skeleton className="h-16 w-full" />
                        <Skeleton className="h-16 w-full" />
                      </>
                    ) : pointEvents.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        Nenhuma ação registrada ainda
                      </p>
                    ) : (
                      pointEvents.slice(0, 10).map((event, index) => {
                        const Icon = actionTypeIcons[event.tipoAcao] || MoreHorizontal;
                        return (
                          <div
                            key={event.id || index}
                            className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                            data-testid={`event-item-${index}`}
                          >
                            <div className="p-2 rounded-lg bg-primary/10">
                              <Icon className="h-4 w-4 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate">
                                {actionTypeLabelsMap[event.tipoAcao] || event.tipoAcao}
                              </p>
                              <p className="text-xs text-muted-foreground truncate">
                                {event.descricao}
                              </p>
                            </div>
                            <div className="text-right">
                              <Badge variant="secondary" className="font-bold">
                                +{event.pontos}
                              </Badge>
                              {event.createdAt && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {format(new Date(event.createdAt), "dd MMM", { locale: ptBR })}
                                </p>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          <TabsContent value="ranking" className="p-4 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Ranking da Comunidade
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {isLoadingLeaderboard ? (
                  <>
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                  </>
                ) : leaderboard.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    Nenhum membro no ranking ainda
                  </p>
                ) : (
                  leaderboard.map((entry, index) => {
                    const position = index + 1;
                    const userName = getUserName(entry.userId);
                    const initials = getUserInitials(entry.userId);
                    const isCurrentUser = entry.userId === currentUserId;

                    return (
                      <div
                        key={entry.id || entry.userId}
                        className={cn(
                          "flex items-center gap-3 p-3 rounded-lg border transition-all",
                          getRowStyle(position, entry.userId)
                        )}
                        data-testid={`ranking-item-${position}`}
                      >
                        <div className="w-8 flex justify-center">
                          {position <= 3 ? (
                            <Medal className={cn("h-6 w-6", getMedalColor(position))} />
                          ) : (
                            <span className="text-lg font-bold text-muted-foreground">
                              {position}
                            </span>
                          )}
                        </div>
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className={cn(
                            isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                          )}>
                            {initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className={cn(
                            "font-medium truncate",
                            isCurrentUser && "text-primary"
                          )}>
                            {userName}
                            {isCurrentUser && (
                              <span className="text-xs text-muted-foreground ml-2">(você)</span>
                            )}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Nível {entry.nivel || 1}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge
                            variant={position <= 3 ? "default" : "secondary"}
                            className="font-bold"
                          >
                            {entry.totalPontos || 0} pts
                          </Badge>
                        </div>
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {currentUserId && (
        <AwardPointsDialog
          open={showAwardDialog}
          onOpenChange={setShowAwardDialog}
          userId={currentUserId}
        />
      )}
    </div>
  );
}
