import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Users, MapPin } from "lucide-react";
import { SiWhatsapp, SiFacebook, SiInstagram } from "react-icons/si";
import type { Vicinal, User } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function ContactPage() {
  const { data: vicinais = [], isLoading: isLoadingVicinais } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const getMemberCount = (vicinalId: string) => {
    return users.filter((u) => u.vicinalId === vicinalId).length;
  };

  const vicinaisWithLinks = vicinais.filter(
    (v) => v.whatsappLink || v.facebookLink || v.instagramLink
  );

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4">
        <h1 className="text-xl font-semibold">Contato & Redes Sociais</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Acesse os grupos e redes sociais das vicinais
        </p>
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        {isLoadingVicinais ? (
          <>
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-48 w-full" />
          </>
        ) : vicinaisWithLinks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
              <SiWhatsapp className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-medium text-lg">Nenhum grupo cadastrado</h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-xs">
              As vicinais ainda não cadastraram seus grupos de WhatsApp ou redes sociais
            </p>
          </div>
        ) : (
          vicinaisWithLinks.map((vicinal) => (
            <Card key={vicinal.id} data-testid={`card-contact-${vicinal.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-lg">{vicinal.nome}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="text-xs">
                        <Users className="h-3 w-3 mr-1" />
                        {getMemberCount(vicinal.id)} membros
                      </Badge>
                    </div>
                  </div>
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                {vicinal.descricao && (
                  <p className="text-sm text-muted-foreground">{vicinal.descricao}</p>
                )}

                <div className="space-y-2">
                  {vicinal.whatsappLink && (
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-green-600 border-green-200 hover:bg-green-50 dark:border-green-900 dark:hover:bg-green-950"
                      onClick={() => window.open(vicinal.whatsappLink!, "_blank")}
                      data-testid={`button-whatsapp-${vicinal.id}`}
                    >
                      <SiWhatsapp className="h-5 w-5" />
                      <span className="flex-1 text-left">Grupo do WhatsApp</span>
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  )}

                  {vicinal.facebookLink && (
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-blue-600 border-blue-200 hover:bg-blue-50 dark:border-blue-900 dark:hover:bg-blue-950"
                      onClick={() => window.open(vicinal.facebookLink!, "_blank")}
                      data-testid={`button-facebook-${vicinal.id}`}
                    >
                      <SiFacebook className="h-5 w-5" />
                      <span className="flex-1 text-left">Página do Facebook</span>
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  )}

                  {vicinal.instagramLink && (
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-pink-600 border-pink-200 hover:bg-pink-50 dark:border-pink-900 dark:hover:bg-pink-950"
                      onClick={() => window.open(vicinal.instagramLink!, "_blank")}
                      data-testid={`button-instagram-${vicinal.id}`}
                    >
                      <SiInstagram className="h-5 w-5" />
                      <span className="flex-1 text-left">Perfil do Instagram</span>
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}

        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-full bg-primary/10">
                <SiWhatsapp className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Quer adicionar seu grupo?</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Vá até a aba Comunidade, crie uma vicinal e adicione o link do grupo WhatsApp!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
