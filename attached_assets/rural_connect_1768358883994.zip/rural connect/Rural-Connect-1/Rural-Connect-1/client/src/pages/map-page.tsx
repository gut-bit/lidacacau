import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { GoogleMapView } from "@/components/google-map-view";
import { AddOccurrenceDialog } from "@/components/add-occurrence-dialog";
import { OccurrenceDetailsPanel } from "@/components/occurrence-details-panel";
import { RoadInfoCard } from "@/components/road-info-card";
import { CameraCapture } from "@/components/camera-capture";
import { FloatingActionButton } from "@/components/floating-action-button";
import { FiscalizationAlertBanner } from "@/components/fiscalization-alert";
import { MinimizableCardsProvider, MinimizedCardsTray } from "@/components/minimizable-cards";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isOnline, addToSyncQueue, generateOfflineId } from "@/lib/offline-storage";
import type { Occurrence, Vicinal, User, OccurrenceType, Road, FiscalizationAlert } from "@shared/schema";

type MapMode = "idle" | "placing-occurrence" | "drawing-road";

export default function MapPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showCameraCapture, setShowCameraCapture] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedOccurrence, setSelectedOccurrence] = useState<Occurrence | null>(null);
  const [selectedRoad, setSelectedRoad] = useState<Road | null>(null);
  const [mapMode, setMapMode] = useState<MapMode>("idle");
  const [selectedPinType, setSelectedPinType] = useState<OccurrenceType | null>(null);

  const { data: occurrences = [] } = useQuery<Occurrence[]>({
    queryKey: ["/api/occurrences"],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: activeAlerts = [] } = useQuery<FiscalizationAlert[]>({
    queryKey: ["/api/alerts/active"],
    refetchInterval: 30000,
  });

  const createOccurrence = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/occurrences", {
        ...data,
        userId: "anonymous",
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/occurrences"] });
      toast({
        title: "Ocorrência registrada",
        description: "Sua ocorrência foi registrada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível registrar a ocorrência.",
        variant: "destructive",
      });
    },
  });

  const handleAddOccurrence = () => {
    setShowAddDialog(true);
  };

  const handleMapClick = (lat: number, lng: number) => {
    if (mapMode === "placing-occurrence" && selectedPinType) {
      setSelectedLocation({ lat, lng });
      setShowAddDialog(true);
    } else if (mapMode === "idle") {
      setSelectedOccurrence(null);
    }
  };

  const handleOccurrenceClick = (occurrence: Occurrence) => {
    if (mapMode === "idle") {
      setSelectedOccurrence(occurrence);
      setSelectedRoad(null);
    }
  };

  const handleRoadClick = (road: Road) => {
    if (mapMode === "idle") {
      setSelectedRoad(road);
      setSelectedOccurrence(null);
    }
  };

  const handleSelectPinType = (type: OccurrenceType) => {
    setSelectedPinType(type);
    setMapMode("placing-occurrence");
    setSelectedOccurrence(null);
    toast({
      title: "Modo de posicionamento",
      description: "Toque no mapa para posicionar a ocorrência.",
    });
  };

  const cancelPlacementMode = () => {
    setMapMode("idle");
    setSelectedPinType(null);
    setSelectedLocation(null);
  };

  const handleCameraCapture = async (data: {
    photo: string;
    titulo: string;
    descricao: string;
    tipo: OccurrenceType;
    vicinalId: string;
    latitude: number;
    longitude: number;
    timestamp: string;
  }) => {
    const occurrenceData = {
      titulo: data.titulo,
      descricao: data.descricao,
      tipo: data.tipo,
      vicinalId: data.vicinalId,
      latitude: data.latitude,
      longitude: data.longitude,
      userId: "anonymous",
      createdAt: data.timestamp,
      fotos: [data.photo],
      status: "open" as const,
    };

    if (isOnline()) {
      try {
        await createOccurrence.mutateAsync(occurrenceData);
      } catch {
        await addToSyncQueue({
          id: generateOfflineId(),
          type: "occurrence",
          data: occurrenceData,
          timestamp: new Date().toISOString(),
        });
        toast({
          title: "Salvo localmente",
          description: "Será enviado quando você estiver online.",
        });
      }
    } else {
      await addToSyncQueue({
        id: generateOfflineId(),
        type: "occurrence",
        data: occurrenceData,
        timestamp: new Date().toISOString(),
      });
      toast({
        title: "Salvo localmente",
        description: "Será enviado quando você estiver online.",
      });
    }
  };

  return (
    <MinimizableCardsProvider>
      <div className="h-full relative">
        <FiscalizationAlertBanner alerts={activeAlerts} vicinais={vicinais} />
        
        <GoogleMapView
          occurrences={occurrences}
          users={users}
          vicinais={vicinais}
          onAddOccurrence={handleAddOccurrence}
          onMapClick={handleMapClick}
          onOccurrenceClick={handleOccurrenceClick}
          onRoadClick={handleRoadClick}
          selectedLocation={selectedLocation}
        />

        {selectedOccurrence && mapMode === "idle" && (
          <div className="absolute top-4 right-4 z-[1000] max-w-sm">
            <OccurrenceDetailsPanel
              occurrence={selectedOccurrence}
              vicinais={vicinais}
              onClose={() => setSelectedOccurrence(null)}
            />
          </div>
        )}

        {selectedRoad && mapMode === "idle" && (
          <div className="absolute top-4 right-4 z-[1000] max-w-sm">
            <RoadInfoCard
              roadId={selectedRoad.id}
              onClose={() => setSelectedRoad(null)}
              onEditRoad={() => {
                setSelectedRoad(null);
                navigate("/estradas");
              }}
              onAddOccurrence={() => {
                setSelectedRoad(null);
                setShowAddDialog(true);
              }}
            />
          </div>
        )}

        {mapMode === "placing-occurrence" && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000]">
            <Badge variant="secondary" className="gap-2 px-4 py-2 shadow-lg" data-testid="badge-placement-mode">
              <MapPin className="h-4 w-4" />
              Toque no mapa para posicionar
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5 ml-1"
                onClick={cancelPlacementMode}
                data-testid="button-cancel-placement"
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          </div>
        )}

        <FloatingActionButton
          onSelectPinType={handleSelectPinType}
          onOpenCamera={() => setShowCameraCapture(true)}
          disabled={mapMode === "drawing-road"}
        />

        <AddOccurrenceDialog
          open={showAddDialog}
          onOpenChange={(open) => {
            setShowAddDialog(open);
            if (!open) {
              cancelPlacementMode();
            }
          }}
          vicinais={vicinais}
          defaultLocation={selectedLocation}
          defaultTipo={selectedPinType || undefined}
          onSubmit={async (data) => {
            await createOccurrence.mutateAsync(data);
            cancelPlacementMode();
          }}
        />

        <CameraCapture
          open={showCameraCapture}
          onOpenChange={setShowCameraCapture}
          vicinais={vicinais}
          onCapture={handleCameraCapture}
        />

        <MinimizedCardsTray />
      </div>
    </MinimizableCardsProvider>
  );
}
