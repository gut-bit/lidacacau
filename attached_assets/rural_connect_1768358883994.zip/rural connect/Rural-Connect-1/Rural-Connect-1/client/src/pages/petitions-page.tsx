import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PetitionCard } from "@/components/petition-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, FileSignature, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Petition, Signature, Vicinal, User } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const petitionFormSchema = z.object({
  titulo: z.string().min(3, "Título deve ter pelo menos 3 caracteres"),
  descricao: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  vicinalId: z.string().min(1, "Selecione uma vicinal"),
  targetSignatures: z.coerce.number().min(10).default(50),
});

type PetitionFormData = z.infer<typeof petitionFormSchema>;

export default function PetitionsPage() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentUserId = typeof window !== "undefined" 
    ? localStorage.getItem("currentUserId") 
    : null;

  const { data: petitions = [], isLoading } = useQuery<Petition[]>({
    queryKey: ["/api/petitions"],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const form = useForm<PetitionFormData>({
    resolver: zodResolver(petitionFormSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      vicinalId: "",
      targetSignatures: 50,
    },
  });

  const createPetition = useMutation({
    mutationFn: async (data: PetitionFormData) => {
      return apiRequest("POST", "/api/petitions", {
        ...data,
        userId: currentUserId || "anonymous",
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/petitions"] });
      toast({
        title: "Abaixo-assinado criado",
        description: "Seu abaixo-assinado foi criado com sucesso!",
      });
      form.reset();
      setShowAddDialog(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar o abaixo-assinado.",
        variant: "destructive",
      });
    },
  });

  const signPetition = useMutation({
    mutationFn: async (petitionId: string) => {
      return apiRequest("POST", `/api/petitions/${petitionId}/signatures`, {
        userId: currentUserId,
      });
    },
    onSuccess: (_, petitionId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/petitions"] });
      queryClient.invalidateQueries({ queryKey: [`/api/petitions/${petitionId}/signatures`] });
      toast({
        title: "Assinatura registrada",
        description: "Você assinou o abaixo-assinado com sucesso!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error?.message || "Não foi possível assinar.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (data: PetitionFormData) => {
    setIsSubmitting(true);
    try {
      await createPetition.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredPetitions = petitions.filter((p) =>
    p.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.descricao.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-xl font-semibold">Abaixo-Assinados</h1>
          <Button 
            onClick={() => {
              if (!currentUserId) {
                toast({
                  title: "Cadastre-se primeiro",
                  description: "Você precisa estar cadastrado para criar um abaixo-assinado.",
                  variant: "destructive",
                });
                return;
              }
              setShowAddDialog(true);
            }} 
            data-testid="button-add-petition"
          >
            <Plus className="h-4 w-4 mr-1" />
            Novo
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar abaixo-assinados..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-petitions"
          />
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-20 space-y-4">
        {isLoading ? (
          <>
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-48 w-full" />
          </>
        ) : filteredPetitions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <FileSignature className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-medium text-lg">Nenhum abaixo-assinado</h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-xs">
              {searchQuery
                ? "Tente ajustar sua busca"
                : "Crie o primeiro abaixo-assinado para mobilizar a comunidade!"}
            </p>
          </div>
        ) : (
          filteredPetitions.map((petition) => (
            <PetitionCardWrapper
              key={petition.id}
              petition={petition}
              currentUserId={currentUserId}
              users={users}
              onSign={() => {
                if (!currentUserId) {
                  toast({
                    title: "Cadastre-se primeiro",
                    description: "Você precisa estar cadastrado para assinar.",
                    variant: "destructive",
                  });
                  return;
                }
                signPetition.mutate(petition.id);
              }}
            />
          ))
        )}
      </main>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Novo Abaixo-Assinado</DialogTitle>
            <DialogDescription>
              Crie um abaixo-assinado para mobilizar a comunidade sobre um problema.
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="titulo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Título</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Ex: Reforma da ponte do km 85" 
                        {...field} 
                        data-testid="input-petition-titulo"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="descricao"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva o problema e o que você espera conseguir com este abaixo-assinado..."
                        className="min-h-[100px]"
                        {...field}
                        data-testid="input-petition-descricao"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="vicinalId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vicinal</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-petition-vicinal">
                          <SelectValue placeholder="Selecione a vicinal" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vicinais.map((v) => (
                          <SelectItem key={v.id} value={v.id}>
                            {v.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="targetSignatures"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Meta de assinaturas</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min={10}
                        {...field} 
                        data-testid="input-petition-target"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddDialog(false)}
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1"
                  data-testid="button-submit-petition"
                >
                  {isSubmitting ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : null}
                  Criar
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PetitionCardWrapper({
  petition,
  currentUserId,
  users,
  onSign,
}: {
  petition: Petition;
  currentUserId: string | null;
  users: User[];
  onSign: () => void;
}) {
  const { data: signatures = [] } = useQuery<Signature[]>({
    queryKey: [`/api/petitions/${petition.id}/signatures`],
  });

  const signatoryUsers = signatures
    .map((sig) => users.find((u) => u.id === sig.userId))
    .filter(Boolean) as User[];

  return (
    <PetitionCard
      petition={petition}
      signatures={signatures}
      signatories={signatoryUsers}
      currentUserId={currentUserId || undefined}
      onSign={onSign}
    />
  );
}
