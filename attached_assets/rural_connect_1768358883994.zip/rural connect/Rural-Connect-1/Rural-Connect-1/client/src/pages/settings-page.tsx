import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { VicinalDialog } from "@/components/vicinal-dialog";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  Settings,
  Plus,
  Pencil,
  Trash2,
  Route,
  Bell,
  ChevronRight,
  MapPin,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Vicinal } from "@shared/schema";

export default function SettingsPage() {
  const { toast } = useToast();
  const [showVicinalDialog, setShowVicinalDialog] = useState(false);
  const [editingVicinal, setEditingVicinal] = useState<Vicinal | null>(null);
  const [deletingVicinal, setDeletingVicinal] = useState<Vicinal | null>(null);

  const { data: vicinais = [], isLoading } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/vicinais/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vicinais"] });
      toast({
        title: "Vicinal excluída",
        description: "A vicinal foi removida com sucesso.",
      });
      setDeletingVicinal(null);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a vicinal.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (vicinal: Vicinal) => {
    setEditingVicinal(vicinal);
    setShowVicinalDialog(true);
  };

  const handleAdd = () => {
    setEditingVicinal(null);
    setShowVicinalDialog(true);
  };

  const handleDialogClose = (open: boolean) => {
    setShowVicinalDialog(open);
    if (!open) {
      setEditingVicinal(null);
    }
  };

  const handleDelete = (vicinal: Vicinal) => {
    setDeletingVicinal(vicinal);
  };

  const confirmDelete = () => {
    if (deletingVicinal) {
      deleteMutation.mutate(deletingVicinal.id);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-semibold" data-testid="text-page-title">
            Configurações
          </h1>
        </div>
        <ThemeToggle />
      </header>

      <main className="flex-1 overflow-y-auto p-4 pb-24 space-y-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Vicinais
            </CardTitle>
            <Button
              size="icon"
              variant="ghost"
              onClick={handleAdd}
              data-testid="button-add-vicinal"
            >
              <Plus className="h-5 w-5" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {isLoading ? (
              <>
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </>
            ) : vicinais.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4" data-testid="text-no-vicinais">
                Nenhuma vicinal cadastrada.
              </p>
            ) : (
              vicinais.map((vicinal) => (
                <div
                  key={vicinal.id}
                  className="flex items-center justify-between gap-2 p-3 rounded-lg bg-muted/50"
                  data-testid={`card-vicinal-${vicinal.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate" data-testid={`text-vicinal-nome-${vicinal.id}`}>
                      {vicinal.nome}
                    </p>
                    {vicinal.descricao && (
                      <p
                        className="text-sm text-muted-foreground truncate"
                        data-testid={`text-vicinal-descricao-${vicinal.id}`}
                      >
                        {vicinal.descricao.length > 50
                          ? `${vicinal.descricao.substring(0, 50)}...`
                          : vicinal.descricao}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleEdit(vicinal)}
                      data-testid={`button-edit-vicinal-${vicinal.id}`}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleDelete(vicinal)}
                      data-testid={`button-delete-vicinal-${vicinal.id}`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Gerenciamento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link href="/estradas">
              <button
                className="flex items-center justify-between w-full p-3 rounded-lg bg-muted/50 hover-elevate"
                data-testid="link-manage-roads"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Route className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">Gerenciar Estradas</span>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            </Link>

            <Link href="/ocorrencias">
              <button
                className="flex items-center justify-between w-full p-3 rounded-lg bg-muted/50 hover-elevate"
                data-testid="link-manage-occurrences"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Bell className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">Gerenciar Ocorrências</span>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            </Link>
          </CardContent>
        </Card>
      </main>

      <VicinalDialog
        open={showVicinalDialog}
        onOpenChange={handleDialogClose}
        vicinal={editingVicinal}
      />

      <AlertDialog open={!!deletingVicinal} onOpenChange={(open) => !open && setDeletingVicinal(null)}>
        <AlertDialogContent data-testid="dialog-delete-confirmation">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Vicinal</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a vicinal "{deletingVicinal?.nome}"? 
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Excluindo..." : "Excluir"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
