import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Plus, 
  Search, 
  Users, 
  Building2, 
  UserPlus, 
  Trash2, 
  Edit, 
  FolderKanban,
  Loader2
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { 
  Association, 
  AssociationMember, 
  Vicinal, 
  User, 
  MemberRole 
} from "@shared/schema";

const associationFormSchema = z.object({
  nome: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  cnpj: z.string().optional(),
  descricao: z.string().optional(),
  vicinalId: z.string().min(1, "Selecione uma vicinal"),
});

type AssociationFormData = z.infer<typeof associationFormSchema>;

const memberFormSchema = z.object({
  userId: z.string().min(1, "Selecione um usuário"),
  role: z.enum(["presidente", "vice_presidente", "tesoureiro", "secretario", "fiscal", "membro"]),
});

type MemberFormData = z.infer<typeof memberFormSchema>;

const ROLE_LABELS: Record<MemberRole, string> = {
  presidente: "Presidente",
  vice_presidente: "Vice-Presidente",
  tesoureiro: "Tesoureiro",
  secretario: "Secretário",
  fiscal: "Fiscal",
  membro: "Membro",
};

const ROLE_COLORS: Record<MemberRole, "default" | "secondary" | "destructive" | "outline"> = {
  presidente: "default",
  vice_presidente: "default",
  tesoureiro: "secondary",
  secretario: "secondary",
  fiscal: "outline",
  membro: "outline",
};

export default function AssociationPage() {
  const { toast } = useToast();
  const [showAddAssociationDialog, setShowAddAssociationDialog] = useState(false);
  const [showAddMemberDialog, setShowAddMemberDialog] = useState(false);
  const [showEditAssociationDialog, setShowEditAssociationDialog] = useState(false);
  const [selectedVicinalId, setSelectedVicinalId] = useState<string>("all");
  const [selectedAssociation, setSelectedAssociation] = useState<Association | null>(null);
  const [memberToRemove, setMemberToRemove] = useState<AssociationMember | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: vicinais = [], isLoading: isLoadingVicinais } = useQuery<Vicinal[]>({
    queryKey: ["/api/vicinais"],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: associations = [], isLoading: isLoadingAssociations } = useQuery<Association[]>({
    queryKey: ["/api/associations"],
  });

  const { data: members = [], isLoading: isLoadingMembers } = useQuery<AssociationMember[]>({
    queryKey: ["/api/associations", selectedAssociation?.id, "members"],
    enabled: !!selectedAssociation?.id,
  });

  const associationForm = useForm<AssociationFormData>({
    resolver: zodResolver(associationFormSchema),
    defaultValues: {
      nome: "",
      cnpj: "",
      descricao: "",
      vicinalId: "",
    },
  });

  const editForm = useForm<AssociationFormData>({
    resolver: zodResolver(associationFormSchema),
    defaultValues: {
      nome: "",
      cnpj: "",
      descricao: "",
      vicinalId: "",
    },
  });

  const memberForm = useForm<MemberFormData>({
    resolver: zodResolver(memberFormSchema),
    defaultValues: {
      userId: "",
      role: "membro",
    },
  });

  const createAssociation = useMutation({
    mutationFn: async (data: AssociationFormData) => {
      return apiRequest("POST", "/api/associations", {
        ...data,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/associations"] });
      toast({
        title: "Associação criada",
        description: "A associação foi criada com sucesso!",
      });
      associationForm.reset();
      setShowAddAssociationDialog(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar a associação.",
        variant: "destructive",
      });
    },
  });

  const updateAssociation = useMutation({
    mutationFn: async (data: AssociationFormData) => {
      if (!selectedAssociation) return;
      return apiRequest("PATCH", `/api/associations/${selectedAssociation.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/associations"] });
      toast({
        title: "Associação atualizada",
        description: "A associação foi atualizada com sucesso!",
      });
      editForm.reset();
      setShowEditAssociationDialog(false);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a associação.",
        variant: "destructive",
      });
    },
  });

  const addMember = useMutation({
    mutationFn: async (data: MemberFormData) => {
      if (!selectedAssociation) return;
      return apiRequest("POST", `/api/associations/${selectedAssociation.id}/members`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/associations", selectedAssociation?.id, "members"] 
      });
      toast({
        title: "Membro adicionado",
        description: "O membro foi adicionado com sucesso!",
      });
      memberForm.reset();
      setShowAddMemberDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error?.message || "Não foi possível adicionar o membro.",
        variant: "destructive",
      });
    },
  });

  const updateMemberRole = useMutation({
    mutationFn: async ({ memberId, role }: { memberId: string; role: MemberRole }) => {
      if (!selectedAssociation) return;
      return apiRequest("PATCH", `/api/associations/${selectedAssociation.id}/members/${memberId}`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/associations", selectedAssociation?.id, "members"] 
      });
      toast({
        title: "Cargo atualizado",
        description: "O cargo do membro foi atualizado com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o cargo.",
        variant: "destructive",
      });
    },
  });

  const removeMember = useMutation({
    mutationFn: async (memberId: string) => {
      if (!selectedAssociation) return;
      return apiRequest("DELETE", `/api/associations/${selectedAssociation.id}/members/${memberId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/associations", selectedAssociation?.id, "members"] 
      });
      toast({
        title: "Membro removido",
        description: "O membro foi removido da associação.",
      });
      setMemberToRemove(null);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível remover o membro.",
        variant: "destructive",
      });
    },
  });

  const filteredAssociations = associations.filter((a) => {
    const matchesSearch = a.nome.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesVicinal = selectedVicinalId === "all" || a.vicinalId === selectedVicinalId;
    return matchesSearch && matchesVicinal;
  });

  const getVicinalName = (vicinalId: string) => {
    return vicinais.find((v) => v.id === vicinalId)?.nome || "Vicinal não encontrada";
  };

  const getUserName = (userId: string) => {
    return users.find((u) => u.id === userId)?.nome || "Usuário não encontrado";
  };

  const existingMemberUserIds = members.map((m) => m.userId);
  const availableUsers = users.filter((u) => !existingMemberUserIds.includes(u.id));

  const handleEditClick = (association: Association) => {
    setSelectedAssociation(association);
    editForm.reset({
      nome: association.nome,
      cnpj: association.cnpj || "",
      descricao: association.descricao || "",
      vicinalId: association.vicinalId,
    });
    setShowEditAssociationDialog(true);
  };

  const handleSelectAssociation = (association: Association) => {
    setSelectedAssociation(association);
  };

  return (
    <div className="flex flex-col h-full">
      <header className="sticky top-0 z-40 bg-background border-b p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-xl font-semibold">Associações</h1>
          <Button 
            onClick={() => setShowAddAssociationDialog(true)} 
            data-testid="button-add-association"
          >
            <Plus className="h-4 w-4 mr-1" />
            Nova Associação
          </Button>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar associações..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search-associations"
            />
          </div>
          <Select value={selectedVicinalId} onValueChange={setSelectedVicinalId}>
            <SelectTrigger className="w-full sm:w-48" data-testid="select-vicinal-filter">
              <SelectValue placeholder="Filtrar por vicinal" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as vicinais</SelectItem>
              {vicinais.map((v) => (
                <SelectItem key={v.id} value={v.id}>
                  {v.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </header>

      <Tabs defaultValue="lista" className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4 grid w-auto grid-cols-2">
          <TabsTrigger value="lista" className="gap-2" data-testid="tab-lista">
            <Building2 className="h-4 w-4" />
            Associações
          </TabsTrigger>
          <TabsTrigger 
            value="membros" 
            className="gap-2" 
            disabled={!selectedAssociation}
            data-testid="tab-membros"
          >
            <Users className="h-4 w-4" />
            Membros
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lista" className="flex-1 overflow-y-auto p-4 pb-20 space-y-3 mt-0">
          {isLoadingAssociations || isLoadingVicinais ? (
            <>
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-32 w-full" />
            </>
          ) : filteredAssociations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Building2 className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">Nenhuma associação encontrada</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {searchQuery || selectedVicinalId !== "all"
                  ? "Tente ajustar os filtros de busca"
                  : "Crie a primeira associação da sua comunidade!"}
              </p>
            </div>
          ) : (
            filteredAssociations.map((association) => (
              <Card 
                key={association.id} 
                className={`cursor-pointer transition-colors ${
                  selectedAssociation?.id === association.id 
                    ? "ring-2 ring-primary" 
                    : ""
                }`}
                onClick={() => handleSelectAssociation(association)}
                data-testid={`card-association-${association.id}`}
              >
                <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate" data-testid={`text-association-name-${association.id}`}>
                      {association.nome}
                    </CardTitle>
                    <CardDescription className="text-sm">
                      {getVicinalName(association.vicinalId)}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button 
                      size="icon" 
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditClick(association);
                      }}
                      data-testid={`button-edit-association-${association.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Link href={`/projetos?associationId=${association.id}`}>
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={(e) => e.stopPropagation()}
                        data-testid={`button-projects-${association.id}`}
                      >
                        <FolderKanban className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  {association.cnpj && (
                    <p className="text-sm text-muted-foreground mb-1">
                      CNPJ: {association.cnpj}
                    </p>
                  )}
                  {association.descricao && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {association.descricao}
                    </p>
                  )}
                  {selectedAssociation?.id === association.id && (
                    <p className="text-xs text-primary mt-2">
                      Selecionada - vá para a aba Membros para gerenciar
                    </p>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="membros" className="flex-1 overflow-y-auto p-4 pb-20 mt-0">
          {!selectedAssociation ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">Selecione uma associação</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Volte à aba Associações e clique em uma para gerenciar seus membros
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h2 className="text-lg font-semibold" data-testid="text-selected-association">
                    {selectedAssociation.nome}
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    {members.length} membro(s)
                  </p>
                </div>
                <Button 
                  onClick={() => setShowAddMemberDialog(true)}
                  data-testid="button-add-member"
                >
                  <UserPlus className="h-4 w-4 mr-1" />
                  Adicionar
                </Button>
              </div>

              {isLoadingMembers ? (
                <>
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </>
              ) : members.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 text-center">
                  <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                    <Users className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium">Nenhum membro cadastrado</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Adicione o primeiro membro desta associação
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {members.map((member) => (
                    <Card key={member.id} data-testid={`card-member-${member.id}`}>
                      <CardContent className="flex items-center justify-between gap-2 py-3">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate" data-testid={`text-member-name-${member.id}`}>
                            {getUserName(member.userId)}
                          </p>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <Badge 
                              variant={ROLE_COLORS[member.role as MemberRole]}
                              className="text-xs"
                              data-testid={`badge-role-${member.id}`}
                            >
                              {ROLE_LABELS[member.role as MemberRole]}
                            </Badge>
                            {!member.isActive && (
                              <Badge variant="destructive" className="text-xs">
                                Inativo
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Select
                            value={member.role}
                            onValueChange={(value) => {
                              updateMemberRole.mutate({ 
                                memberId: member.id, 
                                role: value as MemberRole 
                              });
                            }}
                          >
                            <SelectTrigger 
                              className="w-32"
                              data-testid={`select-role-${member.id}`}
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="presidente">Presidente</SelectItem>
                              <SelectItem value="vice_presidente">Vice-Presidente</SelectItem>
                              <SelectItem value="tesoureiro">Tesoureiro</SelectItem>
                              <SelectItem value="secretario">Secretário</SelectItem>
                              <SelectItem value="fiscal">Fiscal</SelectItem>
                              <SelectItem value="membro">Membro</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setMemberToRemove(member)}
                            data-testid={`button-remove-member-${member.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showAddAssociationDialog} onOpenChange={setShowAddAssociationDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nova Associação</DialogTitle>
            <DialogDescription>
              Cadastre uma nova associação para uma vicinal.
            </DialogDescription>
          </DialogHeader>

          <Form {...associationForm}>
            <form 
              onSubmit={associationForm.handleSubmit((data) => createAssociation.mutate(data))} 
              className="space-y-4"
            >
              <FormField
                control={associationForm.control}
                name="vicinalId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vicinal</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-vicinal">
                          <SelectValue placeholder="Selecione uma vicinal" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vicinais.map((v) => (
                          <SelectItem key={v.id} value={v.id}>
                            {v.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={associationForm.control}
                name="nome"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome da Associação</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Ex: Associação dos Produtores da Vicinal X"
                        data-testid="input-association-name"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={associationForm.control}
                name="cnpj"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CNPJ (opcional)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="00.000.000/0001-00"
                        data-testid="input-cnpj"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={associationForm.control}
                name="descricao"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição (opcional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva a associação..."
                        className="resize-none"
                        data-testid="input-description"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddAssociationDialog(false)}
                  data-testid="button-cancel-association"
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  disabled={createAssociation.isPending}
                  data-testid="button-submit-association"
                >
                  {createAssociation.isPending && (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  )}
                  Criar Associação
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditAssociationDialog} onOpenChange={setShowEditAssociationDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Associação</DialogTitle>
            <DialogDescription>
              Atualize os dados da associação.
            </DialogDescription>
          </DialogHeader>

          <Form {...editForm}>
            <form 
              onSubmit={editForm.handleSubmit((data) => updateAssociation.mutate(data))} 
              className="space-y-4"
            >
              <FormField
                control={editForm.control}
                name="vicinalId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vicinal</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="edit-select-vicinal">
                          <SelectValue placeholder="Selecione uma vicinal" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vicinais.map((v) => (
                          <SelectItem key={v.id} value={v.id}>
                            {v.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="nome"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome da Associação</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Ex: Associação dos Produtores da Vicinal X"
                        data-testid="edit-input-name"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="cnpj"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CNPJ (opcional)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="00.000.000/0001-00"
                        data-testid="edit-input-cnpj"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="descricao"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição (opcional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva a associação..."
                        className="resize-none"
                        data-testid="edit-input-description"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowEditAssociationDialog(false)}
                  data-testid="button-cancel-edit"
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateAssociation.isPending}
                  data-testid="button-submit-edit"
                >
                  {updateAssociation.isPending && (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  )}
                  Salvar Alterações
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddMemberDialog} onOpenChange={setShowAddMemberDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Membro</DialogTitle>
            <DialogDescription>
              Adicione um novo membro à associação {selectedAssociation?.nome}.
            </DialogDescription>
          </DialogHeader>

          <Form {...memberForm}>
            <form 
              onSubmit={memberForm.handleSubmit((data) => addMember.mutate(data))} 
              className="space-y-4"
            >
              <FormField
                control={memberForm.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Usuário</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-user">
                          <SelectValue placeholder="Selecione um usuário" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableUsers.length === 0 ? (
                          <div className="p-2 text-sm text-muted-foreground">
                            Nenhum usuário disponível
                          </div>
                        ) : (
                          availableUsers.map((u) => (
                            <SelectItem key={u.id} value={u.id}>
                              {u.nome}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={memberForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cargo</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-role">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="presidente">Presidente</SelectItem>
                        <SelectItem value="vice_presidente">Vice-Presidente</SelectItem>
                        <SelectItem value="tesoureiro">Tesoureiro</SelectItem>
                        <SelectItem value="secretario">Secretário</SelectItem>
                        <SelectItem value="fiscal">Fiscal</SelectItem>
                        <SelectItem value="membro">Membro</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddMemberDialog(false)}
                  data-testid="button-cancel-member"
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  disabled={addMember.isPending || availableUsers.length === 0}
                  data-testid="button-submit-member"
                >
                  {addMember.isPending && (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  )}
                  Adicionar Membro
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!memberToRemove} onOpenChange={() => setMemberToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remover Membro</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover{" "}
              <strong>{memberToRemove ? getUserName(memberToRemove.userId) : ""}</strong>{" "}
              da associação? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-remove">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => memberToRemove && removeMember.mutate(memberToRemove.id)}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-confirm-remove"
            >
              {removeMember.isPending && (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              )}
              Remover
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
