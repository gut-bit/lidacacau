import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Building2, FileText, FolderKanban, Plus, Clock, CheckCircle, 
  AlertTriangle, XCircle, Users, MapPin, Calendar, TrendingUp
} from "lucide-react";
import { BottomNav } from "@/components/bottom-nav";
import type { GovernmentDemand, GovernmentProject, Vicinal } from "@shared/schema";
import { DemandDialog } from "@/components/demand-dialog";

const statusLabels: Record<string, { label: string; color: string }> = {
  pendente: { label: "Pendente", color: "bg-yellow-500" },
  em_analise: { label: "Em Análise", color: "bg-blue-500" },
  aprovado: { label: "Aprovado", color: "bg-green-500" },
  em_execucao: { label: "Em Execução", color: "bg-purple-500" },
  concluido: { label: "Concluído", color: "bg-emerald-600" },
  negado: { label: "Negado", color: "bg-red-500" },
};

const projectStatusLabels: Record<string, { label: string; color: string }> = {
  planejado: { label: "Planejado", color: "bg-gray-500" },
  licitacao: { label: "Licitação", color: "bg-yellow-500" },
  em_execucao: { label: "Em Execução", color: "bg-blue-500" },
  paralisado: { label: "Paralisado", color: "bg-red-500" },
  concluido: { label: "Concluído", color: "bg-green-500" },
  cancelado: { label: "Cancelado", color: "bg-gray-600" },
};

const categoryLabels: Record<string, string> = {
  infraestrutura: "Infraestrutura",
  saude: "Saúde",
  educacao: "Educação",
  seguranca: "Segurança",
  agricultura: "Agricultura",
  meio_ambiente: "Meio Ambiente",
  transporte: "Transporte",
  outro: "Outro",
};

const priorityLabels: Record<string, { label: string; color: string }> = {
  baixa: { label: "Baixa", color: "text-gray-500" },
  media: { label: "Média", color: "text-yellow-600" },
  alta: { label: "Alta", color: "text-orange-500" },
  urgente: { label: "Urgente", color: "text-red-600" },
};

function DemandCard({ demand, vicinais }: { demand: GovernmentDemand; vicinais: Vicinal[] }) {
  const vicinal = vicinais.find(v => v.id === demand.vicinalId);
  const status = statusLabels[demand.status] || statusLabels.pendente;
  const priority = priorityLabels[demand.prioridade] || priorityLabels.media;

  return (
    <Card className="hover-elevate" data-testid={`demand-card-${demand.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base font-semibold line-clamp-2">
              {demand.titulo}
            </CardTitle>
            <CardDescription className="flex items-center gap-2 mt-1">
              <MapPin className="h-3 w-3" />
              {vicinal?.nome || "Vicinal desconhecida"}
            </CardDescription>
          </div>
          <Badge className={`${status.color} text-white shrink-0`}>
            {status.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {demand.descricao}
        </p>
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline">{categoryLabels[demand.categoria]}</Badge>
          <span className={`font-medium ${priority.color}`}>
            {priority.label}
          </span>
          {demand.populacaoAfetada && (
            <span className="flex items-center gap-1 text-muted-foreground">
              <Users className="h-3 w-3" />
              {demand.populacaoAfetada} afetados
            </span>
          )}
        </div>
        {demand.responseGoverno && (
          <div className="mt-3 p-2 bg-muted rounded-md">
            <p className="text-xs font-medium text-muted-foreground">Resposta:</p>
            <p className="text-sm">{demand.responseGoverno}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ProjectCard({ project }: { project: GovernmentProject }) {
  const status = projectStatusLabels[project.status] || projectStatusLabels.planejado;

  return (
    <Card className="hover-elevate" data-testid={`gov-project-card-${project.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base font-semibold line-clamp-2">
              {project.titulo}
            </CardTitle>
            <CardDescription className="flex items-center gap-2 mt-1">
              <Building2 className="h-3 w-3" />
              {project.orgaoResponsavel}
            </CardDescription>
          </div>
          <Badge className={`${status.color} text-white shrink-0`}>
            {status.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {project.descricao}
        </p>
        
        {project.percentualConcluido !== null && project.percentualConcluido !== undefined && (
          <div className="mb-3">
            <div className="flex justify-between text-xs mb-1">
              <span>Progresso</span>
              <span className="font-medium">{project.percentualConcluido}%</span>
            </div>
            <Progress value={project.percentualConcluido} className="h-2" />
          </div>
        )}

        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
          {project.orcamento && (
            <span className="flex items-center gap-1">
              R$ {project.orcamento.toLocaleString('pt-BR')}
            </span>
          )}
          {project.prazoConclusao && (
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              Prazo: {new Date(project.prazoConclusao).toLocaleDateString('pt-BR')}
            </span>
          )}
        </div>

        {project.responsavelNome && (
          <div className="mt-2 text-xs text-muted-foreground">
            Responsável: {project.responsavelNome}
            {project.responsavelContato && ` - ${project.responsavelContato}`}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function GovernmentPage() {
  const [showDemandDialog, setShowDemandDialog] = useState(false);

  const { data: demands = [], isLoading: loadingDemands } = useQuery<GovernmentDemand[]>({
    queryKey: ['/api/government/demands'],
  });

  const { data: projects = [], isLoading: loadingProjects } = useQuery<GovernmentProject[]>({
    queryKey: ['/api/government/projects'],
  });

  const { data: vicinais = [] } = useQuery<Vicinal[]>({
    queryKey: ['/api/vicinais'],
  });

  const demandsByStatus = {
    pendentes: demands.filter(d => d.status === 'pendente' || d.status === 'em_analise'),
    aprovados: demands.filter(d => d.status === 'aprovado' || d.status === 'em_execucao'),
    concluidos: demands.filter(d => d.status === 'concluido'),
  };

  const projectsByStatus = {
    ativos: projects.filter(p => p.status === 'planejado' || p.status === 'licitacao' || p.status === 'em_execucao'),
    concluidos: projects.filter(p => p.status === 'concluido'),
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">Poder Público</h1>
              <p className="text-xs text-muted-foreground">Demandas e projetos do governo</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container px-4 py-4">
        <div className="grid grid-cols-3 gap-3 mb-4">
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-yellow-600">{demandsByStatus.pendentes.length}</div>
            <div className="text-xs text-muted-foreground">Pendentes</div>
          </Card>
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-blue-600">{demandsByStatus.aprovados.length}</div>
            <div className="text-xs text-muted-foreground">Em Andamento</div>
          </Card>
          <Card className="p-3 text-center">
            <div className="text-2xl font-bold text-green-600">{demandsByStatus.concluidos.length}</div>
            <div className="text-xs text-muted-foreground">Concluídos</div>
          </Card>
        </div>

        <Tabs defaultValue="demandas" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="demandas" className="gap-2" data-testid="tab-demandas">
              <FileText className="h-4 w-4" />
              Demandas
            </TabsTrigger>
            <TabsTrigger value="projetos" className="gap-2" data-testid="tab-projetos">
              <FolderKanban className="h-4 w-4" />
              Projetos Gov
            </TabsTrigger>
          </TabsList>

          <TabsContent value="demandas" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-semibold">Demandas da Comunidade</h2>
              <Button size="sm" onClick={() => setShowDemandDialog(true)} data-testid="button-new-demand">
                <Plus className="h-4 w-4 mr-1" />
                Nova
              </Button>
            </div>

            {loadingDemands ? (
              <div className="text-center py-8 text-muted-foreground">Carregando...</div>
            ) : demands.length === 0 ? (
              <Card className="p-8 text-center">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                <p className="text-muted-foreground">Nenhuma demanda registrada</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Registre as necessidades da sua comunidade para o poder público
                </p>
              </Card>
            ) : (
              <div className="space-y-3">
                {demands.map(demand => (
                  <DemandCard key={demand.id} demand={demand} vicinais={vicinais} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="projetos" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-semibold">Projetos do Governo</h2>
              <Badge variant="outline">
                {projectsByStatus.ativos.length} ativos
              </Badge>
            </div>

            {loadingProjects ? (
              <div className="text-center py-8 text-muted-foreground">Carregando...</div>
            ) : projects.length === 0 ? (
              <Card className="p-8 text-center">
                <FolderKanban className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                <p className="text-muted-foreground">Nenhum projeto cadastrado</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Projetos do governo aparecerão aqui para acompanhamento
                </p>
              </Card>
            ) : (
              <div className="space-y-3">
                {projects.map(project => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <DemandDialog 
        open={showDemandDialog} 
        onOpenChange={setShowDemandDialog}
        vicinais={vicinais}
      />

      <BottomNav />
    </div>
  );
}
