const DB_NAME = "transamazonica-offline";
const DB_VERSION = 1;
const STORE_QUEUE = "sync-queue";
const STORE_CACHE = "data-cache";

interface SyncItem {
  id: string;
  type: "occurrence" | "comment" | "road";
  data: any;
  timestamp: string;
  status: "pending" | "syncing" | "failed";
  retries: number;
}

let db: IDBDatabase | null = null;

export async function initOfflineDB(): Promise<IDBDatabase> {
  if (db) return db;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      
      if (!database.objectStoreNames.contains(STORE_QUEUE)) {
        database.createObjectStore(STORE_QUEUE, { keyPath: "id" });
      }
      
      if (!database.objectStoreNames.contains(STORE_CACHE)) {
        database.createObjectStore(STORE_CACHE, { keyPath: "key" });
      }
    };
  });
}

export async function addToSyncQueue(item: Omit<SyncItem, "status" | "retries">): Promise<void> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_QUEUE, "readwrite");
    const store = tx.objectStore(STORE_QUEUE);
    
    const fullItem: SyncItem = {
      ...item,
      status: "pending",
      retries: 0,
    };
    
    const request = store.put(fullItem);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function getSyncQueue(): Promise<SyncItem[]> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_QUEUE, "readonly");
    const store = tx.objectStore(STORE_QUEUE);
    const request = store.getAll();
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result || []);
  });
}

export async function removeFromSyncQueue(id: string): Promise<void> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_QUEUE, "readwrite");
    const store = tx.objectStore(STORE_QUEUE);
    const request = store.delete(id);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function updateSyncItemStatus(id: string, status: SyncItem["status"]): Promise<void> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_QUEUE, "readwrite");
    const store = tx.objectStore(STORE_QUEUE);
    const getRequest = store.get(id);
    
    getRequest.onsuccess = () => {
      const item = getRequest.result;
      if (item) {
        item.status = status;
        item.retries = (item.retries || 0) + (status === "failed" ? 1 : 0);
        store.put(item);
      }
      resolve();
    };
    getRequest.onerror = () => reject(getRequest.error);
  });
}

export async function cacheData(key: string, data: any): Promise<void> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_CACHE, "readwrite");
    const store = tx.objectStore(STORE_CACHE);
    const request = store.put({ key, data, timestamp: new Date().toISOString() });
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function getCachedData<T>(key: string): Promise<T | null> {
  const database = await initOfflineDB();
  
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_CACHE, "readonly");
    const store = tx.objectStore(STORE_CACHE);
    const request = store.get(key);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const result = request.result;
      resolve(result ? result.data : null);
    };
  });
}

export function isOnline(): boolean {
  return navigator.onLine;
}

export function onOnlineStatusChange(callback: (online: boolean) => void): () => void {
  const handleOnline = () => callback(true);
  const handleOffline = () => callback(false);
  
  window.addEventListener("online", handleOnline);
  window.addEventListener("offline", handleOffline);
  
  return () => {
    window.removeEventListener("online", handleOnline);
    window.removeEventListener("offline", handleOffline);
  };
}

export async function syncPendingItems(
  syncFn: (item: SyncItem) => Promise<boolean>
): Promise<{ synced: number; failed: number }> {
  if (!isOnline()) {
    return { synced: 0, failed: 0 };
  }

  const queue = await getSyncQueue();
  const pendingItems = queue.filter((item) => item.status === "pending" || item.status === "failed");
  
  let synced = 0;
  let failed = 0;

  for (const item of pendingItems) {
    if (item.retries >= 3) {
      continue;
    }

    await updateSyncItemStatus(item.id, "syncing");
    
    try {
      const success = await syncFn(item);
      if (success) {
        await removeFromSyncQueue(item.id);
        synced++;
      } else {
        await updateSyncItemStatus(item.id, "failed");
        failed++;
      }
    } catch {
      await updateSyncItemStatus(item.id, "failed");
      failed++;
    }
  }

  return { synced, failed };
}

export function generateOfflineId(): string {
  return `offline-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
