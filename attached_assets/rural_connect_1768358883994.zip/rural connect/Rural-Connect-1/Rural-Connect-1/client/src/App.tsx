import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { BottomNav } from "@/components/bottom-nav";
import { OnlineStatusIndicator } from "@/components/online-status-indicator";
import { WelcomeOverlay } from "@/components/welcome-overlay";
import MapPage from "@/pages/map-page";
import OccurrencesPage from "@/pages/occurrences-page";
import RoadsPage from "@/pages/roads-page";
import PetitionsPage from "@/pages/petitions-page";
import ProfilePage from "@/pages/profile-page";
import AssociationPage from "@/pages/association-page";
import ProjectsPage from "@/pages/projects-page";
import SettingsPage from "@/pages/settings-page";
import ProvidersPage from "@/pages/providers-page";
import PointsPage from "@/pages/points-page";
import GovernmentPage from "@/pages/government-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={MapPage} />
      <Route path="/ocorrencias" component={OccurrencesPage} />
      <Route path="/estradas" component={RoadsPage} />
      <Route path="/peticoes" component={PetitionsPage} />
      <Route path="/perfil" component={ProfilePage} />
      <Route path="/associacao" component={AssociationPage} />
      <Route path="/projetos" component={ProjectsPage} />
      <Route path="/configuracoes" component={SettingsPage} />
      <Route path="/servicos" component={ProvidersPage} />
      <Route path="/pontos" component={PointsPage} />
      <Route path="/governo" component={GovernmentPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <div className="flex flex-col h-screen w-full bg-background">
            <OnlineStatusIndicator />
            <main className="flex-1 overflow-hidden">
              <Router />
            </main>
            <BottomNav />
          </div>
          <WelcomeOverlay />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
