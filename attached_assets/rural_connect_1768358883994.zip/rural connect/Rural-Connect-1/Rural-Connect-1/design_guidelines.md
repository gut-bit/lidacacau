# Design Guidelines: Transamazônica Community Management App
## Rural Amazon Region (Medicilândia - Uruara, Pará)

## Design Approach
**Selected Approach:** Material Design with Warm, Human-Centered Adaptations

**Justification:** Utility-focused app requiring clear data presentation and mobile-first efficiency, but with critical distinction: this is a community solidarity tool, not corporate software. Material Design provides the structural foundation for clarity and accessibility, while we inject warmth through generous imagery, rounded corners, organic shapes, and friendly visual language that reflects the Amazon community's human connection.

**Key References:** Material Design (structure) + Instagram (photo-first) + Airbnb (warmth & trust)

---

## Core Design Principles
1. **Photo-First Storytelling:** Every problem tells a visual story - large images drive engagement
2. **Mobile-Optimized Touch:** 44px minimum targets, bottom-zone navigation, one-handed operation
3. **Gamified Progress:** Visual feedback, achievement indicators, progress celebration
4. **Trust Through Transparency:** Clear status tracking, community visibility, action accountability
5. **Offline-Resilient:** Always-visible sync status, graceful degradation

---

## Typography
- **Primary Font:** Roboto (Google Fonts)
- **Display/Headers:** Roboto Medium (500) - 28px (h1), 22px (h2), 18px (h3)
- **Body Text:** Roboto Regular (400) - 16px content, 14px metadata
- **Emphasis:** Roboto Medium (500) - 16px for CTAs, labels
- **Captions:** Roboto Regular (400) - 13px for timestamps, helper text
- **Hierarchy Note:** Use size + weight variation, not just weight alone

---

## Layout System
**Tailwind Spacing Units:** 2, 4, 6, 8 (consistent throughout)
- **Tight spacing:** gap-2, p-2 (component internals)
- **Standard rhythm:** p-4, gap-4 (cards, sections)
- **Generous breathing:** py-6, mb-6 (section separation)
- **Major divisions:** py-8, mt-8 (distinct areas)

**Container Strategy:**
- Mobile: Full-width with px-4 side padding
- Desktop: max-w-7xl centered with px-6
- Content max-width: max-w-3xl for text-heavy sections

---

## Component Library

### Landing/Onboarding Hero
- **Full-screen hero section** (80vh) with authentic Amazon community imagery
  - Background: Wide-angle photo of Transamazônica road/community gathering
  - Overlaid text: "A comunidade resolvendo seus próprios problemas" (large, bold)
  - Subtitle: Community statistics (e.g., "432 problemas resolvidos | 1,247 assinaturas coletadas")
  - Primary CTA: "Começar Agora" button with blurred background backdrop
  - Secondary CTA: "Ver Como Funciona" (ghost button)
- **Three-feature showcase** below hero:
  - Large icons (64px) with descriptive text
  - Features: "Reporte Problemas", "Organize Abaixo-Assinados", "Conecte a Comunidade"
  - Photo illustrations showing real app usage
- **Trust section:**
  - Community testimonials with member photos
  - Map showing coverage area
  - Recent success stories grid (3-column cards)

### Bottom Navigation (Mobile Primary)
- **5 tabs with large icons** (32px) and labels:
  - Mapa | Problemas | Comunidade | Grupos | Perfil
- Fixed position, elevated card style with rounded top corners (rounded-t-2xl)
- Active state: Icon scale + underline indicator
- 72px height for thumb comfort

### Map Interface
- **Full-screen map view** with overlay controls:
  - Floating search bar (top, rounded-full)
  - Layer toggle pills (top-right): "Todos | Urgente | Resolvidos"
  - Zoom controls (right side, vertical stack)
  - Location FAB (bottom-right, 56px circle)
- **Problem markers:** Custom illustrated pins with category icons inside
- **Legend card:** Bottom sheet (swipe up), shows pin categories with status counts
- **Cluster indicators:** Circular badges showing count when zoomed out

### Photo-First Problem Cards
- **Large format card design:**
  - Hero image (16:9 aspect ratio, rounded-t-xl corners)
  - Overlay gradient at bottom with white text
  - Category badge (top-left corner, 8px from edge)
  - Status badge (top-right corner)
- **Card content section:**
  - Bold title (18px)
  - Author info: Avatar (32px) + name + timestamp
  - Description excerpt (3 lines max, fade ellipsis)
  - Action bar: Signature count + "Assinar" button + share icon
- **Image gallery variant:**
  - Multi-photo carousel with dots indicator
  - Swipe gesture support
  - Photo counter badge "1/4"

### Problem Reporting Flow
- **Camera-first interface:**
  - Large "Adicionar Fotos" area (200px height, dashed border when empty)
  - Camera icon (48px) centered
  - Gallery thumbnail grid after upload (3 columns)
  - Primary photo selection (highlighted border)
- **Category selector:**
  - Grid layout (2 columns on mobile, 4 on desktop)
  - Large icon buttons (80px square cards)
  - Icons: Energia, Estrada, Ponte, Saúde, Educação, Segurança
  - Selected state: elevated card with checkmark
- **Location capture:**
  - Map preview card (150px height)
  - "Usar Minha Localização" button (full-width, prominent)
  - Manual address entry (collapsed accordion)
- **Description field:**
  - Auto-expanding textarea
  - Character counter (500 max)
  - Helper text: "Seja específico para ajudar a comunidade"

### Petition/Signature System
- **Petition detail view:**
  - Full-width photo carousel (400px height)
  - Problem description with rich formatting
  - Progress bar: Visual thermometer showing signature goal
  - Milestone markers on progress bar (25%, 50%, 75%, 100%)
  - Large count display: "234 de 500 assinaturas"
- **Signature action:**
  - Fixed bottom card (elevated, full-width)
  - "Assinar Abaixo-Assinado" primary button
  - Secondary action: "Compartilhar no WhatsApp"
  - Legal disclaimer (small text, collapsible)
- **Signatory list:**
  - Avatar grid (48px circles, overlapping -ml-3)
  - "Ver todos" expansion trigger
  - Full list: Names with timestamps, grouped by date

### Gamification Elements
- **Achievement badges:**
  - Circular icons (64px) with illustrated symbols
  - Labels: "Primeiro Relato", "10 Assinaturas", "Problema Resolvido"
  - Display in profile section and celebration modals
- **Progress indicators:**
  - Animated circular progress rings
  - Linear bars with gradient fills
  - Milestone confetti animation on completion
- **Status visualization:**
  - Timeline view showing problem lifecycle
  - Icon + text nodes (Relatado → Em Andamento → Resolvido)
  - Connecting lines with animated pulse on active status

### Community Directory
- **Member cards:**
  - Horizontal card layout
  - Avatar (56px, left-aligned)
  - Name + property location
  - Contact button: "WhatsApp" with platform icon
  - "Ver Propriedade no Mapa" link
- **Grid layout:** Single column mobile, 2-column tablet, 3-column desktop
- **Search bar:** Top-anchored with filters dropdown

### WhatsApp Integration
- **Quick action cards:**
  - Branded treatment (WhatsApp visual language)
  - Group name + member count
  - "Abrir Grupo" button (full-width within card)
  - Timestamp of last activity
- **Share functionality:**
  - Native share sheet trigger
  - Pre-formatted message templates
  - Image + text bundling for rich shares

### Trust & Transparency Elements
- **Status tracking timeline:**
  - Vertical timeline with node markers
  - Each update: timestamp, author, action, optional photo
  - Visual connection lines between events
- **Accountability cards:**
  - Responsible party/organization clearly labeled
  - Expected resolution timeframe
  - Update frequency indicator
- **Success metrics dashboard:**
  - Large number displays with icons
  - Grid layout: Problems reported | Resolved | Signatures | Active members
  - Trend indicators (up/down arrows with percentages)

---

## Images Strategy

### Required Images
1. **Hero Section:** Wide landscape photo of Transamazônica road or community gathering (authentic, showing infrastructure/people context)
2. **Problem Cards:** User-uploaded photos of infrastructure issues (roads, bridges, electrical, etc.)
3. **Success Stories:** Before/after comparison imagery showing resolved problems
4. **Community Members:** Profile photos and avatars throughout
5. **Feature Illustrations:** Custom iconography for categories (roads, electricity, health, etc.)

### Image Treatment
- **Rounded corners:** 12px (rounded-xl) for all imagery
- **Aspect ratios:** 16:9 for hero/cards, 1:1 for avatars, 4:3 for detail views
- **Loading states:** Subtle skeleton screens matching content shape
- **Compression:** Auto-optimize for rural bandwidth (progressive JPEGs, WebP support)

---

## Animations (Minimal, Purposeful)
- **Success feedback:** Confetti burst on signature submission (2 seconds)
- **Progress:** Smooth bar fill animations (300ms ease-out)
- **Status transitions:** Gentle node highlighting in timeline
- **Photo uploads:** Fade-in + scale (200ms) when added to gallery
- **Map markers:** Gentle drop-in bounce on placement
- **NO:** Excessive page transitions, background animations, decorative motion

---

## Accessibility & Inclusivity
- **Touch targets:** Minimum 44x44px, generous padding around interactive elements
- **Icon + text pairing:** Never icon-only for critical actions
- **Contrast patterns:** Rely on size/weight/spacing hierarchy, not subtle shades
- **Offline indicators:** Always-visible connection status badge
- **Progressive disclosure:** Complex actions broken into clear steps
- **Error states:** Friendly language with recovery suggestions

---

## Critical UX Flows
1. **New Problem Report:** Camera → Category → Location (GPS) → Description → Submit (queues offline)
2. **Sign Petition:** View problem → Read details → One-tap signature → Share confirmation
3. **Track Status:** Problem detail → Timeline view → Subscribe to updates
4. **Community Connection:** Directory → Member profile → WhatsApp deep-link
5. **Success Celebration:** Milestone reached → Modal with achievement → Share prompt

---

This design creates visual warmth through generous imagery, rounded corners, and human-centered language while maintaining Material Design's clarity and mobile efficiency. The photo-first approach builds empathy and urgency, gamification drives engagement, and transparency mechanisms establish trust - all optimized for rural smartphone usage with offline resilience.