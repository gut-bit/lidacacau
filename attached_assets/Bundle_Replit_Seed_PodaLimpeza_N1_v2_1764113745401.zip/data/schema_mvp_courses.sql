-- SQLite schema (MVP) for importing course/skill content
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS skills (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS courses (
  id TEXT PRIMARY KEY,
  skill_id TEXT,
  title TEXT NOT NULL,
  tagline TEXT,
  version TEXT,
  level TEXT, -- teaser | N1 | N2 ...
  estimated_minutes INTEGER,
  published_at TEXT,
  metadata_json TEXT,
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS course_modules (
  id TEXT PRIMARY KEY,
  course_id TEXT NOT NULL,
  order_index INTEGER NOT NULL,
  title TEXT NOT NULL,
  time_minutes INTEGER,
  competencies_json TEXT,
  content_md TEXT,
  images_json TEXT,
  quiz_id TEXT,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS quizzes (
  id TEXT PRIMARY KEY,
  course_id TEXT NOT NULL,
  module_id TEXT,
  pass_score INTEGER NOT NULL,
  question_count INTEGER NOT NULL,
  xp_on_pass INTEGER DEFAULT 50,
  metadata_json TEXT,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS quiz_questions (
  id TEXT PRIMARY KEY,
  quiz_id TEXT NOT NULL,
  order_index INTEGER NOT NULL,
  prompt TEXT NOT NULL,
  choices_json TEXT NOT NULL,
  correct_index INTEGER NOT NULL,
  explanation TEXT,
  FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rubrics (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  name TEXT NOT NULL,
  scale_json TEXT NOT NULL,
  weights_json TEXT NOT NULL,
  pass_min REAL NOT NULL,
  pass_rule TEXT,
  unlock_rule_n1 TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rubric_dimensions (
  id TEXT PRIMARY KEY,
  rubric_id TEXT NOT NULL,
  key TEXT NOT NULL,
  title TEXT NOT NULL,
  weight REAL NOT NULL,
  levels_json TEXT NOT NULL,
  critical_failures_json TEXT,
  FOREIGN KEY (rubric_id) REFERENCES rubrics(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS checklists (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  title TEXT NOT NULL,
  phase TEXT NOT NULL, -- antes_de_iniciar | durante | finalizacao
  items_json TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evidence_protocols (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  title TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  anti_fraud_json TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS os_templates (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  title TEXT NOT NULL,
  fields_json TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS progression_rules (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL,
  levels_json TEXT NOT NULL,
  xp_sources_json TEXT NOT NULL,
  penalties_json TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS assets (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,         -- image | pdf | doc
  file_name TEXT NOT NULL,
  title TEXT,
  caption TEXT,
  metadata_json TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_courses_skill ON courses(skill_id);
CREATE INDEX IF NOT EXISTS idx_modules_course ON course_modules(course_id, order_index);
CREATE INDEX IF NOT EXISTS idx_questions_quiz ON quiz_questions(quiz_id, order_index);
