/**
 * Import seed JSON into SQLite (MVP).
 * Usage:
 *   1) npm i better-sqlite3
 *   2) node scripts/import_seed.js data/seed_relational_poda_limpeza_n1.json data/app.db
 *
 * If better-sqlite3 is painful in Replit, switch to 'sqlite3' package.
 */
const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

function insertMany(db, table, rows) {
  if (!rows || rows.length === 0) return;
  const cols = Object.keys(rows[0]);
  const placeholders = cols.map(c => "@" + c).join(", ");
  const stmt = db.prepare(`INSERT OR REPLACE INTO ${table} (${cols.join(", ")}) VALUES (${placeholders})`);
  const tx = db.transaction((items) => {
    for (const it of items) stmt.run(it);
  });
  tx(rows);
}

const seedFile = process.argv[2];
const dbFile = process.argv[3] || "app.db";

if (!seedFile) {
  console.error("Missing seed file. Example: node scripts/import_seed.js data/seed_relational_poda_limpeza_n1.json data/app.db");
  process.exit(1);
}

const seed = JSON.parse(fs.readFileSync(seedFile, "utf-8"));
const db = new Database(dbFile);

const schemaPath = path.join(__dirname, "..", "data", "schema_mvp_courses.sql");
if (fs.existsSync(schemaPath)) {
  db.exec(fs.readFileSync(schemaPath, "utf-8"));
} else {
  console.warn("Warning: schema file not found at", schemaPath, "(skipping)");
}

insertMany(db, "skills", seed.skills);
insertMany(db, "courses", seed.courses);
insertMany(db, "course_modules", seed.course_modules);
insertMany(db, "quizzes", seed.quizzes);
insertMany(db, "quiz_questions", seed.quiz_questions);
insertMany(db, "rubrics", seed.rubrics);
insertMany(db, "rubric_dimensions", seed.rubric_dimensions);
insertMany(db, "checklists", seed.checklists);
insertMany(db, "evidence_protocols", seed.evidence_protocols);
insertMany(db, "os_templates", seed.os_templates);
insertMany(db, "progression_rules", seed.progression_rules);
insertMany(db, "assets", seed.assets);

db.close();
console.log("✅ Import OK:", { dbFile, skills: seed.skills.length, courses: seed.courses.length });
